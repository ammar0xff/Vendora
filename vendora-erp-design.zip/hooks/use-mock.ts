'use client'

import useSWR from 'swr'
import { useApp } from '@/components/app/app-provider'
import { MOCK_SOURCES, type MockKey } from '@/lib/mock-data'

type Source = typeof MOCK_SOURCES

function mockFetcher<K extends MockKey>(key: K): Promise<Source[K]> {
  return new Promise((resolve) => setTimeout(() => resolve(MOCK_SOURCES[key]), 450))
}

export type ListQuery<T> = {
  data: T[]
  status: 'loading' | 'error' | 'ready'
  retry: () => void
  mutate: (next: T[]) => void
}

export function useMock<K extends MockKey>(key: K): ListQuery<Source[K][number]> {
  const { preview, setPreview } = useApp()
  const { data, isLoading, error, mutate } = useSWR(key, mockFetcher, {
    revalidateOnFocus: false,
  })

  type Item = Source[K][number]
  const items = (data ?? []) as Item[]

  let status: ListQuery<Item>['status'] = 'ready'
  if (preview === 'loading' || isLoading) status = 'loading'
  else if (preview === 'error' || error) status = 'error'

  return {
    data: preview === 'empty' ? [] : items,
    status,
    retry: () => {
      setPreview('live')
      mutate()
    },
    mutate: (next) => mutate(next as unknown as Source[K], { revalidate: false }),
  }
}

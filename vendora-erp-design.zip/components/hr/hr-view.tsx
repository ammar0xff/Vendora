'use client'

import { useMemo, useState } from 'react'
import { CalendarOff, Clock, UserCheck, UserCog, UserX } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ListState, Money, Num, PageHeader, SimpleSelect, StatCard, StatusBadge, TableShell } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableFooter, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useMock } from '@/hooks/use-mock'
import { formatTime } from '@/lib/format'
import type { Employee } from '@/lib/mock-data'

const LATE_AFTER_HOUR = 9

export function HrView() {
  const { roleId } = useApp()
  const employees = useMock('employees')
  const [branch, setBranch] = useState('all')
  const canSeePayroll = roleId === 'admin' || roleId === 'accountant'

  const branches = useMemo(() => Array.from(new Set(employees.data.map((e) => e.branch))), [employees.data])
  const rows = useMemo(() => employees.data.filter((e) => branch === 'all' || e.branch === branch), [employees.data, branch])
  const count = (s: Employee['status']) => employees.data.filter((e) => e.status === s).length
  const payroll = rows.reduce((s, e) => s + e.salary, 0)

  function checkIn(e: Employee) {
    const now = new Date()
    const status: Employee['status'] = now.getHours() >= LATE_AFTER_HOUR && now.getMinutes() > 15 ? 'متأخر' : 'حاضر'
    employees.mutate(employees.data.map((x) => (x.id === e.id ? { ...x, status, checkIn: now.toISOString() } : x)))
    toast.success(`تم تسجيل حضور ${e.name}`, { description: status === 'متأخر' ? 'سُجّل كتأخير' : undefined })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="الموارد البشرية"
        description="حضور اليوم والموظفون والرواتب"
        actions={
          <SimpleSelect
            value={branch}
            onValueChange={setBranch}
            label="الفرع"
            className="w-48"
            options={[{ value: 'all', label: 'كل الفروع' }, ...branches.map((b) => ({ value: b, label: b }))]}
          />
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="حاضر" value={<Num value={count('حاضر')} />} icon={UserCheck} tone="success" />
        <StatCard label="متأخر" value={<Num value={count('متأخر')} />} icon={Clock} tone="warning" />
        <StatCard label="إجازة" value={<Num value={count('إجازة')} />} icon={CalendarOff} />
        <StatCard label="غائب" value={<Num value={count('غائب')} />} icon={UserX} tone="destructive" />
      </div>

      <Tabs defaultValue="attendance" className="flex flex-col gap-4">
        <TabsList>
          <TabsTrigger value="attendance">حضور اليوم</TabsTrigger>
          {canSeePayroll && <TabsTrigger value="payroll">الرواتب</TabsTrigger>}
        </TabsList>

        <TabsContent value="attendance">
          <ListState
            status={employees.status}
            isEmpty={rows.length === 0}
            onRetry={employees.retry}
            emptyIcon={UserCog}
            emptyTitle="لا يوجد موظفون"
            emptyDescription="لا يوجد موظفون مسجلون في هذا الفرع."
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الموظف</TableHead>
                    <TableHead className="hidden md:table-cell">الفرع</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead className="hidden sm:table-cell">وقت الحضور</TableHead>
                    <TableHead className="w-28">
                      <span className="sr-only">إجراءات</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{e.name}</span>
                          <span className="text-xs text-muted-foreground">{e.title}</span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{e.branch}</TableCell>
                      <TableCell>
                        <StatusBadge status={e.status} />
                      </TableCell>
                      <TableCell className="num hidden sm:table-cell">{e.checkIn ? formatTime(e.checkIn) : '—'}</TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline" disabled={Boolean(e.checkIn) || e.status === 'إجازة'} onClick={() => checkIn(e)}>
                          تسجيل حضور
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>

        {canSeePayroll && (
          <TabsContent value="payroll">
            <ListState
              status={employees.status}
              isEmpty={rows.length === 0}
              onRetry={employees.retry}
              emptyIcon={UserCog}
              emptyTitle="لا توجد رواتب"
              emptyDescription="لا يوجد موظفون في هذا الفرع."
            >
              <TableShell>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الموظف</TableHead>
                      <TableHead className="hidden md:table-cell">المسمى</TableHead>
                      <TableHead className="hidden md:table-cell">الفرع</TableHead>
                      <TableHead>الراتب الأساسي</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((e) => (
                      <TableRow key={e.id}>
                        <TableCell className="font-medium">{e.name}</TableCell>
                        <TableCell className="hidden md:table-cell">{e.title}</TableCell>
                        <TableCell className="hidden md:table-cell">{e.branch}</TableCell>
                        <TableCell>
                          <Money value={e.salary} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell className="font-medium">الإجمالي الشهري</TableCell>
                      <TableCell className="hidden md:table-cell" />
                      <TableCell className="hidden md:table-cell" />
                      <TableCell>
                        <Money value={payroll} className="font-semibold" />
                      </TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </TableShell>
            </ListState>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}

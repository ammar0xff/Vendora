'use client'

import { useState } from 'react'
import { Money, SimpleSelect } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import type { FinanceEntry, Treasury } from '@/lib/mock-data'

const CATEGORIES: Record<FinanceEntry['kind'], string[]> = {
  مصروف: ['نقل وشحن', 'مرافق', 'إيجارات', 'رواتب', 'صيانة', 'نثريات'],
  إيراد: ['إيرادات أخرى', 'تحصيل عملاء', 'استرداد'],
}

export type EntryDraft = { kind: FinanceEntry['kind']; treasuryId: string; category: string; amount: number; description: string }

export function EntryDialog({
  open,
  onOpenChange,
  treasuries,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  treasuries: Treasury[]
  onSubmit: (draft: EntryDraft) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        {open && <EntryForm treasuries={treasuries} onCancel={() => onOpenChange(false)} onSubmit={onSubmit} />}
      </DialogContent>
    </Dialog>
  )
}

function EntryForm({
  treasuries,
  onCancel,
  onSubmit,
}: {
  treasuries: Treasury[]
  onCancel: () => void
  onSubmit: (draft: EntryDraft) => void
}) {
  const [kind, setKind] = useState<FinanceEntry['kind']>('مصروف')
  const [treasuryId, setTreasuryId] = useState(treasuries[0]?.id ?? '')
  const [category, setCategory] = useState(CATEGORIES['مصروف'][0])
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const value = Number(amount)
  const treasury = treasuries.find((t) => t.id === treasuryId)
  const insufficient = kind === 'مصروف' && treasury !== undefined && value > treasury.balance
  const invalid = !(value > 0) || insufficient || description.trim().length < 3

  return (
    <form
      className="flex flex-col gap-6"
      onSubmit={(e) => {
        e.preventDefault()
        if (!invalid) onSubmit({ kind, treasuryId, category, amount: value, description: description.trim() })
      }}
    >
      <DialogHeader>
        <DialogTitle>قيد مالي جديد</DialogTitle>
        <DialogDescription>يُحدّث رصيد الخزينة فور الحفظ ويظهر في سجل الحركات.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <Field>
          <FieldLabel>نوع القيد</FieldLabel>
          <ToggleGroup
            value={[kind]}
            onValueChange={(v) => {
              const next = v[0] as FinanceEntry['kind'] | undefined
              if (!next) return
              setKind(next)
              setCategory(CATEGORIES[next][0])
            }}
            variant="outline"
            aria-label="نوع القيد"
          >
            <ToggleGroupItem value="مصروف">مصروف</ToggleGroupItem>
            <ToggleGroupItem value="إيراد">إيراد</ToggleGroupItem>
          </ToggleGroup>
        </Field>
        <Field>
          <FieldLabel htmlFor="entry-desc">البيان</FieldLabel>
          <Input id="entry-desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="مثال: فاتورة مياه فرع المعادي" />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field>
            <FieldLabel htmlFor="entry-cat">التصنيف</FieldLabel>
            <SimpleSelect id="entry-cat" value={category} onValueChange={setCategory} options={CATEGORIES[kind].map((c) => ({ value: c, label: c }))} />
          </Field>
          <Field data-invalid={insufficient || undefined}>
            <FieldLabel htmlFor="entry-amount">المبلغ</FieldLabel>
            <Input
              id="entry-amount"
              type="number"
              inputMode="decimal"
              min={0}
              step="0.01"
              dir="ltr"
              className="num text-start"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              aria-invalid={insufficient || undefined}
            />
          </Field>
        </div>
        <Field data-invalid={insufficient || undefined}>
          <FieldLabel htmlFor="entry-treasury">الخزينة</FieldLabel>
          <SimpleSelect id="entry-treasury" value={treasuryId} onValueChange={setTreasuryId} options={treasuries.map((t) => ({ value: t.id, label: t.name }))} />
          {treasury && (
            <FieldDescription>
              {insufficient ? 'الرصيد لا يكفي لهذا المصروف — ' : 'الرصيد المتاح: '}
              <Money value={treasury.balance} />
            </FieldDescription>
          )}
        </Field>
      </FieldGroup>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button type="submit" disabled={invalid}>
          حفظ القيد
        </Button>
      </DialogFooter>
    </form>
  )
}

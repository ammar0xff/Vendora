'use client'

import { useMemo, useState } from 'react'
import { Landmark, Plus, Smartphone, TrendingDown, TrendingUp, Vault, Wallet } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ListState, Money, PageHeader, SimpleSelect, StatCard, StatusBadge, TableShell } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDateTime } from '@/lib/format'
import type { FinanceEntry, Treasury } from '@/lib/mock-data'
import { cn } from '@/lib/utils'
import { EntryDialog, type EntryDraft } from './entry-dialog'

const KIND_ICON: Record<Treasury['kind'], typeof Vault> = { خزينة: Vault, بنك: Landmark, محفظة: Smartphone }

export function FinanceView() {
  const { userName } = useApp()
  const treasuries = useMock('treasuries')
  const entries = useMock('finance')
  const [kind, setKind] = useState('all')
  const [open, setOpen] = useState(false)

  const rows = useMemo(() => entries.data.filter((e) => kind === 'all' || e.kind === kind), [entries.data, kind])
  const total = treasuries.data.reduce((s, t) => s + t.balance, 0)
  const income = entries.data.filter((e) => e.kind === 'إيراد').reduce((s, e) => s + e.amount, 0)
  const expense = entries.data.filter((e) => e.kind === 'مصروف').reduce((s, e) => s + e.amount, 0)

  function create(d: EntryDraft) {
    const treasury = treasuries.data.find((t) => t.id === d.treasuryId)
    const entry: FinanceEntry = {
      id: `f${Date.now()}`,
      date: new Date().toISOString(),
      description: d.description,
      category: d.category,
      treasury: treasury?.name ?? '',
      amount: d.amount,
      kind: d.kind,
      user: userName,
    }
    entries.mutate([entry, ...entries.data])
    treasuries.mutate(
      treasuries.data.map((t) => (t.id === d.treasuryId ? { ...t, balance: t.balance + (d.kind === 'إيراد' ? d.amount : -d.amount) } : t)),
    )
    setOpen(false)
    toast.success(`تم تسجيل ${d.kind}`, { description: `${d.description} — ${treasury?.name ?? ''}` })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="المالية"
        description="الخزائن والبنوك والمحافظ، المصروفات والإيرادات"
        actions={
          <Button onClick={() => setOpen(true)} disabled={treasuries.status !== 'ready'}>
            <Plus data-icon="inline-start" />
            قيد جديد
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="إجمالي السيولة" value={<Money value={total} />} icon={Wallet} />
        <StatCard label="إيرادات مسجلة" value={<Money value={income} />} icon={TrendingUp} tone="success" />
        <StatCard label="مصروفات مسجلة" value={<Money value={expense} />} icon={TrendingDown} tone="destructive" />
      </div>

      <section aria-labelledby="treasuries-heading" className="flex flex-col gap-3">
        <h2 id="treasuries-heading" className="text-sm font-medium text-muted-foreground">
          الخزائن والحسابات
        </h2>
        {treasuries.status === 'loading' ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {treasuries.data.map((t) => {
              const Icon = KIND_ICON[t.kind]
              return (
                <Card key={t.id} size="sm">
                  <CardHeader>
                    <CardDescription className="flex items-center justify-between gap-2">
                      <span className="truncate">{t.branch}</span>
                      <span className={cn('flex size-8 items-center justify-center rounded-md bg-muted text-muted-foreground')}>
                        <Icon className="size-4" aria-hidden />
                      </span>
                    </CardDescription>
                    <CardTitle className="flex flex-col gap-1">
                      <span className="text-sm font-medium">{t.name}</span>
                      <Money value={t.balance} className="text-xl font-semibold" />
                    </CardTitle>
                  </CardHeader>
                </Card>
              )
            })}
          </div>
        )}
      </section>

      <section aria-labelledby="entries-heading" className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-3">
          <h2 id="entries-heading" className="text-sm font-medium text-muted-foreground">
            سجل الحركات
          </h2>
          <SimpleSelect
            value={kind}
            onValueChange={setKind}
            label="نوع الحركة"
            className="w-40"
            options={[
              { value: 'all', label: 'كل الحركات' },
              { value: 'إيراد', label: 'إيرادات' },
              { value: 'مصروف', label: 'مصروفات' },
            ]}
          />
        </div>
        <ListState
          status={entries.status}
          isEmpty={rows.length === 0}
          onRetry={entries.retry}
          emptyIcon={Wallet}
          emptyTitle="لا توجد حركات"
          emptyDescription="سجّل أول مصروف أو إيراد ليظهر هنا."
        >
          <TableShell>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>البيان</TableHead>
                  <TableHead className="hidden md:table-cell">التصنيف</TableHead>
                  <TableHead className="hidden lg:table-cell">الخزينة</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>المبلغ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-medium">{e.description}</span>
                        <span className="text-xs text-muted-foreground">
                          <span className="num">{formatDateTime(e.date)}</span> · {e.user}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{e.category}</TableCell>
                    <TableCell className="hidden lg:table-cell">{e.treasury}</TableCell>
                    <TableCell>
                      <StatusBadge status={e.kind} />
                    </TableCell>
                    <TableCell>
                      <Money value={e.kind === 'مصروف' ? -e.amount : e.amount} className={e.kind === 'مصروف' ? 'text-destructive' : 'text-success'} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableShell>
        </ListState>
      </section>

      <EntryDialog open={open} onOpenChange={setOpen} treasuries={treasuries.data} onSubmit={create} />
    </div>
  )
}

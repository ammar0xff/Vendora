'use client'

import { FileText, Minus, PauseCircle, Plus, ShoppingCart, Trash2, Wallet, X } from 'lucide-react'
import { Money, SimpleSelect } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput, InputGroupText } from '@/components/ui/input-group'
import { Kbd } from '@/components/ui/kbd'
import { Separator } from '@/components/ui/separator'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import type { Customer } from '@/lib/mock-data'
import { type CartLine, type PriceTier, WALK_IN_ID, cartTotals, lineTotal, unitPrice } from './pos-types'

export function PosCart({
  lines,
  tier,
  onTierChange,
  customerId,
  onCustomerChange,
  customers,
  branchId,
  invoiceDiscount,
  onInvoiceDiscountChange,
  onQty,
  onLineDiscount,
  onRemove,
  onClear,
  onHold,
  onQuote,
  onCheckout,
  heldCount,
  onOpenHeld,
}: {
  lines: CartLine[]
  tier: PriceTier
  onTierChange: (t: PriceTier) => void
  customerId: string
  onCustomerChange: (id: string) => void
  customers: Customer[]
  branchId: string
  invoiceDiscount: number
  onInvoiceDiscountChange: (v: number) => void
  onQty: (id: string, qty: number) => void
  onLineDiscount: (id: string, v: number) => void
  onRemove: (id: string) => void
  onClear: () => void
  onHold: () => void
  onQuote: () => void
  onCheckout: () => void
  heldCount: number
  onOpenHeld: () => void
}) {
  const totals = cartTotals(lines, tier, invoiceDiscount)
  const customer = customers.find((c) => c.id === customerId)
  const empty = lines.length === 0

  return (
    <section aria-label="الفاتورة الحالية" className="flex min-h-0 flex-col overflow-hidden rounded-xl border bg-card">
      <header className="flex flex-col gap-3 border-b p-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-semibold">الفاتورة الحالية</h2>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={onOpenHeld}>
              <PauseCircle data-icon="inline-start" />
              المعلقة
              {heldCount > 0 && (
                <Badge variant="warning" className="num">
                  {heldCount}
                </Badge>
              )}
            </Button>
            <Button variant="ghost" size="icon-sm" onClick={onClear} disabled={empty} aria-label="تفريغ الفاتورة">
              <Trash2 />
            </Button>
          </div>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <SimpleSelect
            label="العميل"
            value={customerId}
            onValueChange={onCustomerChange}
            className="w-full flex-1"
            options={[
              { value: WALK_IN_ID, label: 'عميل نقدي' },
              ...customers.map((c) => ({ value: c.id, label: c.name })),
            ]}
          />
          <ToggleGroup
            variant="outline"
            size="sm"
            spacing={0}
            value={[tier]}
            onValueChange={(v) => v[0] && onTierChange(v[0] as PriceTier)}
            aria-label="شريحة السعر"
          >
            <ToggleGroupItem value="retail">قطاعي</ToggleGroupItem>
            <ToggleGroupItem value="wholesale">جملة</ToggleGroupItem>
          </ToggleGroup>
        </div>
        {customer && customer.creditLimit > 0 && (
          <p className="text-xs text-muted-foreground">
            الرصيد الحالي <Money value={customer.balance} /> — الحد الائتماني <Money value={customer.creditLimit} />
          </p>
        )}
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {empty ? (
          <Empty className="h-full">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <ShoppingCart />
              </EmptyMedia>
              <EmptyTitle>الفاتورة فارغة</EmptyTitle>
              <EmptyDescription>امسح باركود منتج أو اضغط على أي صنف لإضافته.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <ul className="flex flex-col divide-y">
            {lines.map((line) => {
              const stock = line.product.stock[branchId] ?? 0
              const atMax = line.qty >= stock
              return (
                <li key={line.product.id} className="flex flex-col gap-2 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex min-w-0 flex-col">
                      <span className="text-sm font-medium leading-snug">{line.product.name}</span>
                      <span className="text-xs text-muted-foreground">
                        <Money value={unitPrice(line.product, tier)} /> / {line.product.unit}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      onClick={() => onRemove(line.product.id)}
                      aria-label={`حذف ${line.product.name}`}
                    >
                      <X />
                    </Button>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="icon-sm"
                        onClick={() => onQty(line.product.id, line.qty - 1)}
                        aria-label="تقليل الكمية"
                      >
                        <Minus />
                      </Button>
                      <InputGroup className="h-8 w-16">
                        <InputGroupInput
                          aria-label="الكمية"
                          inputMode="numeric"
                          className="num text-center"
                          value={line.qty}
                          onChange={(e) => onQty(line.product.id, Number(e.target.value.replace(/\D/g, '')) || 0)}
                        />
                      </InputGroup>
                      <Button
                        variant="outline"
                        size="icon-sm"
                        disabled={atMax}
                        onClick={() => onQty(line.product.id, line.qty + 1)}
                        aria-label="زيادة الكمية"
                      >
                        <Plus />
                      </Button>
                    </div>
                    <InputGroup className="h-8 w-32">
                      <InputGroupInput
                        aria-label="خصم الصنف"
                        placeholder="خصم"
                        inputMode="decimal"
                        className="num"
                        value={line.discount || ''}
                        onChange={(e) => onLineDiscount(line.product.id, Number(e.target.value) || 0)}
                      />
                      <InputGroupAddon align="inline-end">
                        <InputGroupText>ج.م</InputGroupText>
                      </InputGroupAddon>
                    </InputGroup>
                    <Money value={lineTotal(line, tier)} className="ms-auto text-sm font-semibold" />
                  </div>
                  {atMax && (
                    <p className="text-xs text-warning" role="status">
                      وصلت للحد المتاح في المخزون (<span className="num">{stock}</span>)
                    </p>
                  )}
                </li>
              )
            })}
          </ul>
        )}
      </div>

      <footer className="flex flex-col gap-3 border-t bg-muted/40 p-4">
        <dl className="flex flex-col gap-1.5 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted-foreground">
              الإجمالي (<span className="num">{totals.count}</span> قطعة)
            </dt>
            <dd>
              <Money value={totals.gross} />
            </dd>
          </div>
          <div className="flex items-center justify-between gap-3">
            <dt className="text-muted-foreground">خصم على الفاتورة</dt>
            <dd>
              <InputGroup className="h-8 w-36 bg-card">
                <InputGroupInput
                  aria-label="خصم على الفاتورة"
                  inputMode="decimal"
                  className="num"
                  placeholder="0.00"
                  disabled={empty}
                  value={invoiceDiscount || ''}
                  onChange={(e) => onInvoiceDiscountChange(Number(e.target.value) || 0)}
                />
                <InputGroupAddon align="inline-end">
                  <InputGroupButton size="xs" disabled={empty} onClick={() => onInvoiceDiscountChange(Math.round(totals.gross * 0.05))}>
                    5%
                  </InputGroupButton>
                </InputGroupAddon>
              </InputGroup>
            </dd>
          </div>
          {totals.discount > 0 && (
            <div className="flex justify-between text-success">
              <dt>إجمالي الخصومات</dt>
              <dd>
                - <Money value={totals.discount} />
              </dd>
            </div>
          )}
        </dl>
        <Separator />
        <div className="flex items-baseline justify-between">
          <span className="font-medium">المطلوب</span>
          <Money value={totals.total} className="text-2xl font-bold" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" disabled={empty} onClick={onHold}>
            <PauseCircle data-icon="inline-start" />
            تعليق
            <Kbd className="ms-auto hidden xl:inline-flex">F8</Kbd>
          </Button>
          <Button variant="outline" disabled={empty} onClick={onQuote}>
            <FileText data-icon="inline-start" />
            عرض سعر
          </Button>
        </div>
        <Button size="lg" className="h-12 text-base" disabled={empty} onClick={onCheckout}>
          <Wallet data-icon="inline-start" />
          الدفع
          <Kbd className="ms-auto bg-primary-foreground/15 text-primary-foreground">F9</Kbd>
        </Button>
      </footer>
    </section>
  )
}

import type { PaymentMethod, Product } from '@/lib/mock-data'

export type PriceTier = 'retail' | 'wholesale'

export type CartLine = {
  product: Product
  qty: number
  discount: number
}

export type HeldBill = {
  id: string
  heldAt: string
  customerId: string
  tier: PriceTier
  lines: CartLine[]
  invoiceDiscount: number
}

export type CompletedSale = {
  number: string
  date: string
  customerName: string
  method: PaymentMethod
  lines: { name: string; qty: number; price: number; discount: number }[]
  subtotal: number
  discount: number
  total: number
  paid: number
  change: number
  isQuote: boolean
}

export const WALK_IN_ID = 'walk-in'

export function unitPrice(product: Product, tier: PriceTier) {
  return tier === 'wholesale' ? product.wholesale : product.price
}

export function lineTotal(line: CartLine, tier: PriceTier) {
  return Math.max(0, unitPrice(line.product, tier) * line.qty - line.discount)
}

export function cartTotals(lines: CartLine[], tier: PriceTier, invoiceDiscount: number) {
  const gross = lines.reduce((s, l) => s + unitPrice(l.product, tier) * l.qty, 0)
  const lineDiscounts = lines.reduce((s, l) => s + Math.min(l.discount, unitPrice(l.product, tier) * l.qty), 0)
  const afterLines = gross - lineDiscounts
  const safeInvoiceDiscount = Math.min(Math.max(0, invoiceDiscount), afterLines)
  return {
    gross,
    discount: lineDiscounts + safeInvoiceDiscount,
    total: Math.round((afterLines - safeInvoiceDiscount) * 100) / 100,
    count: lines.reduce((s, l) => s + l.qty, 0),
  }
}

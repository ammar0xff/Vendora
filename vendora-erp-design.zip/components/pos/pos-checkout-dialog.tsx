'use client'

import { useState } from 'react'
import { Money } from '@/components/app/shared'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { InputGroup, InputGroupAddon, InputGroupInput, InputGroupText } from '@/components/ui/input-group'
import { Spinner } from '@/components/ui/spinner'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { formatMoney } from '@/lib/format'
import type { Customer, PaymentMethod } from '@/lib/mock-data'
import { AlertTriangle } from 'lucide-react'

const METHODS: PaymentMethod[] = ['نقدي', 'محفظة', 'تحويل بنكي', 'آجل']

export function PosCheckoutDialog({
  open,
  onOpenChange,
  total,
  customer,
  onConfirm,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  total: number
  customer: Customer | undefined
  onConfirm: (method: PaymentMethod, paid: number) => Promise<void>
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        {open && <CheckoutForm total={total} customer={customer} onConfirm={onConfirm} onCancel={() => onOpenChange(false)} />}
      </DialogContent>
    </Dialog>
  )
}

function CheckoutForm({
  total,
  customer,
  onConfirm,
  onCancel,
}: {
  total: number
  customer: Customer | undefined
  onConfirm: (method: PaymentMethod, paid: number) => Promise<void>
  onCancel: () => void
}) {
  const [method, setMethod] = useState<PaymentMethod>('نقدي')
  const [paid, setPaid] = useState(String(total))
  const [reference, setReference] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [touched, setTouched] = useState(false)

  const paidValue = Number(paid) || 0
  const change = method === 'نقدي' ? Math.max(0, paidValue - total) : 0
  const remaining = Math.max(0, total - paidValue)
  const availableCredit = customer ? customer.creditLimit - customer.balance : 0

  let error = ''
  let blocker = ''
  if (method === 'آجل') {
    if (!customer) blocker = 'البيع الآجل يتطلب اختيار عميل مسجل. اختر العميل من الفاتورة أولًا.'
    else if (customer.creditLimit <= 0) blocker = `العميل "${customer.name}" غير مسموح له بالبيع الآجل.`
    else if (remaining > availableCredit)
      blocker = `المتبقي (${formatMoney(remaining)} ج.م) يتجاوز الرصيد الائتماني المتاح (${formatMoney(Math.max(0, availableCredit))} ج.م).`
    if (paidValue > total) error = 'الدفعة المقدمة أكبر من قيمة الفاتورة'
  } else if (method === 'نقدي') {
    if (paidValue < total) error = 'المبلغ المدفوع أقل من المطلوب'
  } else if (!reference.trim()) {
    error = 'رقم العملية مطلوب للتحقق من الدفع'
  }

  const quickAmounts = Array.from(new Set([total, Math.ceil(total / 50) * 50, Math.ceil(total / 100) * 100, Math.ceil(total / 500) * 500])).slice(0, 4)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setTouched(true)
    if (error || blocker) return
    setSubmitting(true)
    try {
      await onConfirm(method, method === 'محفظة' || method === 'تحويل بنكي' ? total : paidValue)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={submit} noValidate className="flex flex-col gap-4">
      <DialogHeader>
        <DialogTitle>إتمام الدفع</DialogTitle>
        <DialogDescription>
          المطلوب <Money value={total} className="font-semibold text-foreground" />
          {customer ? ` — ${customer.name}` : ' — عميل نقدي'}
        </DialogDescription>
      </DialogHeader>

      <FieldGroup>
        <Field>
          <FieldLabel>طريقة الدفع</FieldLabel>
          <ToggleGroup
            variant="outline"
            spacing={0}
            value={[method]}
            onValueChange={(v) => {
              if (!v[0]) return
              const m = v[0] as PaymentMethod
              setMethod(m)
              setTouched(false)
              setPaid(m === 'آجل' ? '0' : String(total))
            }}
            className="w-full"
            aria-label="طريقة الدفع"
          >
            {METHODS.map((m) => (
              <ToggleGroupItem key={m} value={m} className="flex-1">
                {m}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
        </Field>

        {(method === 'نقدي' || method === 'آجل') && (
          <Field data-invalid={(touched && !!error) || undefined}>
            <FieldLabel htmlFor="paid">{method === 'آجل' ? 'الدفعة المقدمة' : 'المبلغ المستلم'}</FieldLabel>
            <InputGroup className="h-11">
              <InputGroupInput
                id="paid"
                inputMode="decimal"
                className="num text-lg"
                autoFocus
                value={paid}
                onChange={(e) => setPaid(e.target.value)}
                aria-invalid={(touched && !!error) || undefined}
              />
              <InputGroupAddon align="inline-end">
                <InputGroupText>ج.م</InputGroupText>
              </InputGroupAddon>
            </InputGroup>
            {method === 'نقدي' && (
              <div className="flex flex-wrap gap-2">
                {quickAmounts.map((a) => (
                  <Button key={a} type="button" variant="secondary" size="sm" className="num" onClick={() => setPaid(String(a))}>
                    {formatMoney(a)}
                  </Button>
                ))}
              </div>
            )}
            {touched && error ? <FieldError>{error}</FieldError> : null}
          </Field>
        )}

        {(method === 'محفظة' || method === 'تحويل بنكي') && (
          <Field data-invalid={(touched && !!error) || undefined}>
            <FieldLabel htmlFor="ref">رقم العملية</FieldLabel>
            <InputGroup>
              <InputGroupInput
                id="ref"
                autoFocus
                className="num"
                placeholder={method === 'محفظة' ? 'مثال: 0105 123 4567' : 'رقم التحويل البنكي'}
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                aria-invalid={(touched && !!error) || undefined}
              />
            </InputGroup>
            {touched && error ? (
              <FieldError>{error}</FieldError>
            ) : (
              <FieldDescription>يتم مطابقة رقم العملية مع كشف الحساب في نهاية اليوم.</FieldDescription>
            )}
          </Field>
        )}
      </FieldGroup>

      {blocker && (
        <Alert variant="destructive">
          <AlertTriangle />
          <AlertTitle>لا يمكن إتمام البيع الآجل</AlertTitle>
          <AlertDescription>{blocker}</AlertDescription>
        </Alert>
      )}

      <dl className="grid grid-cols-2 gap-3 rounded-lg bg-muted p-3 text-sm">
        {method === 'نقدي' ? (
          <div className="col-span-2 flex items-baseline justify-between">
            <dt className="text-muted-foreground">الباقي للعميل</dt>
            <dd>
              <Money value={change} className="text-xl font-bold" />
            </dd>
          </div>
        ) : method === 'آجل' ? (
          <>
            <div className="flex flex-col">
              <dt className="text-muted-foreground">يُضاف لحساب العميل</dt>
              <dd>
                <Money value={remaining} className="font-semibold" />
              </dd>
            </div>
            <div className="flex flex-col">
              <dt className="text-muted-foreground">الائتمان المتاح</dt>
              <dd>
                <Money value={Math.max(0, availableCredit)} className="font-semibold" />
              </dd>
            </div>
          </>
        ) : (
          <div className="col-span-2 flex items-baseline justify-between">
            <dt className="text-muted-foreground">المبلغ المحصّل</dt>
            <dd>
              <Money value={total} className="font-semibold" />
            </dd>
          </div>
        )}
      </dl>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel} disabled={submitting}>
          رجوع
        </Button>
        <Button type="submit" disabled={submitting || !!blocker}>
          {submitting && <Spinner data-icon="inline-start" />}
          {submitting ? 'جارٍ الحفظ...' : 'تأكيد وطباعة'}
        </Button>
      </DialogFooter>
    </form>
  )
}

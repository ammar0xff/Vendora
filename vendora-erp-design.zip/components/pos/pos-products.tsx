'use client'

import Image from 'next/image'
import { ScanBarcode } from 'lucide-react'
import { Money } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { InputGroup, InputGroupAddon, InputGroupInput } from '@/components/ui/input-group'
import { Kbd } from '@/components/ui/kbd'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { CATEGORIES, type Product } from '@/lib/mock-data'
import { cn } from '@/lib/utils'
import { type PriceTier, unitPrice } from './pos-types'

export function PosProducts({
  products,
  loading,
  branchId,
  tier,
  query,
  onQueryChange,
  category,
  onCategoryChange,
  onAdd,
  onScan,
  inCart,
  searchRef,
}: {
  products: Product[]
  loading: boolean
  branchId: string
  tier: PriceTier
  query: string
  onQueryChange: (q: string) => void
  category: string
  onCategoryChange: (c: string) => void
  onAdd: (p: Product) => void
  onScan: (code: string) => void
  inCart: Record<string, number>
  searchRef: React.RefObject<HTMLInputElement | null>
}) {
  return (
    <section aria-label="المنتجات" className="flex min-h-0 flex-col gap-3">
      <InputGroup className="h-11 bg-card">
        <InputGroupInput
          ref={searchRef}
          autoFocus
          placeholder="امسح الباركود أو ابحث بالاسم / الكود"
          aria-label="بحث أو باركود"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key !== 'Enter' || e.nativeEvent.isComposing || e.keyCode === 229) return
            e.preventDefault()
            if (query.trim()) onScan(query.trim())
          }}
        />
        <InputGroupAddon>
          <ScanBarcode />
        </InputGroupAddon>
        <InputGroupAddon align="inline-end" className="hidden sm:flex">
          <Kbd>F2</Kbd>
        </InputGroupAddon>
      </InputGroup>

      <ScrollArea className="w-full" dir="rtl">
        <ToggleGroup
          variant="outline"
          size="sm"
          value={[category]}
          onValueChange={(v) => onCategoryChange(v[0] ?? 'all')}
          aria-label="تصنيف المنتجات"
          className="pb-2"
        >
          <ToggleGroupItem value="all">الكل</ToggleGroupItem>
          {CATEGORIES.map((c) => (
            <ToggleGroupItem key={c} value={c} className="whitespace-nowrap">
              {c}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
      </ScrollArea>

      <div className="min-h-0 flex-1 overflow-y-auto pe-1">
        {loading ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 2xl:grid-cols-4" aria-busy="true" aria-label="جارٍ تحميل المنتجات">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="aspect-[4/5] rounded-xl" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <Empty className="h-full border border-dashed">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <ScanBarcode />
              </EmptyMedia>
              <EmptyTitle>لا توجد منتجات مطابقة</EmptyTitle>
              <EmptyDescription>جرّب اسمًا آخر أو امسح الباركود مرة أخرى.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 2xl:grid-cols-4">
            {products.map((p) => {
              const stock = p.stock[branchId] ?? 0
              const available = stock - (inCart[p.id] ?? 0)
              const out = stock <= 0
              const low = !out && stock < p.minStock
              return (
                <li key={p.id}>
                  <button
                    type="button"
                    disabled={out}
                    onClick={() => onAdd(p)}
                    className={cn(
                      'group flex h-full w-full flex-col overflow-hidden rounded-xl border bg-card text-start transition-colors outline-none',
                      'hover:border-primary/50 focus-visible:ring-3 focus-visible:ring-ring/50',
                      'disabled:cursor-not-allowed disabled:opacity-55',
                      inCart[p.id] && 'border-primary ring-1 ring-primary/30',
                    )}
                  >
                    <div className="relative aspect-[4/3] bg-muted">
                      <Image src={p.image} alt="" fill sizes="(min-width: 1536px) 12vw, 25vw" className="object-contain p-3" />
                      {inCart[p.id] ? (
                        <Badge className="absolute top-2 start-2">
                          <span className="num">{inCart[p.id]}</span> في السلة
                        </Badge>
                      ) : null}
                    </div>
                    <div className="flex flex-1 flex-col gap-1.5 p-3">
                      <span className="line-clamp-2 text-sm font-medium leading-snug">{p.name}</span>
                      <span className="num text-xs text-muted-foreground">{p.sku}</span>
                      <div className="mt-auto flex items-center justify-between gap-2 pt-1">
                        <Money value={unitPrice(p, tier)} className="text-sm font-semibold" />
                        <Badge variant={out ? 'destructive' : low ? 'warning' : 'secondary'}>
                          {out ? 'نفد' : <span className="num">{Math.max(available, 0)}</span>}
                        </Badge>
                      </div>
                    </div>
                  </button>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </section>
  )
}

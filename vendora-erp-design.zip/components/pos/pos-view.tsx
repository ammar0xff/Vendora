'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { PlayCircle, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { Money } from '@/components/app/shared'
import { OpenShiftCard } from '@/components/shifts/open-shift-card'
import { Button } from '@/components/ui/button'
import { Empty, EmptyDescription, EmptyHeader, EmptyTitle } from '@/components/ui/empty'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { useMock } from '@/hooks/use-mock'
import { formatTime } from '@/lib/format'
import type { PaymentMethod, Product } from '@/lib/mock-data'
import { PosCart } from './pos-cart'
import { PosCheckoutDialog } from './pos-checkout-dialog'
import { PosProducts } from './pos-products'
import { PosReceiptDialog } from './pos-receipt-dialog'
import { type CartLine, type CompletedSale, type HeldBill, type PriceTier, WALK_IN_ID, cartTotals, unitPrice } from './pos-types'

let invoiceSeq = 10483
let quoteSeq = 214

export function PosView() {
  const { shift, branchId, recordSale } = useApp()
  const products = useMock('products')
  const customers = useMock('customers')

  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [lines, setLines] = useState<CartLine[]>([])
  const [tier, setTier] = useState<PriceTier>('retail')
  const [customerId, setCustomerId] = useState(WALK_IN_ID)
  const [invoiceDiscount, setInvoiceDiscount] = useState(0)
  const [held, setHeld] = useState<HeldBill[]>([])
  const [heldOpen, setHeldOpen] = useState(false)
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [confirmClear, setConfirmClear] = useState(false)
  const [sale, setSale] = useState<CompletedSale | null>(null)
  const searchRef = useRef<HTMLInputElement>(null)

  const activeProducts = useMemo(() => products.data.filter((p) => p.active), [products.data])
  const customer = customers.data.find((c) => c.id === customerId)

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return activeProducts.filter(
      (p) =>
        (category === 'all' || p.category === category) &&
        (!q || p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || p.barcodes.some((b) => b.includes(q))),
    )
  }, [activeProducts, category, query])

  const inCart = useMemo(() => Object.fromEntries(lines.map((l) => [l.product.id, l.qty])), [lines])

  const addProduct = useCallback(
    (product: Product) => {
      const stock = product.stock[branchId] ?? 0
      setLines((prev) => {
        const existing = prev.find((l) => l.product.id === product.id)
        const nextQty = (existing?.qty ?? 0) + 1
        if (nextQty > stock) {
          toast.error('الكمية غير متوفرة', { description: `المتاح من "${product.name}" في الفرع: ${stock}` })
          return prev
        }
        if (existing) return prev.map((l) => (l.product.id === product.id ? { ...l, qty: nextQty } : l))
        return [...prev, { product, qty: 1, discount: 0 }]
      })
    },
    [branchId],
  )

  function handleScan(code: string) {
    const match =
      activeProducts.find((p) => p.barcodes.includes(code) || p.sku.toLowerCase() === code.toLowerCase()) ??
      (visible.length === 1 ? visible[0] : undefined)
    if (!match) {
      toast.error('لم يتم العثور على المنتج', { description: `لا يوجد صنف بالكود "${code}"` })
      return
    }
    addProduct(match)
    setQuery('')
  }

  function setQty(id: string, qty: number) {
    setLines((prev) => {
      if (qty <= 0) return prev.filter((l) => l.product.id !== id)
      return prev.map((l) => {
        if (l.product.id !== id) return l
        const stock = l.product.stock[branchId] ?? 0
        if (qty > stock) toast.warning(`أقصى كمية متاحة: ${stock}`)
        return { ...l, qty: Math.min(qty, stock) }
      })
    })
  }

  function setLineDiscount(id: string, value: number) {
    setLines((prev) =>
      prev.map((l) => (l.product.id === id ? { ...l, discount: Math.min(Math.max(0, value), unitPrice(l.product, tier) * l.qty) } : l)),
    )
  }

  function resetCart() {
    setLines([])
    setInvoiceDiscount(0)
    setCustomerId(WALK_IN_ID)
    setTier('retail')
    searchRef.current?.focus()
  }

  const holdBill = useCallback(() => {
    if (lines.length === 0) return
    setHeld((h) => [
      { id: crypto.randomUUID(), heldAt: new Date().toISOString(), customerId, tier, lines, invoiceDiscount },
      ...h,
    ])
    toast.success('تم تعليق الفاتورة', { description: 'يمكنك استكمالها من قائمة الفواتير المعلقة' })
    setLines([])
    setInvoiceDiscount(0)
    setCustomerId(WALK_IN_ID)
    setTier('retail')
  }, [customerId, invoiceDiscount, lines, tier])

  function resumeBill(bill: HeldBill) {
    if (lines.length > 0) {
      toast.error('أكمل أو علّق الفاتورة الحالية أولًا')
      return
    }
    setLines(bill.lines)
    setTier(bill.tier)
    setCustomerId(bill.customerId)
    setInvoiceDiscount(bill.invoiceDiscount)
    setHeld((h) => h.filter((b) => b.id !== bill.id))
    setHeldOpen(false)
  }

  function buildSale(method: PaymentMethod, paid: number, isQuote: boolean): CompletedSale {
    const totals = cartTotals(lines, tier, invoiceDiscount)
    return {
      number: isQuote ? `QT-${String(quoteSeq++).padStart(5, '0')}` : `INV-${invoiceSeq++}`,
      date: new Date().toISOString(),
      customerName: customer?.name ?? 'عميل نقدي',
      method,
      lines: lines.map((l) => ({ name: l.product.name, qty: l.qty, price: unitPrice(l.product, tier), discount: l.discount })),
      subtotal: totals.gross,
      discount: totals.discount,
      total: totals.total,
      paid,
      change: method === 'نقدي' ? Math.max(0, paid - totals.total) : 0,
      isQuote,
    }
  }

  async function confirmCheckout(method: PaymentMethod, paid: number) {
    await new Promise((r) => setTimeout(r, 650))
    const result = buildSale(method, paid, false)
    recordSale(result.total, method)
    setCheckoutOpen(false)
    setSale(result)
    toast.success(`تم حفظ الفاتورة ${result.number}`)
    setLines([])
    setInvoiceDiscount(0)
  }

  function saveQuote() {
    if (lines.length === 0) return
    const result = buildSale('نقدي', 0, true)
    setSale(result)
    toast.success(`تم حفظ عرض السعر ${result.number}`, { description: 'لن يتم خصم أي كمية من المخزون' })
    setLines([])
    setInvoiceDiscount(0)
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === 'F2') {
        e.preventDefault()
        searchRef.current?.focus()
        searchRef.current?.select()
      } else if (e.key === 'F9' && lines.length > 0 && !checkoutOpen && !sale) {
        e.preventDefault()
        setCheckoutOpen(true)
      } else if (e.key === 'F8' && lines.length > 0 && !checkoutOpen) {
        e.preventDefault()
        holdBill()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [lines.length, checkoutOpen, sale, holdBill])

  if (!shift) {
    return (
      <div className="flex min-h-[60vh] items-center">
        <OpenShiftCard />
      </div>
    )
  }

  const totals = cartTotals(lines, tier, invoiceDiscount)

  return (
    <div className="grid gap-4 lg:h-[calc(100svh-7.5rem)] lg:grid-cols-[minmax(0,1fr)_400px] xl:grid-cols-[minmax(0,1fr)_440px]">
      <PosProducts
        products={visible}
        loading={products.status === 'loading'}
        branchId={branchId}
        tier={tier}
        query={query}
        onQueryChange={setQuery}
        category={category}
        onCategoryChange={setCategory}
        onAdd={addProduct}
        onScan={handleScan}
        inCart={inCart}
        searchRef={searchRef}
      />
      <PosCart
        lines={lines}
        tier={tier}
        onTierChange={setTier}
        customerId={customerId}
        onCustomerChange={setCustomerId}
        customers={customers.data}
        branchId={branchId}
        invoiceDiscount={invoiceDiscount}
        onInvoiceDiscountChange={setInvoiceDiscount}
        onQty={setQty}
        onLineDiscount={setLineDiscount}
        onRemove={(id) => setQty(id, 0)}
        onClear={() => setConfirmClear(true)}
        onHold={holdBill}
        onQuote={saveQuote}
        onCheckout={() => setCheckoutOpen(true)}
        heldCount={held.length}
        onOpenHeld={() => setHeldOpen(true)}
      />

      <PosCheckoutDialog
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        total={totals.total}
        customer={customer}
        onConfirm={confirmCheckout}
      />
      <PosReceiptDialog
        sale={sale}
        onClose={() => {
          setSale(null)
          resetCart()
        }}
      />
      <ConfirmDialog
        open={confirmClear}
        onOpenChange={setConfirmClear}
        title="تفريغ الفاتورة؟"
        description="سيتم حذف جميع الأصناف من الفاتورة الحالية. لا يمكن التراجع عن هذا الإجراء."
        confirmLabel="تفريغ"
        destructive
        onConfirm={() => {
          resetCart()
          setConfirmClear(false)
        }}
      />

      <Sheet open={heldOpen} onOpenChange={setHeldOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md">
          <SheetHeader>
            <SheetTitle>الفواتير المعلقة</SheetTitle>
            <SheetDescription>فواتير محفوظة مؤقتًا في هذه الوردية</SheetDescription>
          </SheetHeader>
          <div className="flex flex-col gap-3 overflow-y-auto px-4 pb-4">
            {held.length === 0 ? (
              <Empty className="border border-dashed">
                <EmptyHeader>
                  <EmptyTitle>لا توجد فواتير معلقة</EmptyTitle>
                  <EmptyDescription>
                    استخدم زر &quot;تعليق&quot; أو <span className="num">F8</span> لحفظ فاتورة مؤقتًا.
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : (
              held.map((bill) => {
                const t = cartTotals(bill.lines, bill.tier, bill.invoiceDiscount)
                const name = customers.data.find((c) => c.id === bill.customerId)?.name ?? 'عميل نقدي'
                return (
                  <div key={bill.id} className="flex flex-col gap-3 rounded-lg border p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{name}</span>
                        <span className="text-xs text-muted-foreground">
                          <span className="num">{formatTime(bill.heldAt)}</span> — <span className="num">{t.count}</span> قطعة
                        </span>
                      </div>
                      <Money value={t.total} className="font-semibold" />
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1" onClick={() => resumeBill(bill)}>
                        <PlayCircle data-icon="inline-start" />
                        استكمال
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        aria-label="حذف الفاتورة المعلقة"
                        onClick={() => setHeld((h) => h.filter((b) => b.id !== bill.id))}
                      >
                        <Trash2 />
                      </Button>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}

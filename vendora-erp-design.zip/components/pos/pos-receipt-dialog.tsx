'use client'

import { Printer } from 'lucide-react'
import { useApp } from '@/components/app/app-provider'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { formatDateTime, formatMoney } from '@/lib/format'
import type { CompletedSale } from './pos-types'

export function PosReceiptDialog({ sale, onClose }: { sale: CompletedSale | null; onClose: () => void }) {
  const { branchName, userName } = useApp()

  return (
    <Dialog open={!!sale} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader className="no-print">
          <DialogTitle>{sale?.isQuote ? 'تم حفظ عرض السعر' : 'تمت عملية البيع'}</DialogTitle>
          <DialogDescription>راجع الإيصال قبل الطباعة.</DialogDescription>
        </DialogHeader>
        {sale && (
          <div className="print-area flex flex-col gap-3 rounded-lg border bg-card p-4 text-sm">
            <div className="flex flex-col items-center gap-0.5 text-center">
              <span className="font-bold">فيندورا المصرية الألمانية</span>
              <span className="text-xs text-muted-foreground">{branchName}</span>
              <span className="mt-1 text-xs font-semibold">{sale.isQuote ? 'عرض سعر' : 'فاتورة بيع'}</span>
            </div>
            <dl className="flex flex-col gap-0.5 text-xs">
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">الرقم</dt>
                <dd className="num">{sale.number}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">التاريخ</dt>
                <dd className="num">{formatDateTime(sale.date)}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">العميل</dt>
                <dd>{sale.customerName}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-muted-foreground">الكاشير</dt>
                <dd>{userName}</dd>
              </div>
            </dl>
            <Separator />
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground">
                  <th className="pb-1 text-start font-normal">الصنف</th>
                  <th className="pb-1 text-center font-normal">كمية</th>
                  <th className="pb-1 text-end font-normal">القيمة</th>
                </tr>
              </thead>
              <tbody>
                {sale.lines.map((l) => (
                  <tr key={l.name} className="align-top">
                    <td className="py-0.5 pe-2">{l.name}</td>
                    <td className="num py-0.5 text-center">{l.qty}</td>
                    <td className="num py-0.5 text-end">{formatMoney(l.qty * l.price - l.discount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Separator />
            <dl className="flex flex-col gap-0.5 text-xs">
              <div className="flex justify-between gap-3">
                <dt>الإجمالي</dt>
                <dd className="num">{formatMoney(sale.subtotal)}</dd>
              </div>
              {sale.discount > 0 && (
                <>
                  <div className="flex justify-between gap-3">
                    <dt>الخصم</dt>
                    <dd className="num">- {formatMoney(sale.discount)}</dd>
                  </div>
                </>
              )}
              <div className="flex justify-between gap-3">
                <dt className="text-sm font-bold">الصافي</dt>
                <dd className="num  text-sm font-bold">{formatMoney(sale.total)} ج.م</dd>
              </div>
              {!sale.isQuote && (
                <>
                  <div className="flex justify-between gap-3">
                    <dt>طريقة الدفع</dt>
                    <dd>{sale.method}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt>المدفوع</dt>
                    <dd className="num">{formatMoney(sale.paid)}</dd>
                  </div>
                  {sale.change > 0 && (
                    <>
                      <div className="flex justify-between gap-3">
                        <dt>الباقي</dt>
                        <dd className="num">{formatMoney(sale.change)}</dd>
                      </div>
                    </>
                  )}
                  {sale.method === 'آجل' && (
                    <>
                      <div className="flex justify-between gap-3">
                        <dt>على الحساب</dt>
                        <dd className="num">{formatMoney(sale.total - sale.paid)}</dd>
                      </div>
                    </>
                  )}
                </>
              )}
            </dl>
            <p className="text-center text-[11px] text-muted-foreground">
              {sale.isQuote ? 'عرض السعر ساري لمدة 7 أيام' : 'الاستبدال والاسترجاع خلال 14 يومًا بأصل الفاتورة'}
            </p>
          </div>
        )}
        <DialogFooter className="no-print">
          <Button variant="outline" onClick={onClose}>
            فاتورة جديدة
          </Button>
          <Button onClick={() => window.print()}>
            <Printer data-icon="inline-start" />
            طباعة
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

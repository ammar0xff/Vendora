'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useTheme } from 'next-themes'
import { Bell, Building2, Clock, FlaskConical, LogOut, Menu, Moon, Sun, UserRound } from 'lucide-react'
import { useApp, type PreviewState } from '@/components/app/app-provider'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { BRANCHES } from '@/lib/mock-data'
import { ROLES, type RoleId } from '@/lib/permissions'
import { formatTime } from '@/lib/format'

const PREVIEW_OPTIONS: { value: PreviewState; label: string }[] = [
  { value: 'live', label: 'بيانات فعلية' },
  { value: 'loading', label: 'حالة التحميل' },
  { value: 'empty', label: 'حالة فارغة' },
  { value: 'error', label: 'حالة خطأ' },
]

export function AppTopbar({ onOpenMenu }: { onOpenMenu: () => void }) {
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const { userName, roleLabel, roleId, setRoleId, branchId, branchName, setBranchId, preview, setPreview, shift } =
    useApp()

  return (
    <header className="no-print sticky top-0 z-30 flex h-16 items-center gap-2 border-b bg-background/90 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/75 md:px-6">
      <Button variant="ghost" size="icon" className="lg:hidden" onClick={onOpenMenu} aria-label="فتح القائمة">
        <Menu />
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger render={<Button variant="outline" size="sm" />}>
          <Building2 data-icon="inline-start" />
          <span className="max-w-32 truncate">{branchName}</span>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-52">
          <DropdownMenuGroup>
            <DropdownMenuLabel>الفرع الحالي</DropdownMenuLabel>
            <DropdownMenuRadioGroup value={branchId} onValueChange={(v) => setBranchId(String(v))}>
              {BRANCHES.map((b) => (
                <DropdownMenuRadioItem key={b.id} value={b.id}>
                  {b.name}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuGroup>
        </DropdownMenuContent>
      </DropdownMenu>

      <Link href="/shifts" className="hidden sm:block">
        {shift ? (
          <Badge variant="success" className="h-7 gap-1.5 px-2.5">
            <span className="size-1.5 rounded-full bg-success" aria-hidden />
            وردية مفتوحة منذ <span className="num">{formatTime(shift.openedAt)}</span>
          </Badge>
        ) : (
          <Badge variant="secondary" className="h-7 gap-1.5 px-2.5">
            <Clock className="size-3" aria-hidden />
            لا توجد وردية
          </Badge>
        )}
      </Link>

      <div className="ms-auto flex items-center gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger
            render={<Button variant={preview === 'live' ? 'ghost' : 'secondary'} size="sm" />}
            aria-label="محاكاة حالات الواجهة"
          >
            <FlaskConical data-icon="inline-start" />
            <span className="hidden md:inline">{PREVIEW_OPTIONS.find((p) => p.value === preview)?.label}</span>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuGroup>
              <DropdownMenuLabel>محاكاة حالة البيانات</DropdownMenuLabel>
              <DropdownMenuRadioGroup value={preview} onValueChange={(v) => setPreview(v as PreviewState)}>
                {PREVIEW_OPTIONS.map((p) => (
                  <DropdownMenuRadioItem key={p.value} value={p.value}>
                    {p.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button
          variant="ghost"
          size="icon"
          aria-label="تبديل الوضع الليلي"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        >
          <Sun className="dark:hidden" />
          <Moon className="hidden dark:block" />
        </Button>

        <Button variant="ghost" size="icon" aria-label="التنبيهات — 3 جديدة" className="relative">
          <Bell />
          <span className="absolute end-2 top-2 size-2 rounded-full bg-destructive" aria-hidden />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger
            render={<Button variant="ghost" className="h-10 gap-2 px-2" />}
            aria-label="قائمة المستخدم"
          >
            <Avatar className="size-8">
              <AvatarFallback>{userName.split(' ')[0].slice(0, 2)}</AvatarFallback>
            </Avatar>
            <span className="hidden flex-col items-start leading-tight md:flex">
              <span className="text-sm font-medium">{userName}</span>
              <span className="text-xs text-muted-foreground">{roleLabel}</span>
            </span>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-60">
            <DropdownMenuGroup>
              <DropdownMenuLabel>تجربة الصلاحيات حسب الدور</DropdownMenuLabel>
              <DropdownMenuRadioGroup value={roleId} onValueChange={(v) => setRoleId(v as RoleId)}>
                {ROLES.map((r) => (
                  <DropdownMenuRadioItem key={r.id} value={r.id}>
                    {r.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem onClick={() => router.push('/settings')}>
                <UserRound />
                الملف الشخصي
              </DropdownMenuItem>
              <DropdownMenuItem variant="destructive" onClick={() => router.push('/')}>
                <LogOut />
                تسجيل الخروج
              </DropdownMenuItem>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

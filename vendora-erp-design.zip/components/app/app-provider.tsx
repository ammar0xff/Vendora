'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { BRANCHES } from '@/lib/mock-data'
import type { PaymentMethod } from '@/lib/mock-data'
import { getRole, type RoleId } from '@/lib/permissions'

export type PreviewState = 'live' | 'loading' | 'empty' | 'error'

export type ActiveShift = {
  id: string
  openedAt: string
  openingCash: number
  cashSales: number
  walletSales: number
  creditSales: number
  transferSales: number
  invoices: number
  refunds: number
}

const ROLE_USERS: Record<RoleId, string> = {
  admin: 'عمرو الجندي',
  manager: 'طارق سمير',
  accountant: 'رانيا فتحي',
  storekeeper: 'خالد إبراهيم',
  cashier: 'منى عادل',
}

type AppContextValue = {
  roleId: RoleId
  setRoleId: (id: RoleId) => void
  userName: string
  roleLabel: string
  branchId: string
  branchName: string
  setBranchId: (id: string) => void
  preview: PreviewState
  setPreview: (s: PreviewState) => void
  shift: ActiveShift | null
  openShift: (openingCash: number) => void
  closeShift: () => void
  recordSale: (total: number, method: PaymentMethod) => void
  recordRefund: (amount: number) => void
}

const AppContext = createContext<AppContextValue | null>(null)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [roleId, setRoleId] = useState<RoleId>('manager')
  const [branchId, setBranchId] = useState('maadi')
  const [preview, setPreview] = useState<PreviewState>('live')
  const [shift, setShift] = useState<ActiveShift | null>({
    id: 'SH-0889',
    openedAt: '2026-10-25T09:00:00',
    openingCash: 2000,
    cashSales: 8319.5,
    walletSales: 4925,
    creditSales: 0,
    transferSales: 0,
    invoices: 3,
    refunds: 0,
  })

  const openShift = useCallback((openingCash: number) => {
    setShift({
      id: `SH-${Math.floor(890 + Math.random() * 100)
        .toString()
        .padStart(4, '0')}`,
      openedAt: new Date().toISOString(),
      openingCash,
      cashSales: 0,
      walletSales: 0,
      creditSales: 0,
      transferSales: 0,
      invoices: 0,
      refunds: 0,
    })
  }, [])

  const closeShift = useCallback(() => setShift(null), [])

  const recordSale = useCallback((total: number, method: PaymentMethod) => {
    setShift((s) => {
      if (!s) return s
      const next = { ...s, invoices: s.invoices + 1 }
      if (method === 'نقدي') next.cashSales += total
      if (method === 'محفظة') next.walletSales += total
      if (method === 'آجل') next.creditSales += total
      if (method === 'تحويل بنكي') next.transferSales += total
      return next
    })
  }, [])

  const recordRefund = useCallback((amount: number) => {
    setShift((s) => (s ? { ...s, refunds: s.refunds + amount } : s))
  }, [])

  const value = useMemo<AppContextValue>(
    () => ({
      roleId,
      setRoleId,
      userName: ROLE_USERS[roleId],
      roleLabel: getRole(roleId).label,
      branchId,
      branchName: BRANCHES.find((b) => b.id === branchId)?.name ?? '',
      setBranchId,
      preview,
      setPreview,
      shift,
      openShift,
      closeShift,
      recordSale,
      recordRefund,
    }),
    [roleId, branchId, preview, shift, openShift, closeShift, recordSale, recordRefund],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}

export function expectedCash(shift: ActiveShift) {
  return shift.openingCash + shift.cashSales - shift.refunds
}

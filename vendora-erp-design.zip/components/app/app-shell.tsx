'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import { Lock } from 'lucide-react'
import { useApp } from '@/components/app/app-provider'
import { AppSidebar } from '@/components/app/app-sidebar'
import { AppTopbar } from '@/components/app/app-topbar'
import { Button } from '@/components/ui/button'
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { Sheet, SheetContent, SheetTitle } from '@/components/ui/sheet'
import { NAV_ITEMS, canAccess, featureForPath } from '@/lib/permissions'

export function AppShell({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const pathname = usePathname()
  const { roleId, roleLabel } = useApp()
  const feature = featureForPath(pathname)
  const allowed = !feature || canAccess(roleId, feature)
  const fallback = NAV_ITEMS.find((n) => canAccess(roleId, n.feature))

  return (
    <div className="flex min-h-svh">
      <aside className="no-print sticky top-0 hidden h-svh w-64 shrink-0 lg:block">
        <AppSidebar />
      </aside>
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side="right" className="w-72 p-0" showCloseButton={false}>
          <SheetTitle className="sr-only">القائمة الرئيسية</SheetTitle>
          <AppSidebar onNavigate={() => setMenuOpen(false)} />
        </SheetContent>
      </Sheet>
      <div className="flex min-w-0 flex-1 flex-col">
        <AppTopbar onOpenMenu={() => setMenuOpen(true)} />
        <main className="flex-1 px-4 py-6 md:px-6 lg:px-8">
          {allowed ? (
            children
          ) : (
            <Empty className="mx-auto mt-16 max-w-md border border-dashed">
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <Lock />
                </EmptyMedia>
                <EmptyTitle>لا تملك صلاحية الوصول</EmptyTitle>
                <EmptyDescription>
                  دور «{roleLabel}» لا يتضمن هذه الشاشة. تواصل مع مدير النظام لتعديل الصلاحيات.
                </EmptyDescription>
              </EmptyHeader>
              {fallback && (
                <EmptyContent>
                  <Button nativeButton={false} render={<Link href={fallback.href} />}>
                    الانتقال إلى {fallback.label}
                  </Button>
                </EmptyContent>
              )}
            </Empty>
          )}
        </main>
      </div>
    </div>
  )
}

'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Droplets } from 'lucide-react'
import { useApp } from '@/components/app/app-provider'
import { NAV_GROUPS, NAV_ITEMS, canAccess, type NavItem } from '@/lib/permissions'
import { cn } from '@/lib/utils'

export function AppSidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname()
  const { roleId } = useApp()
  const visible = NAV_ITEMS.filter((n) => canAccess(roleId, n.feature))
  const groups = (Object.keys(NAV_GROUPS) as NavItem['group'][])
    .map((g) => ({ id: g, label: NAV_GROUPS[g], items: visible.filter((n) => n.group === g) }))
    .filter((g) => g.items.length > 0)

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-5">
        <span className="flex size-9 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
          <Droplets className="size-5" aria-hidden />
        </span>
        <div className="flex flex-col leading-tight">
          <span className="font-semibold">فيندورا</span>
          <span className="text-xs text-sidebar-foreground/60">المصرية الألمانية</span>
        </div>
      </div>
      <nav aria-label="القائمة الرئيسية" className="flex-1 overflow-y-auto px-3 py-4">
        <div className="flex flex-col gap-5">
          {groups.map((group) => (
            <div key={group.id} className="flex flex-col gap-1">
              <p className="px-3 pb-1 text-[11px] font-medium text-sidebar-foreground/50">{group.label}</p>
              {group.items.map((item) => {
                const active = pathname === item.href || pathname.startsWith(`${item.href}/`)
                const Icon = item.icon
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={onNavigate}
                    aria-current={active ? 'page' : undefined}
                    className={cn(
                      'flex items-center gap-3 rounded-md px-3 py-2 text-sm text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:outline-2 focus-visible:outline-sidebar-ring',
                      active && 'bg-sidebar-accent font-medium text-sidebar-accent-foreground',
                    )}
                  >
                    <Icon className={cn('size-4 shrink-0', active && 'text-sidebar-primary')} aria-hidden />
                    <span className="truncate">{item.label}</span>
                  </Link>
                )
              })}
            </div>
          ))}
        </div>
      </nav>
      <div className="border-t border-sidebar-border px-5 py-3 text-[11px] text-sidebar-foreground/50">
        الإصدار <span className="num">2.4.0</span>
      </div>
    </div>
  )
}

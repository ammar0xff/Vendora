'use client'

import { useMemo, useState } from 'react'
import { Contact, HandCoins, Truck, Users } from 'lucide-react'
import { toast } from 'sonner'
import { ListState, Money, PageHeader, SearchField, StatCard, TableShell } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useMock } from '@/hooks/use-mock'
import { formatDate } from '@/lib/format'
import type { FinanceEntry } from '@/lib/mock-data'
import { PaymentDialog, type PaymentTarget } from './payment-dialog'

export function PartiesView() {
  const customers = useMock('customers')
  const suppliers = useMock('suppliers')
  const treasuries = useMock('treasuries')
  const finance = useMock('finance')
  const [query, setQuery] = useState('')
  const [target, setTarget] = useState<PaymentTarget | null>(null)

  const q = query.trim()
  const customerRows = useMemo(
    () => customers.data.filter((c) => !q || c.name.includes(q) || c.phone.includes(q)),
    [customers.data, q],
  )
  const supplierRows = useMemo(
    () => suppliers.data.filter((s) => !q || s.name.includes(q) || s.phone.includes(q)),
    [suppliers.data, q],
  )
  const receivables = customers.data.reduce((s, c) => s + c.balance, 0)
  const payables = suppliers.data.reduce((s, x) => s + x.balance, 0)
  const overLimit = customers.data.filter((c) => c.creditLimit > 0 && c.balance > c.creditLimit).length

  function confirmPayment(amount: number, treasuryId: string) {
    if (!target) return
    const treasury = treasuries.data.find((t) => t.id === treasuryId)
    const collect = target.kind === 'collect'
    if (collect) {
      customers.mutate(customers.data.map((c) => (c.id === target.id ? { ...c, balance: c.balance - amount } : c)))
    } else {
      suppliers.mutate(suppliers.data.map((s) => (s.id === target.id ? { ...s, balance: s.balance - amount } : s)))
    }
    treasuries.mutate(
      treasuries.data.map((t) => (t.id === treasuryId ? { ...t, balance: t.balance + (collect ? amount : -amount) } : t)),
    )
    const entry: FinanceEntry = {
      id: `f${Date.now()}`,
      date: new Date().toISOString(),
      description: `${collect ? 'تحصيل من' : 'سداد إلى'} ${target.name}`,
      category: collect ? 'تحصيل عملاء' : 'سداد موردين',
      treasury: treasury?.name ?? '',
      amount,
      kind: collect ? 'إيراد' : 'مصروف',
      user: 'المستخدم الحالي',
    }
    finance.mutate([entry, ...finance.data])
    toast.success(collect ? 'تم تسجيل التحصيل' : 'تم تسجيل السداد', { description: `${target.name} — ${treasury?.name ?? ''}` })
    setTarget(null)
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="العملاء والموردون" description="الأرصدة، حدود الائتمان، التحصيل والسداد" />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="مستحقات على العملاء" value={<Money value={receivables} />} icon={HandCoins} tone="warning" />
        <StatCard label="مستحقات للموردين" value={<Money value={payables} />} icon={Truck} tone="destructive" />
        <StatCard
          label="عملاء تجاوزوا الحد"
          value={<span className="num">{overLimit}</span>}
          icon={Users}
          tone={overLimit > 0 ? 'destructive' : 'success'}
          hint="يُمنع البيع الآجل لهم من نقطة البيع"
        />
      </div>

      <Tabs defaultValue="customers" className="flex flex-col gap-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <TabsList>
            <TabsTrigger value="customers">العملاء</TabsTrigger>
            <TabsTrigger value="suppliers">الموردون</TabsTrigger>
          </TabsList>
          <SearchField value={query} onChange={setQuery} placeholder="ابحث بالاسم أو الهاتف" />
        </div>

        <TabsContent value="customers">
          <ListState
            status={customers.status}
            isEmpty={customerRows.length === 0}
            onRetry={customers.retry}
            emptyIcon={Contact}
            emptyTitle="لا يوجد عملاء مطابقون"
            emptyDescription="جرّب كلمة بحث أخرى."
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>العميل</TableHead>
                    <TableHead className="hidden md:table-cell">النوع</TableHead>
                    <TableHead>الرصيد</TableHead>
                    <TableHead className="hidden lg:table-cell">استخدام الائتمان</TableHead>
                    <TableHead className="hidden md:table-cell">آخر شراء</TableHead>
                    <TableHead className="w-24">
                      <span className="sr-only">إجراءات</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customerRows.map((c) => {
                    const usage = c.creditLimit > 0 ? Math.round((c.balance / c.creditLimit) * 100) : 0
                    return (
                      <TableRow key={c.id}>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">{c.name}</span>
                            <span className="num text-xs text-muted-foreground" dir="ltr">
                              {c.phone}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <Badge variant="outline">{c.type}</Badge>
                        </TableCell>
                        <TableCell>
                          <Money value={c.balance} />
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          {c.creditLimit > 0 ? (
                            <div className="flex min-w-40 items-center gap-2">
                              <Progress value={Math.min(usage, 100)} aria-label={`استخدام ائتمان ${c.name}`} className="flex-1" />
                              <Badge variant={usage > 100 ? 'destructive' : usage > 80 ? 'warning' : 'secondary'}>
                                <span className="num">{usage}%</span>
                              </Badge>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">نقدي فقط</span>
                          )}
                        </TableCell>
                        <TableCell className="num hidden md:table-cell">{formatDate(c.lastPurchase)}</TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={c.balance <= 0 || treasuries.status !== 'ready'}
                            onClick={() => setTarget({ id: c.id, name: c.name, balance: c.balance, kind: 'collect' })}
                          >
                            تحصيل
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>

        <TabsContent value="suppliers">
          <ListState
            status={suppliers.status}
            isEmpty={supplierRows.length === 0}
            onRetry={suppliers.retry}
            emptyIcon={Truck}
            emptyTitle="لا يوجد موردون مطابقون"
            emptyDescription="جرّب كلمة بحث أخرى."
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المورد</TableHead>
                    <TableHead className="hidden md:table-cell">الفئة</TableHead>
                    <TableHead>المستحق له</TableHead>
                    <TableHead className="hidden md:table-cell">آخر توريد</TableHead>
                    <TableHead className="w-24">
                      <span className="sr-only">إجراءات</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {supplierRows.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{s.name}</span>
                          <span className="num text-xs text-muted-foreground" dir="ltr">
                            {s.phone}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{s.category}</TableCell>
                      <TableCell>
                        <Money value={s.balance} />
                      </TableCell>
                      <TableCell className="num hidden md:table-cell">{formatDate(s.lastOrder)}</TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={s.balance <= 0 || treasuries.status !== 'ready'}
                          onClick={() => setTarget({ id: s.id, name: s.name, balance: s.balance, kind: 'pay' })}
                        >
                          سداد
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>
      </Tabs>

      <PaymentDialog
        target={target}
        treasuries={treasuries.data}
        onOpenChange={(o) => !o && setTarget(null)}
        onConfirm={confirmPayment}
      />
    </div>
  )
}

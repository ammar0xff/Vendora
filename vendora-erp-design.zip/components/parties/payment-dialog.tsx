'use client'

import { useState } from 'react'
import { Money, SimpleSelect } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import type { Treasury } from '@/lib/mock-data'

export type PaymentTarget = { id: string; name: string; balance: number; kind: 'collect' | 'pay' }

export function PaymentDialog({
  target,
  treasuries,
  onOpenChange,
  onConfirm,
}: {
  target: PaymentTarget | null
  treasuries: Treasury[]
  onOpenChange: (open: boolean) => void
  onConfirm: (amount: number, treasuryId: string) => void
}) {
  return (
    <Dialog open={target !== null} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        {target && (
          <PaymentForm key={target.id} target={target} treasuries={treasuries} onCancel={() => onOpenChange(false)} onConfirm={onConfirm} />
        )}
      </DialogContent>
    </Dialog>
  )
}

function PaymentForm({
  target,
  treasuries,
  onCancel,
  onConfirm,
}: {
  target: PaymentTarget
  treasuries: Treasury[]
  onCancel: () => void
  onConfirm: (amount: number, treasuryId: string) => void
}) {
  const [amount, setAmount] = useState(String(target.balance))
  const [treasuryId, setTreasuryId] = useState(treasuries[0]?.id ?? '')
  const value = Number(amount)
  const treasury = treasuries.find((t) => t.id === treasuryId)
  const overBalance = value > target.balance
  const insufficient = target.kind === 'pay' && treasury !== undefined && value > treasury.balance
  const invalid = !Number.isFinite(value) || value <= 0 || overBalance || insufficient
  const isCollect = target.kind === 'collect'

  return (
    <form
      className="flex flex-col gap-6"
      onSubmit={(e) => {
        e.preventDefault()
        if (!invalid) onConfirm(value, treasuryId)
      }}
    >
      <DialogHeader>
        <DialogTitle>{isCollect ? 'تحصيل دفعة' : 'سداد دفعة'}</DialogTitle>
        <DialogDescription>
          {target.name} — الرصيد الحالي <Money value={target.balance} />
        </DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <Field data-invalid={overBalance || insufficient || undefined}>
          <FieldLabel htmlFor="pay-amount">المبلغ</FieldLabel>
          <Input
            id="pay-amount"
            type="number"
            inputMode="decimal"
            min={0}
            step="0.01"
            dir="ltr"
            className="num text-start"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            aria-invalid={overBalance || insufficient || undefined}
          />
          {overBalance && <FieldDescription>المبلغ أكبر من الرصيد المستحق.</FieldDescription>}
          {insufficient && <FieldDescription>رصيد الخزينة المختارة لا يكفي.</FieldDescription>}
        </Field>
        <Field>
          <FieldLabel htmlFor="pay-treasury">{isCollect ? 'إيداع في' : 'الصرف من'}</FieldLabel>
          <SimpleSelect
            id="pay-treasury"
            value={treasuryId}
            onValueChange={setTreasuryId}
            options={treasuries.map((t) => ({ value: t.id, label: t.name }))}
          />
          {treasury && (
            <FieldDescription>
              رصيد الخزينة: <Money value={treasury.balance} />
            </FieldDescription>
          )}
        </Field>
      </FieldGroup>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button type="submit" disabled={invalid}>
          {isCollect ? 'تأكيد التحصيل' : 'تأكيد السداد'}
        </Button>
      </DialogFooter>
    </form>
  )
}

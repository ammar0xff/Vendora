'use client'

import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts'
import { Download, Percent, Receipt, TrendingUp, Undo2 } from 'lucide-react'
import { toast } from 'sonner'
import { Money, Num, PageHeader, StatCard, TableShell } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { Progress } from '@/components/ui/progress'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { useMock } from '@/hooks/use-mock'
import { BRANCH_SALES, CATEGORY_SALES, SALES_TREND } from '@/lib/mock-data'

const RANGES = { '7': 7, '14': 14 } as const
type Range = keyof typeof RANGES

const trendConfig = {
  sales: { label: 'المبيعات', color: 'var(--chart-1)' },
  returns: { label: 'المرتجعات', color: 'var(--chart-4)' },
} satisfies ChartConfig

const branchConfig = { sales: { label: 'المبيعات', color: 'var(--chart-2)' } } satisfies ChartConfig

export function ReportsView() {
  const products = useMock('products')
  const [range, setRange] = useState<Range>('14')

  const trend = SALES_TREND.slice(-RANGES[range])
  const totals = useMemo(() => {
    const sales = trend.reduce((s, d) => s + d.sales, 0)
    const returns = trend.reduce((s, d) => s + d.returns, 0)
    return { sales, returns, avg: sales / trend.length }
  }, [trend])

  const margins = useMemo(
    () =>
      products.data
        .filter((p) => p.active && p.price > 0)
        .map((p) => ({ id: p.id, name: p.name, margin: Math.round(((p.price - p.cost) / p.price) * 100), price: p.price }))
        .sort((a, b) => b.margin - a.margin)
        .slice(0, 6),
    [products.data],
  )

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="التقارير"
        description="أداء المبيعات والفروع والأصناف"
        actions={
          <>
            <ToggleGroup
              value={[range]}
              onValueChange={(v) => v[0] && setRange(v[0] as Range)}
              variant="outline"
              aria-label="الفترة"
            >
              <ToggleGroupItem value="7">آخر 7 أيام</ToggleGroupItem>
              <ToggleGroupItem value="14">آخر 14 يومًا</ToggleGroupItem>
            </ToggleGroup>
            <Button variant="outline" onClick={() => toast.success('جارٍ تصدير التقرير', { description: 'سيتم تنزيل ملف Excel خلال لحظات' })}>
              <Download data-icon="inline-start" />
              تصدير
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="صافي المبيعات" value={<Money value={totals.sales - totals.returns} />} icon={TrendingUp} tone="success" />
        <StatCard label="متوسط يومي" value={<Money value={totals.avg} />} icon={Receipt} />
        <StatCard
          label="نسبة المرتجعات"
          value={<Num value={`${((totals.returns / totals.sales) * 100).toFixed(1)}%`} />}
          icon={Undo2}
          tone="warning"
          hint={<Money value={totals.returns} />}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>المبيعات اليومية</CardTitle>
          <CardDescription>المبيعات مقابل المرتجعات لجميع الفروع</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={trendConfig} className="aspect-auto h-72 w-full" dir="ltr">
            <BarChart data={trend} margin={{ left: 8, right: 8, top: 8 }}>
              <CartesianGrid vertical={false} />
              <XAxis dataKey="day" tickLine={false} axisLine={false} tickMargin={8} reversed />
              <YAxis
                orientation="right"
                tickLine={false}
                axisLine={false}
                width={48}
                tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="sales" fill="var(--color-sales)" radius={4} />
              <Bar dataKey="returns" fill="var(--color-returns)" radius={4} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>المبيعات حسب الفرع</CardTitle>
            <CardDescription>الشهر الحالي</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={branchConfig} className="aspect-auto h-56 w-full" dir="ltr">
              <BarChart data={BRANCH_SALES} layout="vertical" margin={{ left: 8, right: 8 }}>
                <XAxis type="number" hide reversed />
                <YAxis type="category" dataKey="branch" orientation="right" tickLine={false} axisLine={false} width={80} />
                <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                <Bar dataKey="sales" fill="var(--color-sales)" radius={4} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>حصة الفئات من المبيعات</CardTitle>
            <CardDescription>نسبة مئوية من إجمالي الإيراد</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            {CATEGORY_SALES.map((c) => (
              <div key={c.category} className="flex flex-col gap-2">
                <div className="flex items-center justify-between text-sm">
                  <span>{c.category}</span>
                  <span className="num text-muted-foreground">{c.value}%</span>
                </div>
                <Progress value={c.value} aria-label={`حصة ${c.category}`} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Percent className="size-4 text-muted-foreground" aria-hidden />
            أعلى الأصناف ربحية
          </CardTitle>
          <CardDescription>هامش الربح على سعر البيع الحالي</CardDescription>
        </CardHeader>
        <CardContent>
          <TableShell>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الصنف</TableHead>
                  <TableHead>سعر البيع</TableHead>
                  <TableHead>الهامش</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {margins.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="font-medium">{m.name}</TableCell>
                    <TableCell>
                      <Money value={m.price} />
                    </TableCell>
                    <TableCell className="num">{m.margin}%</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableShell>
        </CardContent>
      </Card>
    </div>
  )
}

'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { SimpleSelect } from '@/components/app/shared'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput } from '@/components/ui/input-group'
import { Spinner } from '@/components/ui/spinner'
import { ROLES, type RoleId } from '@/lib/permissions'

export function LoginForm() {
  const router = useRouter()
  const { setRoleId } = useApp()
  const [username, setUsername] = useState('tarek')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [role, setRole] = useState<RoleId>('manager')
  const [errors, setErrors] = useState<{ username?: string; password?: string; form?: string }>({})
  const [submitting, setSubmitting] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const next: typeof errors = {}
    if (!username.trim()) next.username = 'من فضلك أدخل اسم المستخدم'
    if (!password) next.password = 'من فضلك أدخل كلمة المرور'
    else if (password.length < 6) next.password = 'كلمة المرور يجب ألا تقل عن 6 أحرف'
    setErrors(next)
    if (Object.keys(next).length) return
    setSubmitting(true)
    setTimeout(() => {
      if (password === 'wrong1') {
        setSubmitting(false)
        setErrors({ form: 'اسم المستخدم أو كلمة المرور غير صحيحة' })
        return
      }
      setRoleId(role)
      toast.success('تم تسجيل الدخول بنجاح')
      router.push(role === 'cashier' ? '/pos' : '/dashboard')
    }, 600)
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-6">
      {errors.form && (
        <Alert variant="destructive">
          <AlertDescription>{errors.form}</AlertDescription>
        </Alert>
      )}
      <FieldGroup>
        <Field data-invalid={!!errors.username || undefined}>
          <FieldLabel htmlFor="username">اسم المستخدم</FieldLabel>
          <Input
            id="username"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            aria-invalid={!!errors.username || undefined}
          />
          {errors.username && <FieldError>{errors.username}</FieldError>}
        </Field>
        <Field data-invalid={!!errors.password || undefined}>
          <FieldLabel htmlFor="password">كلمة المرور</FieldLabel>
          <InputGroup>
            <InputGroupInput
              id="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              aria-invalid={!!errors.password || undefined}
            />
            <InputGroupAddon align="inline-end">
              <InputGroupButton
                size="icon-xs"
                aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                aria-pressed={showPassword}
                onClick={() => setShowPassword((v) => !v)}
              >
                {showPassword ? <EyeOff /> : <Eye />}
              </InputGroupButton>
            </InputGroupAddon>
          </InputGroup>
          {errors.password && <FieldError>{errors.password}</FieldError>}
        </Field>
        <Field>
          <FieldLabel htmlFor="role">الدخول بدور (للتجربة)</FieldLabel>
          <SimpleSelect
            id="role"
            value={role}
            onValueChange={(v) => setRole(v as RoleId)}
            options={ROLES.map((r) => ({ value: r.id, label: r.label }))}
            className="w-full"
          />
          <FieldDescription>{ROLES.find((r) => r.id === role)?.description}</FieldDescription>
        </Field>
      </FieldGroup>
      <Button type="submit" size="lg" disabled={submitting}>
        {submitting && <Spinner data-icon="inline-start" />}
        {submitting ? 'جارٍ الدخول…' : 'دخول'}
      </Button>
      <Alert>
        <AlertDescription>
          نسخة عرض: أي كلمة مرور من 6 أحرف تعمل، واكتب <span className="num">wrong1</span> لمعاينة رسالة الخطأ.
        </AlertDescription>
      </Alert>
    </form>
  )
}

'use client'

import { useState } from 'react'
import { LockOpen } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { InputGroup, InputGroupAddon, InputGroupInput, InputGroupText } from '@/components/ui/input-group'

export function OpenShiftCard({ description }: { description?: string }) {
  const { openShift, userName, branchName } = useApp()
  const [amount, setAmount] = useState('2000')
  const [error, setError] = useState('')

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const value = Number(amount)
    if (amount.trim() === '' || Number.isNaN(value)) return setError('أدخل رصيد افتتاحي صحيح')
    if (value < 0) return setError('الرصيد الافتتاحي لا يمكن أن يكون سالبًا')
    setError('')
    openShift(value)
    toast.success('تم فتح الوردية', { description: `${branchName} — ${userName}` })
  }

  return (
    <Card className="mx-auto w-full max-w-md">
      <form onSubmit={submit} noValidate className="contents">
        <CardHeader>
          <CardTitle>لا توجد وردية مفتوحة</CardTitle>
          <CardDescription>
            {description ?? 'لا يمكن تسجيل أي عملية بيع قبل فتح وردية. أدخل النقدية الموجودة في الدرج لبدء العمل.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <Field data-invalid={!!error || undefined}>
              <FieldLabel htmlFor="opening-cash">الرصيد الافتتاحي للدرج</FieldLabel>
              <InputGroup>
                <InputGroupInput
                  id="opening-cash"
                  inputMode="decimal"
                  className="num"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  aria-invalid={!!error || undefined}
                  autoFocus
                />
                <InputGroupAddon align="inline-end">
                  <InputGroupText>ج.م</InputGroupText>
                </InputGroupAddon>
              </InputGroup>
              {error ? (
                <FieldError>{error}</FieldError>
              ) : (
                <FieldDescription>
                  الكاشير: {userName} — {branchName}
                </FieldDescription>
              )}
            </Field>
          </FieldGroup>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">
            <LockOpen data-icon="inline-start" />
            فتح الوردية
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

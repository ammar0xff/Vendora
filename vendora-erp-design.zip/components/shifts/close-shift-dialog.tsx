'use client'

import { useState } from 'react'
import { Money } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'

export function CloseShiftDialog({
  open,
  onOpenChange,
  expected,
  onConfirm,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  expected: number
  onConfirm: (counted: number, note: string) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">{open && <CloseForm expected={expected} onCancel={() => onOpenChange(false)} onConfirm={onConfirm} />}</DialogContent>
    </Dialog>
  )
}

function CloseForm({ expected, onCancel, onConfirm }: { expected: number; onCancel: () => void; onConfirm: (counted: number, note: string) => void }) {
  const [counted, setCounted] = useState('')
  const [note, setNote] = useState('')
  const value = counted === '' ? null : Number(counted)
  const diff = value === null ? 0 : Math.round((value - expected) * 100) / 100
  const needsNote = value !== null && diff !== 0
  const valid = value !== null && value >= 0 && (!needsNote || note.trim().length >= 5)

  return (
    <>
      <DialogHeader>
        <DialogTitle>إغلاق الوردية</DialogTitle>
        <DialogDescription>عُدّ النقدية الموجودة في الدرج وأدخلها. أي فرق يتطلب ملاحظة ويُسجل في سجل التدقيق.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <div className="flex items-center justify-between rounded-lg bg-muted/60 p-3 text-sm">
          <span className="text-muted-foreground">النقدية المتوقعة</span>
          <Money value={expected} className="font-semibold" />
        </div>
        <Field>
          <FieldLabel htmlFor="counted-cash">النقدية الفعلية</FieldLabel>
          <Input id="counted-cash" type="number" inputMode="decimal" min={0} autoFocus className="num text-lg" value={counted} onChange={(e) => setCounted(e.target.value)} />
          {value !== null && (
            <FieldDescription className="flex items-center gap-2">
              الفرق
              <Badge variant={diff === 0 ? 'success' : diff > 0 ? 'warning' : 'destructive'}>
                <span className="num">{diff > 0 ? `+${diff.toFixed(2)}` : diff.toFixed(2)}</span>
              </Badge>
              {diff === 0 ? 'مطابق' : diff > 0 ? 'زيادة' : 'عجز'}
            </FieldDescription>
          )}
        </Field>
        {needsNote && (
          <Field data-invalid={note.trim().length < 5 || undefined}>
            <FieldLabel htmlFor="shift-note">سبب الفرق</FieldLabel>
            <Textarea id="shift-note" value={note} aria-invalid={note.trim().length < 5} onChange={(e) => setNote(e.target.value)} />
            {note.trim().length < 5 && <FieldError>اكتب سببًا واضحًا للفرق</FieldError>}
          </Field>
        )}
      </FieldGroup>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          رجوع
        </Button>
        <Button variant={needsNote ? 'destructive' : 'default'} disabled={!valid} onClick={() => value !== null && onConfirm(value, note.trim())}>
          إغلاق وطباعة التقرير
        </Button>
      </DialogFooter>
    </>
  )
}

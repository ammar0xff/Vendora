'use client'

import { useState } from 'react'
import { Banknote, Clock, CreditCard, Landmark, Lock, Receipt, Smartphone, Undo2 } from 'lucide-react'
import { toast } from 'sonner'
import { expectedCash, useApp } from '@/components/app/app-provider'
import { ListState, Money, Num, PageHeader, TableShell } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDate, formatTime } from '@/lib/format'
import { cn } from '@/lib/utils'
import { CloseShiftDialog } from './close-shift-dialog'
import { OpenShiftCard } from './open-shift-card'

export function ShiftsView() {
  const { shift, closeShift, userName, branchName, roleId } = useApp()
  const history = useMock('shifts')
  const [closing, setClosing] = useState(false)
  const rows = roleId === 'cashier' ? history.data.filter((h) => h.cashier === userName) : history.data

  function confirmClose(counted: number, note: string) {
    if (!shift) return
    const expected = expectedCash(shift)
    history.mutate([
      {
        id: shift.id,
        cashier: userName,
        branch: branchName,
        openedAt: shift.openedAt,
        closedAt: new Date().toISOString(),
        openingCash: shift.openingCash,
        expectedCash: expected,
        countedCash: counted,
        sales: shift.cashSales + shift.walletSales + shift.creditSales + shift.transferSales,
        invoices: shift.invoices,
      },
      ...history.data,
    ])
    closeShift()
    setClosing(false)
    const diff = counted - expected
    toast.success('تم إغلاق الوردية', { description: diff === 0 ? 'النقدية مطابقة' : `فرق ${diff.toFixed(2)} ج.م — ${note}` })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="الورديات" description={`${branchName} — فتح وإغلاق الوردية ومطابقة النقدية`} />

      {shift ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              الوردية الحالية
              <Badge variant="success">مفتوحة</Badge>
            </CardTitle>
            <CardDescription>
              {userName} — منذ <span className="num">{formatTime(shift.openedAt)}</span>
            </CardDescription>
            <CardAction>
              <Button variant="outline" onClick={() => setClosing(true)}>
                <Lock data-icon="inline-start" />
                إغلاق الوردية
              </Button>
            </CardAction>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Breakdown icon={Banknote} label="مبيعات نقدية" value={shift.cashSales} />
              <Breakdown icon={Smartphone} label="محافظ إلكترونية" value={shift.walletSales} />
              <Breakdown icon={Landmark} label="تحويلات بنكية" value={shift.transferSales} />
              <Breakdown icon={CreditCard} label="مبيعات آجلة" value={shift.creditSales} />
            </div>
            <Separator />
            <dl className="grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
              <Row label="رصيد افتتاحي" value={<Money value={shift.openingCash} />} />
              <Row label="مرتجعات نقدية" value={<Money value={-shift.refunds} />} icon={Undo2} />
              <Row label="عدد الفواتير" value={<Num value={shift.invoices} />} icon={Receipt} />
              <Row label="النقدية المتوقعة بالدرج" value={<Money value={expectedCash(shift)} className="font-semibold text-primary" />} />
            </dl>
          </CardContent>
          <CardFooter className="text-xs text-muted-foreground">النقدية المتوقعة = الافتتاحي + المبيعات النقدية − المرتجعات النقدية</CardFooter>
        </Card>
      ) : (
        <OpenShiftCard description="لا توجد وردية مفتوحة. افتح وردية لبدء البيع من نقطة البيع." />
      )}

      <section className="flex flex-col gap-3" aria-labelledby="history-title">
        <h2 id="history-title" className="font-semibold">
          سجل الورديات
        </h2>
        <ListState status={history.status} isEmpty={rows.length === 0} onRetry={history.retry} emptyIcon={Clock} emptyTitle="لا توجد ورديات سابقة" emptyDescription="ستظهر هنا الورديات بعد إغلاقها.">
          <TableShell>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>الكاشير</TableHead>
                  <TableHead className="hidden md:table-cell">الفرع</TableHead>
                  <TableHead className="hidden sm:table-cell">المبيعات</TableHead>
                  <TableHead>المتوقع</TableHead>
                  <TableHead>الفعلي</TableHead>
                  <TableHead>الفرق</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((h) => {
                  const diff = (h.countedCash ?? h.expectedCash) - h.expectedCash
                  return (
                    <TableRow key={h.id}>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="num">{formatDate(h.openedAt)}</span>
                          <span className="num text-xs text-muted-foreground">
                            {formatTime(h.openedAt)} – {h.closedAt ? formatTime(h.closedAt) : '—'}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{h.cashier}</TableCell>
                      <TableCell className="hidden md:table-cell">{h.branch}</TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <Money value={h.sales} />
                      </TableCell>
                      <TableCell>
                        <Money value={h.expectedCash} />
                      </TableCell>
                      <TableCell>{h.countedCash !== undefined ? <Money value={h.countedCash} /> : '—'}</TableCell>
                      <TableCell>
                        <Badge variant={diff === 0 ? 'success' : diff > 0 ? 'warning' : 'destructive'}>
                          <span className="num">{diff === 0 ? 'مطابق' : diff > 0 ? `+${diff.toFixed(2)}` : diff.toFixed(2)}</span>
                        </Badge>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </TableShell>
        </ListState>
      </section>

      {shift && <CloseShiftDialog open={closing} onOpenChange={setClosing} expected={expectedCash(shift)} onConfirm={confirmClose} />}
    </div>
  )
}

function Breakdown({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: number }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border p-3">
      <div className="flex size-9 items-center justify-center rounded-md bg-muted text-muted-foreground">
        <Icon className="size-4" />
      </div>
      <div className="flex flex-col">
        <span className="text-xs text-muted-foreground">{label}</span>
        <Money value={value} className="font-semibold" />
      </div>
    </div>
  )
}

function Row({ label, value, icon: Icon }: { label: string; value: React.ReactNode; icon?: React.ComponentType<{ className?: string }> }) {
  return (
    <div className={cn('flex items-center justify-between gap-2 rounded-md bg-muted/50 px-3 py-2')}>
      <dt className="flex items-center gap-1.5 text-muted-foreground">
        {Icon && <Icon className="size-3.5" />}
        {label}
      </dt>
      <dd>{value}</dd>
    </div>
  )
}

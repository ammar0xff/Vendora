'use client'

import { useState } from 'react'
import { SimpleSelect } from '@/components/app/shared'
import { LineEditor, linesValid, newLine, type Line } from '@/components/stock/line-editor'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { BRANCHES, type Product } from '@/lib/mock-data'

export type TransferDraft = { from: string; to: string; lines: Line[]; send: boolean }

export function TransferDialog({
  open,
  onOpenChange,
  products,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  products: Product[]
  onSubmit: (d: TransferDraft) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl">
        {open && <TransferForm products={products} onCancel={() => onOpenChange(false)} onSubmit={onSubmit} />}
      </DialogContent>
    </Dialog>
  )
}

function TransferForm({ products, onCancel, onSubmit }: { products: Product[]; onCancel: () => void; onSubmit: (d: TransferDraft) => void }) {
  const [from, setFrom] = useState('main-wh')
  const [to, setTo] = useState('maadi')
  const [lines, setLines] = useState<Line[]>([newLine()])
  const same = from === to
  const available = (p: Product) => p.stock[from] ?? 0
  const valid = !same && linesValid(lines, products, available)
  const options = BRANCHES.map((b) => ({ value: b.id, label: b.name }))

  return (
    <>
      <DialogHeader>
        <DialogTitle>تحويل مخزني جديد</DialogTitle>
        <DialogDescription>لا يُخصم الرصيد من المصدر إلا عند الإرسال، ولا يُضاف للوجهة إلا بعد تأكيد الاستلام.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field>
            <FieldLabel htmlFor="tr-from">من</FieldLabel>
            <SimpleSelect id="tr-from" className="w-full" value={from} onValueChange={setFrom} options={options} />
          </Field>
          <Field data-invalid={same || undefined}>
            <FieldLabel htmlFor="tr-to">إلى</FieldLabel>
            <SimpleSelect id="tr-to" className="w-full" value={to} onValueChange={setTo} options={options} />
            {same && <FieldError>لا يمكن التحويل لنفس المخزن</FieldError>}
          </Field>
        </div>
        <Field>
          <FieldLabel>الأصناف</FieldLabel>
          <LineEditor lines={lines} onChange={setLines} products={products.filter((p) => p.active)} available={available} />
        </Field>
      </FieldGroup>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button variant="secondary" disabled={!valid} onClick={() => onSubmit({ from, to, lines, send: false })}>
          حفظ كمسودة
        </Button>
        <Button disabled={!valid} onClick={() => onSubmit({ from, to, lines, send: true })}>
          حفظ وإرسال
        </Button>
      </DialogFooter>
    </>
  )
}

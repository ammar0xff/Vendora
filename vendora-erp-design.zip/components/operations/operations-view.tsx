'use client'

import { useMemo, useState } from 'react'
import { ArrowLeft, ArrowLeftRight, Check, Plus, Send, Truck, X } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { ListState, Num, PageHeader, SimpleSelect, StatCard, StatusBadge, TableShell } from '@/components/app/shared'
import type { Line } from '@/components/stock/line-editor'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDateTime } from '@/lib/format'
import { BRANCHES, type Transfer } from '@/lib/mock-data'
import { TransferDialog, type TransferDraft } from './transfer-dialog'

const branchIdByName = (name: string) => BRANCHES.find((b) => b.name === name)?.id

export function OperationsView() {
  const { userName, roleId, branchName } = useApp()
  const transfers = useMock('transfers')
  const products = useMock('products')
  const [status, setStatus] = useState('all')
  const [open, setOpen] = useState(false)
  const [linesById, setLinesById] = useState<Record<string, Line[]>>({})
  const [rejecting, setRejecting] = useState<Transfer | null>(null)
  const canApproveAny = roleId === 'admin' || roleId === 'storekeeper'

  const rows = useMemo(() => transfers.data.filter((t) => status === 'all' || t.status === status), [transfers.data, status])
  const inTransit = transfers.data.filter((t) => t.status === 'قيد النقل').length
  const drafts = transfers.data.filter((t) => t.status === 'مسودة').length

  function moveStock(t: Transfer, direction: 'out' | 'in' | 'back') {
    const lines = linesById[t.id]
    if (!lines) return
    const fromId = branchIdByName(t.from)
    const toId = branchIdByName(t.to)
    products.mutate(
      products.data.map((p) => {
        const line = lines.find((l) => l.productId === p.id)
        if (!line) return p
        const stock = { ...p.stock }
        if (direction === 'out' && fromId) stock[fromId] = (stock[fromId] ?? 0) - line.qty
        if (direction === 'in' && toId) stock[toId] = (stock[toId] ?? 0) + line.qty
        if (direction === 'back' && fromId) stock[fromId] = (stock[fromId] ?? 0) + line.qty
        return { ...p, stock }
      }),
    )
  }

  function setTransferStatus(t: Transfer, next: Transfer['status']) {
    transfers.mutate(transfers.data.map((x) => (x.id === t.id ? { ...x, status: next } : x)))
  }

  function create(d: TransferDraft) {
    const id = `t${Date.now()}`
    const number = `TR-${String(394 + transfers.data.length).padStart(4, '0')}`
    const t: Transfer = {
      id,
      number,
      date: new Date().toISOString(),
      from: BRANCHES.find((b) => b.id === d.from)?.name ?? '',
      to: BRANCHES.find((b) => b.id === d.to)?.name ?? '',
      items: d.lines.length,
      status: d.send ? 'قيد النقل' : 'مسودة',
      createdBy: userName,
    }
    setLinesById((m) => ({ ...m, [id]: d.lines }))
    transfers.mutate([t, ...transfers.data])
    if (d.send) {
      const fromId = d.from
      products.mutate(
        products.data.map((p) => {
          const line = d.lines.find((l) => l.productId === p.id)
          return line ? { ...p, stock: { ...p.stock, [fromId]: (p.stock[fromId] ?? 0) - line.qty } } : p
        }),
      )
    }
    setOpen(false)
    toast.success(d.send ? `تم إرسال ${number}` : `تم حفظ ${number} كمسودة`, { description: `${t.from} ← ${t.to}` })
  }

  const canReceive = (t: Transfer) => canApproveAny || roleId === 'manager' && t.to === branchName

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="العمليات المخزنية"
        description="التحويلات بين الفروع والمخازن مع دورة إرسال واستلام"
        actions={
          <Button onClick={() => setOpen(true)}>
            <Plus data-icon="inline-start" />
            تحويل جديد
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="قيد النقل" value={<Num value={inTransit} />} icon={Truck} tone="warning" />
        <StatCard label="مسودات" value={<Num value={drafts} />} icon={ArrowLeftRight} />
        <StatCard label="إجمالي التحويلات" value={<Num value={transfers.data.length} />} icon={Check} tone="success" />
      </div>

      <SimpleSelect
        value={status}
        onValueChange={setStatus}
        label="الحالة"
        className="w-48"
        options={[{ value: 'all', label: 'كل الحالات' }, ...['مسودة', 'قيد النقل', 'مستلم', 'مرفوض'].map((s) => ({ value: s, label: s }))]}
      />

      <ListState
        status={transfers.status}
        isEmpty={rows.length === 0}
        onRetry={transfers.retry}
        emptyIcon={ArrowLeftRight}
        emptyTitle="لا توجد تحويلات"
        emptyDescription="أنشئ تحويلًا لنقل بضاعة من المخزن الرئيسي إلى أحد الفروع."
        emptyAction={
          <Button onClick={() => setOpen(true)}>
            <Plus data-icon="inline-start" />
            تحويل جديد
          </Button>
        }
      >
        <TableShell>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>رقم التحويل</TableHead>
                <TableHead>المسار</TableHead>
                <TableHead className="hidden md:table-cell text-center">الأصناف</TableHead>
                <TableHead className="hidden lg:table-cell">بواسطة</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead className="text-end">إجراء</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((t) => (
                <TableRow key={t.id}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="num font-medium">{t.number}</span>
                      <span className="num text-xs text-muted-foreground">{formatDateTime(t.date)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="inline-flex items-center gap-1.5">
                      {t.from}
                      <ArrowLeft className="size-3.5 text-muted-foreground" aria-label="إلى" />
                      {t.to}
                    </span>
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-center">
                    <Num value={t.items} />
                  </TableCell>
                  <TableCell className="hidden lg:table-cell">{t.createdBy}</TableCell>
                  <TableCell>
                    <StatusBadge status={t.status} />
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-1.5">
                      {t.status === 'مسودة' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            moveStock(t, 'out')
                            setTransferStatus(t, 'قيد النقل')
                            toast.success(`تم إرسال ${t.number}`)
                          }}
                        >
                          <Send data-icon="inline-start" />
                          إرسال
                        </Button>
                      )}
                      {t.status === 'قيد النقل' && canReceive(t) && (
                        <>
                          <Button
                            size="sm"
                            onClick={() => {
                              moveStock(t, 'in')
                              setTransferStatus(t, 'مستلم')
                              toast.success(`تم استلام ${t.number}`, { description: `أضيفت الكميات إلى ${t.to}` })
                            }}
                          >
                            <Check data-icon="inline-start" />
                            استلام
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => setRejecting(t)}>
                            <X data-icon="inline-start" />
                            رفض
                          </Button>
                        </>
                      )}
                      {(t.status === 'مستلم' || t.status === 'مرفوض' || (t.status === 'قيد النقل' && !canReceive(t))) && (
                        <span className="text-xs text-muted-foreground">{t.status === 'قيد النقل' ? 'بانتظار الفرع المستلم' : '—'}</span>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableShell>
      </ListState>

      <TransferDialog open={open} onOpenChange={setOpen} products={products.data} onSubmit={create} />
      <ConfirmDialog
        open={rejecting !== null}
        onOpenChange={(o) => !o && setRejecting(null)}
        title={`رفض التحويل ${rejecting?.number ?? ''}`}
        description="ستعود الكميات إلى المخزن المصدر وسيُسجل الرفض باسمك في سجل التدقيق."
        confirmLabel="رفض التحويل"
        destructive
        onConfirm={() => {
          if (!rejecting) return
          moveStock(rejecting, 'back')
          setTransferStatus(rejecting, 'مرفوض')
          toast.success(`تم رفض ${rejecting.number}`)
        }}
      />
    </div>
  )
}

'use client'

import { useState } from 'react'
import { SimpleSelect } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import type { ArchiveDoc } from '@/lib/mock-data'

export const DOC_KINDS: ArchiveDoc['kind'][] = ['عقد', 'فاتورة مورد', 'مستند حكومي', 'صورة', 'تقرير']

export type UploadDraft = { title: string; kind: ArchiveDoc['kind']; linkedTo: string; size: string }

function formatSize(bytes: number) {
  if (bytes >= 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`
  return `${Math.max(1, Math.round(bytes / 1024))} KB`
}

export function UploadDialog({
  open,
  onOpenChange,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (draft: UploadDraft) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">{open && <UploadForm onCancel={() => onOpenChange(false)} onSubmit={onSubmit} />}</DialogContent>
    </Dialog>
  )
}

function UploadForm({ onCancel, onSubmit }: { onCancel: () => void; onSubmit: (draft: UploadDraft) => void }) {
  const [file, setFile] = useState<File | null>(null)
  const [title, setTitle] = useState('')
  const [kind, setKind] = useState<ArchiveDoc['kind']>('فاتورة مورد')
  const [linkedTo, setLinkedTo] = useState('')
  const tooLarge = file !== null && file.size > 10 * 1024 * 1024
  const invalid = !file || tooLarge || title.trim().length < 3 || linkedTo.trim().length === 0

  return (
    <form
      className="flex flex-col gap-6"
      onSubmit={(e) => {
        e.preventDefault()
        if (!invalid && file) onSubmit({ title: title.trim(), kind, linkedTo: linkedTo.trim(), size: formatSize(file.size) })
      }}
    >
      <DialogHeader>
        <DialogTitle>رفع مستند</DialogTitle>
        <DialogDescription>اربط المستند بمورد أو أمر شراء أو فرع ليسهل الوصول إليه لاحقًا.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <Field data-invalid={tooLarge || undefined}>
          <FieldLabel htmlFor="doc-file">الملف</FieldLabel>
          <Input
            id="doc-file"
            type="file"
            accept=".pdf,.png,.jpg,.jpeg,.xlsx,.docx"
            aria-invalid={tooLarge || undefined}
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null
              setFile(f)
              if (f && !title) setTitle(f.name.replace(/\.[^.]+$/, ''))
            }}
          />
          <FieldDescription>{tooLarge ? 'الحد الأقصى لحجم الملف 10 ميجابايت.' : 'PDF أو صور أو مستندات Office حتى 10 ميجابايت.'}</FieldDescription>
        </Field>
        <Field>
          <FieldLabel htmlFor="doc-title">عنوان المستند</FieldLabel>
          <Input id="doc-title" value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field>
            <FieldLabel htmlFor="doc-kind">النوع</FieldLabel>
            <SimpleSelect
              id="doc-kind"
              value={kind}
              onValueChange={(v) => setKind(v as ArchiveDoc['kind'])}
              options={DOC_KINDS.map((k) => ({ value: k, label: k }))}
            />
          </Field>
          <Field>
            <FieldLabel htmlFor="doc-link">مرتبط بـ</FieldLabel>
            <Input id="doc-link" value={linkedTo} onChange={(e) => setLinkedTo(e.target.value)} placeholder="PO-0218 أو اسم مورد" />
          </Field>
        </div>
      </FieldGroup>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button type="submit" disabled={invalid}>
          رفع
        </Button>
      </DialogFooter>
    </form>
  )
}

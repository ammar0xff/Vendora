'use client'

import { useMemo, useState } from 'react'
import { Archive, FileImage, FileSignature, FileText, Landmark, MoreHorizontal, ScrollText, Upload } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { ListState, PageHeader, SearchField, SimpleSelect, TableShell } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDate } from '@/lib/format'
import type { ArchiveDoc } from '@/lib/mock-data'
import { DOC_KINDS, UploadDialog, type UploadDraft } from './upload-dialog'

const KIND_ICON: Record<ArchiveDoc['kind'], typeof FileText> = {
  عقد: FileSignature,
  'فاتورة مورد': ScrollText,
  'مستند حكومي': Landmark,
  صورة: FileImage,
  تقرير: FileText,
}

export function ArchiveView() {
  const { userName, roleId } = useApp()
  const docs = useMock('archive')
  const [query, setQuery] = useState('')
  const [kind, setKind] = useState('all')
  const [open, setOpen] = useState(false)
  const [deleting, setDeleting] = useState<ArchiveDoc | null>(null)
  const canDelete = roleId === 'admin'

  const q = query.trim()
  const rows = useMemo(
    () => docs.data.filter((d) => (kind === 'all' || d.kind === kind) && (!q || d.title.includes(q) || d.linkedTo.includes(q))),
    [docs.data, kind, q],
  )

  function upload(d: UploadDraft) {
    const doc: ArchiveDoc = { id: `a${Date.now()}`, ...d, uploadedBy: userName, date: new Date().toISOString() }
    docs.mutate([doc, ...docs.data])
    setOpen(false)
    toast.success('تم رفع المستند', { description: d.title })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="الأرشيف"
        description="العقود وفواتير الموردين والمستندات الرسمية"
        actions={
          <Button onClick={() => setOpen(true)}>
            <Upload data-icon="inline-start" />
            رفع مستند
          </Button>
        }
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <SearchField value={query} onChange={setQuery} placeholder="ابحث بالعنوان أو الجهة المرتبطة" />
        <SimpleSelect
          value={kind}
          onValueChange={setKind}
          label="نوع المستند"
          className="w-44"
          options={[{ value: 'all', label: 'كل الأنواع' }, ...DOC_KINDS.map((k) => ({ value: k, label: k }))]}
        />
      </div>

      <ListState
        status={docs.status}
        isEmpty={rows.length === 0}
        onRetry={docs.retry}
        emptyIcon={Archive}
        emptyTitle="لا توجد مستندات"
        emptyDescription="ارفع أول مستند أو غيّر معايير البحث."
        emptyAction={
          <Button variant="outline" onClick={() => setOpen(true)}>
            <Upload data-icon="inline-start" />
            رفع مستند
          </Button>
        }
      >
        <TableShell>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>المستند</TableHead>
                <TableHead className="hidden md:table-cell">النوع</TableHead>
                <TableHead>مرتبط بـ</TableHead>
                <TableHead className="hidden lg:table-cell">رفع بواسطة</TableHead>
                <TableHead className="hidden sm:table-cell">التاريخ</TableHead>
                <TableHead className="w-12">
                  <span className="sr-only">إجراءات</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((d) => {
                const Icon = KIND_ICON[d.kind]
                return (
                  <TableRow key={d.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
                          <Icon className="size-4" aria-hidden />
                        </span>
                        <div className="flex min-w-0 flex-col">
                          <span className="truncate font-medium">{d.title}</span>
                          <span className="num text-xs text-muted-foreground" dir="ltr">
                            {d.size}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <Badge variant="outline">{d.kind}</Badge>
                    </TableCell>
                    <TableCell>{d.linkedTo}</TableCell>
                    <TableCell className="hidden lg:table-cell">{d.uploadedBy}</TableCell>
                    <TableCell className="num hidden sm:table-cell">{formatDate(d.date)}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger render={<Button variant="ghost" size="icon-sm" aria-label={`إجراءات ${d.title}`} />}>
                          <MoreHorizontal />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuGroup>
                            <DropdownMenuItem onClick={() => toast.info('جارٍ تجهيز المعاينة', { description: d.title })}>معاينة</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => toast.success('بدأ التنزيل', { description: d.title })}>تنزيل</DropdownMenuItem>
                          </DropdownMenuGroup>
                          {canDelete && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuGroup>
                                <DropdownMenuItem variant="destructive" onClick={() => setDeleting(d)}>
                                  حذف
                                </DropdownMenuItem>
                              </DropdownMenuGroup>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </TableShell>
      </ListState>

      <UploadDialog open={open} onOpenChange={setOpen} onSubmit={upload} />
      <ConfirmDialog
        open={deleting !== null}
        onOpenChange={(o) => !o && setDeleting(null)}
        title="حذف المستند"
        description={`سيتم حذف "${deleting?.title ?? ''}" نهائيًا من الأرشيف.`}
        confirmLabel="حذف"
        destructive
        onConfirm={() => {
          if (!deleting) return
          docs.mutate(docs.data.filter((x) => x.id !== deleting.id))
          toast.success('تم حذف المستند')
        }}
      />
    </div>
  )
}

'use client'

import { Check, Minus, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ListState, PageHeader, SimpleSelect, StatusBadge, TableShell } from '@/components/app/shared'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useMock } from '@/hooks/use-mock'
import { formatDateTime } from '@/lib/format'
import { NAV_ITEMS, ROLES, getRole, type RoleId } from '@/lib/permissions'

const ROLE_OPTIONS = ROLES.map((r) => ({ value: r.id, label: r.label }))

export function UsersView() {
  const { userName } = useApp()
  const users = useMock('users')
  const audit = useMock('audit')

  function logAction(action: string, target: string) {
    audit.mutate([{ id: `l${Date.now()}`, date: new Date().toISOString(), user: userName, action, target }, ...audit.data])
  }

  function changeRole(id: string, role: RoleId) {
    const u = users.data.find((x) => x.id === id)
    if (!u || u.role === role) return
    users.mutate(users.data.map((x) => (x.id === id ? { ...x, role } : x)))
    logAction('تغيير دور', `${u.name} ← ${getRole(role).label}`)
    toast.success(`أصبح ${u.name} ${getRole(role).label}`)
  }

  function toggleActive(id: string, active: boolean) {
    const u = users.data.find((x) => x.id === id)
    if (!u) return
    const admins = users.data.filter((x) => x.role === 'admin' && x.active)
    if (!active && u.role === 'admin' && admins.length <= 1) {
      toast.error('لا يمكن إيقاف آخر مدير نظام نشط')
      return
    }
    users.mutate(users.data.map((x) => (x.id === id ? { ...x, active } : x)))
    logAction(active ? 'تفعيل مستخدم' : 'إيقاف مستخدم', u.name)
    toast.success(active ? `تم تفعيل ${u.name}` : `تم إيقاف ${u.name}`)
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="المستخدمون والصلاحيات" description="الأدوار، الوصول إلى الأقسام، وسجل التدقيق" />

      <Tabs defaultValue="users" className="flex flex-col gap-4">
        <TabsList>
          <TabsTrigger value="users">المستخدمون</TabsTrigger>
          <TabsTrigger value="matrix">مصفوفة الصلاحيات</TabsTrigger>
          <TabsTrigger value="audit">سجل التدقيق</TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <ListState
            status={users.status}
            isEmpty={users.data.length === 0}
            onRetry={users.retry}
            emptyIcon={ShieldCheck}
            emptyTitle="لا يوجد مستخدمون"
            emptyDescription="أضف مستخدمًا لمنحه صلاحية الدخول."
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>الدور</TableHead>
                    <TableHead className="hidden md:table-cell">الفرع</TableHead>
                    <TableHead className="hidden lg:table-cell">آخر دخول</TableHead>
                    <TableHead>نشط</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.data.map((u) => (
                    <TableRow key={u.id} className={u.active ? undefined : 'opacity-60'}>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{u.name}</span>
                          <span className="text-xs text-muted-foreground" dir="ltr">
                            {u.email}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <SimpleSelect
                          value={u.role}
                          onValueChange={(v) => changeRole(u.id, v as RoleId)}
                          options={ROLE_OPTIONS}
                          label={`دور ${u.name}`}
                          className="min-w-36"
                        />
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{u.branch}</TableCell>
                      <TableCell className="num hidden lg:table-cell">{formatDateTime(u.lastLogin)}</TableCell>
                      <TableCell>
                        <Switch checked={u.active} onCheckedChange={(c) => toggleActive(u.id, c)} aria-label={`تفعيل ${u.name}`} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>

        <TabsContent value="matrix">
          <TableShell>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>القسم</TableHead>
                  {ROLES.map((r) => (
                    <TableHead key={r.id} className="text-center">
                      {r.label}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {NAV_ITEMS.map((item) => (
                  <TableRow key={item.feature}>
                    <TableCell className="font-medium">{item.label}</TableCell>
                    {ROLES.map((r) => {
                      const allowed = r.features.includes(item.feature)
                      return (
                        <TableCell key={r.id} className="text-center">
                          {allowed ? (
                            <Check className="mx-auto size-4 text-success" aria-label="مسموح" />
                          ) : (
                            <Minus className="mx-auto size-4 text-muted-foreground/50" aria-label="غير مسموح" />
                          )}
                        </TableCell>
                      )
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableShell>
        </TabsContent>

        <TabsContent value="audit">
          <ListState
            status={audit.status}
            isEmpty={audit.data.length === 0}
            onRetry={audit.retry}
            emptyTitle="لا توجد سجلات"
            emptyDescription="ستظهر هنا الإجراءات الحساسة فور حدوثها."
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الإجراء</TableHead>
                    <TableHead>الهدف</TableHead>
                    <TableHead className="hidden md:table-cell">المستخدم</TableHead>
                    <TableHead className="hidden sm:table-cell">الوقت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {audit.data.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell>
                        <StatusBadge status={l.action} />
                      </TableCell>
                      <TableCell>{l.target}</TableCell>
                      <TableCell className="hidden md:table-cell">{l.user}</TableCell>
                      <TableCell className="num hidden sm:table-cell">{formatDateTime(l.date)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>
      </Tabs>
    </div>
  )
}

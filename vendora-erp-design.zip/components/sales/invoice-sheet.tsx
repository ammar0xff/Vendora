'use client'

import { Ban, Printer, Undo2 } from 'lucide-react'
import { toast } from 'sonner'
import { Money, Num, StatusBadge } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatDateTime } from '@/lib/format'
import { getInvoiceLines, type Invoice } from '@/lib/mock-data'

export function canReturn(inv: Invoice) {
  return inv.status === 'مكتملة' || inv.status === 'آجل' || inv.status === 'مرتجع جزئي'
}

export function InvoiceSheet({
  invoice,
  onOpenChange,
  onReturn,
  onCancel,
  canCancel,
}: {
  invoice: Invoice | null
  onOpenChange: (open: boolean) => void
  onReturn: (inv: Invoice) => void
  onCancel: (inv: Invoice) => void
  canCancel: boolean
}) {
  const lines = invoice ? getInvoiceLines(invoice.id) : []
  const remaining = invoice ? invoice.total - invoice.paid : 0

  return (
    <Sheet open={invoice !== null} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-full gap-0 sm:max-w-lg">
        {invoice && (
          <>
            <SheetHeader className="border-b">
              <div className="flex items-center gap-2">
                <SheetTitle className="num text-lg">{invoice.number}</SheetTitle>
                <StatusBadge status={invoice.status} />
              </div>
              <SheetDescription>
                {invoice.customer} — <span className="num">{formatDateTime(invoice.date)}</span>
              </SheetDescription>
            </SheetHeader>

            <div className="flex flex-1 flex-col gap-5 overflow-y-auto p-4">
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex flex-col gap-0.5">
                  <dt className="text-xs text-muted-foreground">الفرع</dt>
                  <dd>{invoice.branch}</dd>
                </div>
                <div className="flex flex-col gap-0.5">
                  <dt className="text-xs text-muted-foreground">الكاشير</dt>
                  <dd>{invoice.cashier}</dd>
                </div>
                <div className="flex flex-col gap-0.5">
                  <dt className="text-xs text-muted-foreground">طريقة الدفع</dt>
                  <dd>{invoice.method}</dd>
                </div>
                <div className="flex flex-col gap-0.5">
                  <dt className="text-xs text-muted-foreground">عدد الأصناف</dt>
                  <dd>
                    <Num value={invoice.items} />
                  </dd>
                </div>
              </dl>

              <div className="overflow-hidden rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الصنف</TableHead>
                      <TableHead className="text-center">الكمية</TableHead>
                      <TableHead className="text-end">الإجمالي</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {lines.map((l) => (
                      <TableRow key={l.productId}>
                        <TableCell className="whitespace-normal">
                          <div className="flex flex-col">
                            <span className="font-medium">{l.name}</span>
                            <span className="text-xs text-muted-foreground">
                              <Money value={l.price} /> للوحدة
                            </span>
                            {l.returned > 0 && (
                              <span className="text-xs text-destructive">
                                مرتجع: <Num value={l.returned} />
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <Num value={l.qty} />
                        </TableCell>
                        <TableCell className="text-end">
                          <Money value={l.qty * l.price} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex flex-col gap-2 rounded-lg bg-muted/50 p-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الإجمالي</span>
                  <Money value={invoice.total} className="font-semibold" />
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">المدفوع</span>
                  <Money value={invoice.paid} />
                </div>
                {remaining > 0 && invoice.status !== 'عرض سعر' && (
                  <>
                    <Separator />
                    <div className="flex justify-between text-warning">
                      <span>المتبقي على العميل</span>
                      <Money value={remaining} className="font-semibold" />
                    </div>
                  </>
                )}
              </div>
            </div>

            <SheetFooter className="flex-row flex-wrap border-t">
              <Button variant="outline" onClick={() => toast.success(`تم إرسال ${invoice.number} للطابعة`)}>
                <Printer data-icon="inline-start" />
                طباعة
              </Button>
              {canReturn(invoice) && (
                <Button variant="outline" onClick={() => onReturn(invoice)}>
                  <Undo2 data-icon="inline-start" />
                  مرتجع
                </Button>
              )}
              {canCancel && invoice.status === 'مكتملة' && (
                <Button variant="destructive" onClick={() => onCancel(invoice)}>
                  <Ban data-icon="inline-start" />
                  إلغاء الفاتورة
                </Button>
              )}
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}

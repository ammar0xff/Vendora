'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { Download, MoreHorizontal, Receipt, ShoppingCart, Undo2, Wallet } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { ListState, Money, Num, PageHeader, SearchField, SimpleSelect, StatCard, StatusBadge, TableShell } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDateTime } from '@/lib/format'
import { BRANCHES, type Invoice } from '@/lib/mock-data'
import { canReturn, InvoiceSheet } from './invoice-sheet'
import { ReturnDialog, type ReturnResult } from './return-dialog'

const STATUS_OPTIONS = [
  { value: 'all', label: 'كل الحالات' },
  ...['مكتملة', 'آجل', 'مرتجع جزئي', 'مرتجع كلي', 'ملغاة', 'عرض سعر'].map((s) => ({ value: s, label: s })),
]

export function SalesView() {
  const { roleId, branchName, shift, recordRefund } = useApp()
  const query = useMock('invoices')
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const isCashier = roleId === 'cashier'
  const [branch, setBranch] = useState(isCashier ? branchName : 'all')
  const [selected, setSelected] = useState<Invoice | null>(null)
  const [returning, setReturning] = useState<Invoice | null>(null)
  const [cancelling, setCancelling] = useState<Invoice | null>(null)
  const canCancel = roleId === 'admin' || roleId === 'manager'

  const effectiveBranch = isCashier ? branchName : branch

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return query.data.filter(
      (inv) =>
        (status === 'all' || inv.status === status) &&
        (effectiveBranch === 'all' || inv.branch === effectiveBranch) &&
        (!q || inv.number.toLowerCase().includes(q) || inv.customer.includes(q)),
    )
  }, [query.data, search, status, effectiveBranch])

  const sold = rows.filter((r) => r.status !== 'ملغاة' && r.status !== 'عرض سعر')
  const totalSales = sold.reduce((s, r) => s + r.total, 0)
  const outstanding = sold.reduce((s, r) => s + (r.total - r.paid), 0)
  const returnsCount = rows.filter((r) => r.status.startsWith('مرتجع')).length

  function updateInvoice(id: string, patch: Partial<Invoice>) {
    query.mutate(query.data.map((inv) => (inv.id === id ? { ...inv, ...patch } : inv)))
    setSelected((s) => (s && s.id === id ? { ...s, ...patch } : s))
  }

  function handleReturn(inv: Invoice, result: ReturnResult) {
    if (result.method === 'نقدي' && !shift) {
      toast.error('لا يمكن رد مبلغ نقدي بدون وردية مفتوحة', { description: 'افتح وردية من شاشة نقطة البيع أولًا.' })
      return
    }
    if (result.method === 'نقدي') recordRefund(result.amount)
    updateInvoice(inv.id, { status: result.full ? 'مرتجع كلي' : 'مرتجع جزئي' })
    setReturning(null)
    toast.success('تم تسجيل المرتجع', { description: `قيمة المرتجع ${result.amount.toFixed(2)} ج.م — ${result.method}` })
  }

  const branchOptions = [{ value: 'all', label: 'كل الفروع' }, ...BRANCHES.filter((b) => b.kind === 'branch').map((b) => ({ value: b.name, label: b.name }))]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="المبيعات"
        description={isCashier ? `فواتير ${branchName}` : 'كل الفواتير وعروض الأسعار والمرتجعات'}
        actions={
          <>
            <Button variant="outline" onClick={() => toast.success('جارٍ تجهيز ملف Excel', { description: `${rows.length} فاتورة` })}>
              <Download data-icon="inline-start" />
              تصدير
            </Button>
            <Button nativeButton={false} render={<Link href="/pos" />}>
              <ShoppingCart data-icon="inline-start" />
              فاتورة جديدة
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="إجمالي المبيعات (حسب الفلتر)" value={<Money value={totalSales} />} icon={Receipt} />
        <StatCard label="مستحقات آجلة" value={<Money value={outstanding} />} icon={Wallet} tone="warning" />
        <StatCard label="فواتير بها مرتجع" value={<Num value={returnsCount} />} icon={Undo2} tone="destructive" />
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        <SearchField value={search} onChange={setSearch} placeholder="رقم الفاتورة أو اسم العميل" />
        <SimpleSelect value={status} onValueChange={setStatus} options={STATUS_OPTIONS} label="الحالة" />
        {!isCashier && <SimpleSelect value={branch} onValueChange={setBranch} options={branchOptions} label="الفرع" />}
      </div>

      <ListState
        status={query.status}
        isEmpty={rows.length === 0}
        onRetry={query.retry}
        emptyIcon={Receipt}
        emptyTitle="لا توجد فواتير"
        emptyDescription="لا توجد فواتير تطابق البحث أو الفلاتر الحالية."
        emptyAction={
          <Button variant="outline" onClick={() => { setSearch(''); setStatus('all'); setBranch(isCashier ? branchName : 'all') }}>
            مسح الفلاتر
          </Button>
        }
      >
        <TableShell>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الفاتورة</TableHead>
                <TableHead>العميل</TableHead>
                <TableHead className="hidden md:table-cell">الفرع</TableHead>
                <TableHead className="hidden lg:table-cell">الدفع</TableHead>
                <TableHead>الإجمالي</TableHead>
                <TableHead className="hidden sm:table-cell">الحالة</TableHead>
                <TableHead className="w-12">
                  <span className="sr-only">إجراءات</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((inv) => (
                <TableRow key={inv.id} className="cursor-pointer" onClick={() => setSelected(inv)}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="num font-medium">{inv.number}</span>
                      <span className="num text-xs text-muted-foreground">{formatDateTime(inv.date)}</span>
                    </div>
                  </TableCell>
                  <TableCell>{inv.customer}</TableCell>
                  <TableCell className="hidden md:table-cell">{inv.branch}</TableCell>
                  <TableCell className="hidden lg:table-cell">{inv.method}</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <Money value={inv.total} className="font-medium" />
                      {inv.total > inv.paid && inv.status === 'آجل' && (
                        <span className="text-xs text-warning">
                          متبقي <Money value={inv.total - inv.paid} currency={false} />
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <StatusBadge status={inv.status} />
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <DropdownMenu>
                      <DropdownMenuTrigger render={<Button variant="ghost" size="icon-sm" aria-label={`إجراءات ${inv.number}`} />}>
                        <MoreHorizontal />
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuGroup>
                          <DropdownMenuItem onClick={() => setSelected(inv)}>عرض التفاصيل</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast.success(`تم إرسال ${inv.number} للطابعة`)}>طباعة</DropdownMenuItem>
                          <DropdownMenuItem disabled={!canReturn(inv)} onClick={() => setReturning(inv)}>
                            تسجيل مرتجع
                          </DropdownMenuItem>
                        </DropdownMenuGroup>
                        {canCancel && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuGroup>
                              <DropdownMenuItem variant="destructive" disabled={inv.status !== 'مكتملة'} onClick={() => setCancelling(inv)}>
                                إلغاء الفاتورة
                              </DropdownMenuItem>
                            </DropdownMenuGroup>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableShell>
      </ListState>

      <InvoiceSheet
        invoice={selected}
        onOpenChange={(o) => !o && setSelected(null)}
        onReturn={setReturning}
        onCancel={setCancelling}
        canCancel={canCancel}
      />
      <ReturnDialog invoice={returning} onOpenChange={(o) => !o && setReturning(null)} onConfirm={handleReturn} />
      <ConfirmDialog
        open={cancelling !== null}
        onOpenChange={(o) => !o && setCancelling(null)}
        title={`إلغاء الفاتورة ${cancelling?.number ?? ''}`}
        description="سيتم عكس حركة المخزون وإلغاء أثر الفاتورة على الخزينة. هذا الإجراء يُسجَّل في سجل التدقيق ولا يمكن التراجع عنه."
        confirmLabel="إلغاء الفاتورة"
        destructive
        onConfirm={() => {
          if (!cancelling) return
          updateInvoice(cancelling.id, { status: 'ملغاة' })
          toast.success(`تم إلغاء ${cancelling.number}`)
        }}
      />
    </div>
  )
}

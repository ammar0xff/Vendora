'use client'

import { useState } from 'react'
import { Money, SimpleSelect } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { getInvoiceLines, type Invoice } from '@/lib/mock-data'

const REASONS = [
  { value: 'defect', label: 'عيب صناعة' },
  { value: 'wrong', label: 'صنف خاطئ' },
  { value: 'extra', label: 'زيادة عن الحاجة' },
  { value: 'other', label: 'سبب آخر' },
]

const REFUND_METHODS = [
  { value: 'نقدي', label: 'نقدي من الوردية' },
  { value: 'رصيد', label: 'رصيد لحساب العميل' },
]

export type ReturnResult = { amount: number; full: boolean; method: string }

export function ReturnDialog({
  invoice,
  onOpenChange,
  onConfirm,
}: {
  invoice: Invoice | null
  onOpenChange: (open: boolean) => void
  onConfirm: (inv: Invoice, result: ReturnResult) => void
}) {
  return (
    <Dialog open={invoice !== null} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        {invoice && <ReturnForm key={invoice.id} invoice={invoice} onCancel={() => onOpenChange(false)} onConfirm={onConfirm} />}
      </DialogContent>
    </Dialog>
  )
}

function ReturnForm({
  invoice,
  onCancel,
  onConfirm,
}: {
  invoice: Invoice
  onCancel: () => void
  onConfirm: (inv: Invoice, result: ReturnResult) => void
}) {
  const lines = getInvoiceLines(invoice.id)
  const [qty, setQty] = useState<Record<string, number>>({})
  const [reason, setReason] = useState('defect')
  const [method, setMethod] = useState(invoice.method === 'آجل' ? 'رصيد' : 'نقدي')
  const [note, setNote] = useState('')

  const amount = lines.reduce((sum, l) => sum + (qty[l.productId] ?? 0) * l.price, 0)
  const totalReturnable = lines.reduce((s, l) => s + l.qty - l.returned, 0)
  const totalSelected = Object.values(qty).reduce((s, v) => s + v, 0)

  return (
    <>
      <DialogHeader>
        <DialogTitle>
          مرتجع على <span className="num">{invoice.number}</span>
        </DialogTitle>
        <DialogDescription>حدد الكميات المرتجعة. لا يمكن تجاوز الكمية المباعة ناقص ما سبق إرجاعه.</DialogDescription>
      </DialogHeader>

      <FieldGroup>
        <div className="flex flex-col divide-y rounded-lg border">
          {lines.map((l) => {
            const max = l.qty - l.returned
            return (
              <div key={l.productId} className="flex items-center gap-3 p-3">
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate text-sm font-medium">{l.name}</span>
                  <span className="text-xs text-muted-foreground">
                    متاح للإرجاع: <span className="num">{max}</span> — <Money value={l.price} />
                  </span>
                </div>
                <Input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  max={max}
                  disabled={max === 0}
                  aria-label={`كمية مرتجع ${l.name}`}
                  className="num w-20 text-center"
                  value={qty[l.productId] ?? 0}
                  onChange={(e) => {
                    const v = Math.max(0, Math.min(max, Math.floor(Number(e.target.value) || 0)))
                    setQty((q) => ({ ...q, [l.productId]: v }))
                  }}
                />
              </div>
            )
          })}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field>
            <FieldLabel htmlFor="return-reason">سبب المرتجع</FieldLabel>
            <SimpleSelect id="return-reason" value={reason} onValueChange={setReason} options={REASONS} className="w-full" />
          </Field>
          <Field>
            <FieldLabel htmlFor="return-method">طريقة الرد</FieldLabel>
            <SimpleSelect id="return-method" value={method} onValueChange={setMethod} options={REFUND_METHODS} className="w-full" />
          </Field>
        </div>
        <Field>
          <FieldLabel htmlFor="return-note">ملاحظات</FieldLabel>
          <Textarea id="return-note" rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="اختياري" />
        </Field>
      </FieldGroup>

      <div className="flex items-center justify-between rounded-lg bg-muted/60 p-3">
        <span className="text-sm text-muted-foreground">قيمة المرتجع</span>
        <Money value={amount} className="text-lg font-bold" />
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          رجوع
        </Button>
        <Button
          disabled={amount <= 0}
          onClick={() => onConfirm(invoice, { amount, full: totalSelected === totalReturnable, method })}
        >
          تأكيد المرتجع
        </Button>
      </DialogFooter>
    </>
  )
}

'use client'

import Image from 'next/image'
import { useMemo, useState } from 'react'
import { Barcode, MoreHorizontal, Package, Plus, Upload } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ListState, Money, Num, PageHeader, SearchField, SimpleSelect, StatusBadge, TableShell } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { CATEGORIES, type Product } from '@/lib/mock-data'
import { ProductDialog } from './product-dialog'

const totalStock = (p: Product) => Object.values(p.stock).reduce((s, v) => s + v, 0)

export function ProductsView() {
  const { roleId } = useApp()
  const query = useMock('products')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')
  const [state, setState] = useState('all')
  const [editing, setEditing] = useState<Product | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const showCost = roleId === 'admin' || roleId === 'manager'

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return query.data.filter(
      (p) =>
        (category === 'all' || p.category === category) &&
        (state === 'all' || (state === 'active' ? p.active : !p.active)) &&
        (!q || p.name.includes(q) || p.sku.toLowerCase().includes(q) || p.barcodes.some((b) => b.includes(q))),
    )
  }, [query.data, search, category, state])

  function openNew() {
    setEditing(null)
    setDialogOpen(true)
  }

  function save(p: Product) {
    const exists = query.data.some((x) => x.id === p.id)
    query.mutate(exists ? query.data.map((x) => (x.id === p.id ? p : x)) : [p, ...query.data])
    setDialogOpen(false)
    toast.success(exists ? 'تم حفظ التعديلات' : 'تمت إضافة الصنف', { description: p.name })
  }

  function toggleActive(p: Product) {
    query.mutate(query.data.map((x) => (x.id === p.id ? { ...x, active: !x.active } : x)))
    toast.success(p.active ? 'تم إيقاف الصنف' : 'تم تفعيل الصنف', { description: p.name })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="المنتجات"
        description={`${query.data.length} صنف في الكتالوج`}
        actions={
          <>
            <Button variant="outline" onClick={() => toast.info('رفع ملف Excel', { description: 'اسحب ملف الأصناف بصيغة xlsx لاستيرادها.' })}>
              <Upload data-icon="inline-start" />
              استيراد
            </Button>
            <Button onClick={openNew}>
              <Plus data-icon="inline-start" />
              صنف جديد
            </Button>
          </>
        }
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        <SearchField value={search} onChange={setSearch} placeholder="الاسم أو الكود أو الباركود" />
        <SimpleSelect
          value={category}
          onValueChange={setCategory}
          label="التصنيف"
          options={[{ value: 'all', label: 'كل التصنيفات' }, ...CATEGORIES.map((c) => ({ value: c, label: c }))]}
        />
        <SimpleSelect
          value={state}
          onValueChange={setState}
          label="الحالة"
          options={[
            { value: 'all', label: 'كل الحالات' },
            { value: 'active', label: 'نشط' },
            { value: 'inactive', label: 'موقوف' },
          ]}
        />
      </div>

      <ListState
        status={query.status}
        isEmpty={rows.length === 0}
        onRetry={query.retry}
        emptyIcon={Package}
        emptyTitle={query.data.length === 0 ? 'لا توجد أصناف بعد' : 'لا توجد نتائج'}
        emptyDescription={query.data.length === 0 ? 'ابدأ بإضافة أول صنف أو استورد الكتالوج من ملف Excel.' : 'جرّب كلمة بحث أخرى أو غيّر الفلاتر.'}
        emptyAction={
          <Button onClick={openNew}>
            <Plus data-icon="inline-start" />
            صنف جديد
          </Button>
        }
      >
        <TableShell>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الصنف</TableHead>
                <TableHead className="hidden md:table-cell">التصنيف</TableHead>
                <TableHead>السعر</TableHead>
                {showCost && <TableHead className="hidden lg:table-cell">التكلفة</TableHead>}
                <TableHead className="text-center">الرصيد</TableHead>
                <TableHead className="hidden sm:table-cell">الحالة</TableHead>
                <TableHead className="w-12">
                  <span className="sr-only">إجراءات</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((p) => {
                const stock = totalStock(p)
                const low = Object.values(p.stock).some((v) => v < p.minStock)
                return (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Image src={p.image} alt="" width={40} height={40} className="size-10 rounded-md border bg-muted object-cover" />
                        <div className="flex min-w-0 flex-col">
                          <span className="truncate font-medium">{p.name}</span>
                          <span className="num text-xs text-muted-foreground">
                            {p.sku} · {p.brand}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{p.category}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <Money value={p.price} className="font-medium" />
                        <span className="text-xs text-muted-foreground">
                          جملة <Money value={p.wholesale} currency={false} />
                        </span>
                      </div>
                    </TableCell>
                    {showCost && (
                      <TableCell className="hidden lg:table-cell">
                        <Money value={p.cost} />
                      </TableCell>
                    )}
                    <TableCell className="text-center">
                      <div className="flex flex-col items-center gap-1">
                        <Num value={stock} className="font-medium" />
                        {low && <Badge variant="warning">نقص بفرع</Badge>}
                      </div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <StatusBadge status={p.active ? 'نشط' : 'موقوف'} />
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger render={<Button variant="ghost" size="icon-sm" aria-label={`إجراءات ${p.name}`} />}>
                          <MoreHorizontal />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuGroup>
                            <DropdownMenuItem
                              onClick={() => {
                                setEditing(p)
                                setDialogOpen(true)
                              }}
                            >
                              تعديل
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => toast.success('تم إرسال ملصقات الباركود للطابعة', { description: p.barcodes[0] })}>
                              <Barcode />
                              طباعة ملصق
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => toggleActive(p)}>{p.active ? 'إيقاف الصنف' : 'تفعيل الصنف'}</DropdownMenuItem>
                          </DropdownMenuGroup>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </TableShell>
      </ListState>

      <ProductDialog
        open={dialogOpen}
        product={editing}
        existing={query.data}
        showCost={showCost}
        onOpenChange={setDialogOpen}
        onSave={save}
      />
    </div>
  )
}

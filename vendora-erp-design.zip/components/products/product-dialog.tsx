'use client'

import { useState } from 'react'
import { SimpleSelect } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { CATEGORIES, type Category, type Product } from '@/lib/mock-data'

const UNITS: Product['unit'][] = ['قطعة', 'متر', 'شيكارة', 'طقم', 'علبة']

type Draft = {
  name: string
  sku: string
  barcodes: string
  brand: string
  category: Category
  unit: Product['unit']
  price: string
  wholesale: string
  cost: string
  minStock: string
  active: boolean
}

function toDraft(p?: Product): Draft {
  return {
    name: p?.name ?? '',
    sku: p?.sku ?? '',
    barcodes: p?.barcodes.join('، ') ?? '',
    brand: p?.brand ?? '',
    category: p?.category ?? CATEGORIES[0],
    unit: p?.unit ?? 'قطعة',
    price: p ? String(p.price) : '',
    wholesale: p ? String(p.wholesale) : '',
    cost: p ? String(p.cost) : '',
    minStock: p ? String(p.minStock) : '',
    active: p?.active ?? true,
  }
}

export function ProductDialog({
  open,
  product,
  existing,
  showCost,
  onOpenChange,
  onSave,
}: {
  open: boolean
  product: Product | null
  existing: Product[]
  showCost: boolean
  onOpenChange: (open: boolean) => void
  onSave: (p: Product) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl">
        {open && (
          <ProductForm
            key={product?.id ?? 'new'}
            product={product}
            existing={existing}
            showCost={showCost}
            onCancel={() => onOpenChange(false)}
            onSave={onSave}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}

function ProductForm({
  product,
  existing,
  showCost,
  onCancel,
  onSave,
}: {
  product: Product | null
  existing: Product[]
  showCost: boolean
  onCancel: () => void
  onSave: (p: Product) => void
}) {
  const [d, setD] = useState<Draft>(() => toDraft(product ?? undefined))
  const [submitted, setSubmitted] = useState(false)
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((s) => ({ ...s, [k]: v }))

  const barcodes = d.barcodes
    .split(/[,،\s]+/)
    .map((b) => b.trim())
    .filter(Boolean)
  const others = existing.filter((p) => p.id !== product?.id)
  const price = Number(d.price)
  const cost = Number(d.cost)

  const errors: Partial<Record<keyof Draft, string>> = {}
  if (!d.name.trim()) errors.name = 'اسم الصنف مطلوب'
  if (!d.sku.trim()) errors.sku = 'الكود مطلوب'
  else if (others.some((p) => p.sku.toLowerCase() === d.sku.trim().toLowerCase())) errors.sku = 'هذا الكود مستخدم لصنف آخر'
  const dupBarcode = barcodes.find((b) => others.some((p) => p.barcodes.includes(b)))
  if (dupBarcode) errors.barcodes = `الباركود ${dupBarcode} مسجل لصنف آخر`
  if (!(price > 0)) errors.price = 'أدخل سعر بيع صحيح'
  if (d.wholesale && !(Number(d.wholesale) > 0)) errors.wholesale = 'سعر الجملة غير صحيح'
  if (showCost && !(cost > 0)) errors.cost = 'أدخل التكلفة'
  if (d.minStock === '' || Number(d.minStock) < 0) errors.minStock = 'حد الطلب مطلوب'

  const hasErrors = Object.keys(errors).length > 0
  const show = (k: keyof Draft) => (submitted ? errors[k] : undefined)
  const margin = price > 0 && cost > 0 ? ((price - cost) / price) * 100 : null

  function submit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitted(true)
    if (hasErrors) return
    onSave({
      id: product?.id ?? `p${Date.now()}`,
      sku: d.sku.trim().toUpperCase(),
      barcodes,
      name: d.name.trim(),
      brand: d.brand.trim(),
      category: d.category,
      unit: d.unit,
      price,
      wholesale: d.wholesale ? Number(d.wholesale) : price,
      cost: showCost ? cost : (product?.cost ?? 0),
      image: product?.image ?? '/products/fittings.png',
      minStock: Number(d.minStock),
      stock: product?.stock ?? { maadi: 0, nasr: 0, october: 0, 'main-wh': 0 },
      active: d.active,
    })
  }

  return (
    <form onSubmit={submit} noValidate className="flex flex-col gap-4">
      <DialogHeader>
        <DialogTitle>{product ? 'تعديل صنف' : 'صنف جديد'}</DialogTitle>
        <DialogDescription>البيانات الأساسية والتسعير وحد إعادة الطلب.</DialogDescription>
      </DialogHeader>

      <FieldGroup>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field data-invalid={!!show('name') || undefined} className="sm:col-span-2">
            <FieldLabel htmlFor="p-name">اسم الصنف</FieldLabel>
            <Input id="p-name" value={d.name} aria-invalid={!!show('name')} onChange={(e) => set('name', e.target.value)} />
            <FieldError>{show('name')}</FieldError>
          </Field>
          <Field data-invalid={!!show('sku') || undefined}>
            <FieldLabel htmlFor="p-sku">الكود (SKU)</FieldLabel>
            <Input id="p-sku" dir="ltr" className="num text-end" value={d.sku} aria-invalid={!!show('sku')} onChange={(e) => set('sku', e.target.value)} />
            <FieldError>{show('sku')}</FieldError>
          </Field>
          <Field>
            <FieldLabel htmlFor="p-brand">الماركة</FieldLabel>
            <Input id="p-brand" value={d.brand} onChange={(e) => set('brand', e.target.value)} />
          </Field>
          <Field data-invalid={!!show('barcodes') || undefined} className="sm:col-span-2">
            <FieldLabel htmlFor="p-barcodes">الباركود</FieldLabel>
            <Input
              id="p-barcodes"
              dir="ltr"
              className="num text-end"
              value={d.barcodes}
              aria-invalid={!!show('barcodes')}
              onChange={(e) => set('barcodes', e.target.value)}
            />
            {show('barcodes') ? <FieldError>{show('barcodes')}</FieldError> : <FieldDescription>يمكن إدخال أكثر من باركود مفصولة بفاصلة.</FieldDescription>}
          </Field>
          <Field>
            <FieldLabel htmlFor="p-cat">التصنيف</FieldLabel>
            <SimpleSelect
              id="p-cat"
              className="w-full"
              value={d.category}
              onValueChange={(v) => set('category', v as Category)}
              options={CATEGORIES.map((c) => ({ value: c, label: c }))}
            />
          </Field>
          <Field>
            <FieldLabel htmlFor="p-unit">وحدة البيع</FieldLabel>
            <SimpleSelect
              id="p-unit"
              className="w-full"
              value={d.unit}
              onValueChange={(v) => set('unit', v as Product['unit'])}
              options={UNITS.map((u) => ({ value: u, label: u }))}
            />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field data-invalid={!!show('price') || undefined}>
            <FieldLabel htmlFor="p-price">سعر القطاعي</FieldLabel>
            <Input id="p-price" type="number" inputMode="decimal" className="num" value={d.price} aria-invalid={!!show('price')} onChange={(e) => set('price', e.target.value)} />
            <FieldError>{show('price')}</FieldError>
          </Field>
          <Field data-invalid={!!show('wholesale') || undefined}>
            <FieldLabel htmlFor="p-wholesale">سعر الجملة</FieldLabel>
            <Input id="p-wholesale" type="number" inputMode="decimal" className="num" value={d.wholesale} aria-invalid={!!show('wholesale')} onChange={(e) => set('wholesale', e.target.value)} />
            <FieldError>{show('wholesale')}</FieldError>
          </Field>
          {showCost && (
            <Field data-invalid={!!show('cost') || undefined}>
              <FieldLabel htmlFor="p-cost">التكلفة</FieldLabel>
              <Input id="p-cost" type="number" inputMode="decimal" className="num" value={d.cost} aria-invalid={!!show('cost')} onChange={(e) => set('cost', e.target.value)} />
              {show('cost') ? (
                <FieldError>{show('cost')}</FieldError>
              ) : (
                margin !== null && (
                  <FieldDescription className={margin < 0 ? 'text-destructive' : undefined}>
                    هامش الربح <span className="num">{margin.toFixed(1)}%</span>
                  </FieldDescription>
                )
              )}
            </Field>
          )}
          <Field data-invalid={!!show('minStock') || undefined}>
            <FieldLabel htmlFor="p-min">حد إعادة الطلب</FieldLabel>
            <Input id="p-min" type="number" inputMode="numeric" className="num" value={d.minStock} aria-invalid={!!show('minStock')} onChange={(e) => set('minStock', e.target.value)} />
            <FieldError>{show('minStock')}</FieldError>
          </Field>
        </div>

        <Field orientation="horizontal" className="rounded-lg border p-3">
          <Switch id="p-active" checked={d.active} onCheckedChange={(v) => set('active', v)} />
          <FieldLabel htmlFor="p-active" className="flex-col items-start gap-0.5">
            <span>الصنف نشط</span>
            <span className="text-xs font-normal text-muted-foreground">الأصناف الموقوفة لا تظهر في نقطة البيع.</span>
          </FieldLabel>
        </Field>
      </FieldGroup>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button type="submit">{product ? 'حفظ التعديلات' : 'إضافة الصنف'}</Button>
      </DialogFooter>
    </form>
  )
}

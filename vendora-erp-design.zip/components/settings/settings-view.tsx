'use client'

import { useState } from 'react'
import { Building2, Warehouse } from 'lucide-react'
import { useTheme } from 'next-themes'
import { toast } from 'sonner'
import { PageHeader } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, FieldContent, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { BRANCHES } from '@/lib/mock-data'

type StoreForm = { name: string; taxId: string; phone: string; footer: string; vat: string }

const INITIAL: StoreForm = {
  name: 'المصرية الألمانية للأدوات الصحية',
  taxId: '512-874-339',
  phone: '19632',
  footer: 'البضاعة المباعة تُرد أو تُستبدل خلال 14 يومًا بحالتها الأصلية مع الفاتورة.',
  vat: '14',
}

export function SettingsView() {
  const { theme, setTheme } = useTheme()
  const [form, setForm] = useState(INITIAL)
  const [saved, setSaved] = useState(INITIAL)
  const [prefs, setPrefs] = useState({ blockOverLimit: true, requireReturnApproval: true, autoPrint: true, lowStockAlerts: true })
  const dirty = JSON.stringify(form) !== JSON.stringify(saved)
  const vat = Number(form.vat)
  const vatInvalid = !Number.isFinite(vat) || vat < 0 || vat > 100

  const set = (k: keyof StoreForm) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const PREFS: { key: keyof typeof prefs; label: string; description: string }[] = [
    { key: 'blockOverLimit', label: 'منع البيع الآجل فوق حد الائتمان', description: 'يرفض نقطة البيع الفاتورة الآجلة إذا تجاوز العميل حده.' },
    { key: 'requireReturnApproval', label: 'اعتماد المرتجعات من مدير الفرع', description: 'المرتجعات فوق 1,000 ج.م تحتاج موافقة.' },
    { key: 'autoPrint', label: 'طباعة الإيصال تلقائيًا', description: 'يفتح الطباعة مباشرة بعد تأكيد الدفع.' },
    { key: 'lowStockAlerts', label: 'تنبيهات النواقص', description: 'إشعار عند وصول صنف لحد إعادة الطلب.' },
  ]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="الإعدادات" description="بيانات المنشأة، الضرائب، سياسات البيع والمظهر" />

      <div className="grid gap-6 lg:grid-cols-3">
        <form
          className="lg:col-span-2"
          onSubmit={(e) => {
            e.preventDefault()
            if (vatInvalid) return
            setSaved(form)
            toast.success('تم حفظ بيانات المنشأة')
          }}
        >
          <Card>
            <CardHeader>
              <CardTitle>بيانات المنشأة والإيصال</CardTitle>
              <CardDescription>تظهر على الفواتير والإيصالات المطبوعة</CardDescription>
            </CardHeader>
            <CardContent>
              <FieldGroup>
                <Field>
                  <FieldLabel htmlFor="s-name">اسم المنشأة</FieldLabel>
                  <Input id="s-name" value={form.name} onChange={set('name')} />
                </Field>
                <div className="grid gap-4 sm:grid-cols-3">
                  <Field>
                    <FieldLabel htmlFor="s-tax">الرقم الضريبي</FieldLabel>
                    <Input id="s-tax" dir="ltr" className="num text-start" value={form.taxId} onChange={set('taxId')} />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor="s-phone">الخط الساخن</FieldLabel>
                    <Input id="s-phone" dir="ltr" className="num text-start" value={form.phone} onChange={set('phone')} />
                  </Field>
                  <Field data-invalid={vatInvalid || undefined}>
                    <FieldLabel htmlFor="s-vat">ضريبة القيمة المضافة %</FieldLabel>
                    <Input
                      id="s-vat"
                      type="number"
                      min={0}
                      max={100}
                      dir="ltr"
                      className="num text-start"
                      value={form.vat}
                      onChange={set('vat')}
                      aria-invalid={vatInvalid || undefined}
                    />
                  </Field>
                </div>
                <Field>
                  <FieldLabel htmlFor="s-footer">تذييل الإيصال</FieldLabel>
                  <Textarea id="s-footer" rows={3} value={form.footer} onChange={set('footer')} />
                  <FieldDescription>يُطبع أسفل كل إيصال — مناسب لسياسة الاسترجاع.</FieldDescription>
                </Field>
              </FieldGroup>
            </CardContent>
            <CardFooter className="justify-end gap-2">
              <Button type="button" variant="outline" disabled={!dirty} onClick={() => setForm(saved)}>
                تجاهل
              </Button>
              <Button type="submit" disabled={!dirty || vatInvalid}>
                حفظ التغييرات
              </Button>
            </CardFooter>
          </Card>
        </form>

        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader>
              <CardTitle>المظهر</CardTitle>
              <CardDescription>يُحفظ على هذا الجهاز</CardDescription>
            </CardHeader>
            <CardContent>
              <ToggleGroup value={theme ? [theme] : []} onValueChange={(v) => v[0] && setTheme(v[0])} variant="outline" aria-label="المظهر">
                <ToggleGroupItem value="light">فاتح</ToggleGroupItem>
                <ToggleGroupItem value="dark">داكن</ToggleGroupItem>
                <ToggleGroupItem value="system">النظام</ToggleGroupItem>
              </ToggleGroup>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>الفروع والمخازن</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              {BRANCHES.map((b) => {
                const Icon = b.kind === 'warehouse' ? Warehouse : Building2
                return (
                  <div key={b.id} className="flex items-center justify-between gap-3">
                    <span className="flex items-center gap-2 text-sm">
                      <Icon className="size-4 text-muted-foreground" aria-hidden />
                      {b.name}
                    </span>
                    <Badge variant="outline">{b.kind === 'warehouse' ? 'مخزن' : 'فرع'}</Badge>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>سياسات البيع والتنبيهات</CardTitle>
          <CardDescription>تُطبق على جميع الفروع فور التغيير</CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            {PREFS.map((p) => (
              <Field key={p.key} orientation="horizontal">
                <FieldContent>
                  <FieldLabel htmlFor={`pref-${p.key}`}>{p.label}</FieldLabel>
                  <FieldDescription>{p.description}</FieldDescription>
                </FieldContent>
                <Switch
                  id={`pref-${p.key}`}
                  checked={prefs[p.key]}
                  onCheckedChange={(c) => {
                    setPrefs((x) => ({ ...x, [p.key]: c }))
                    toast.success(c ? `تم تفعيل: ${p.label}` : `تم إيقاف: ${p.label}`)
                  }}
                />
              </Field>
            ))}
          </FieldGroup>
        </CardContent>
      </Card>
    </div>
  )
}

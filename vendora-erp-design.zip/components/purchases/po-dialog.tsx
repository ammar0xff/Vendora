'use client'

import { useState } from 'react'
import { SimpleSelect } from '@/components/app/shared'
import { LineEditor, linesValid, newLine, type Line } from '@/components/stock/line-editor'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { BRANCHES, type Product, type Supplier } from '@/lib/mock-data'

export type PoDraft = { supplierId: string; branchId: string; expected: string; lines: Line[]; send: boolean }

export function PoDialog({
  open,
  onOpenChange,
  products,
  suppliers,
  initialLines,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  products: Product[]
  suppliers: Supplier[]
  initialLines?: Line[]
  onSubmit: (d: PoDraft) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl">
        {open && <PoForm products={products} suppliers={suppliers} initialLines={initialLines} onCancel={() => onOpenChange(false)} onSubmit={onSubmit} />}
      </DialogContent>
    </Dialog>
  )
}

function PoForm({
  products,
  suppliers,
  initialLines,
  onCancel,
  onSubmit,
}: {
  products: Product[]
  suppliers: Supplier[]
  initialLines?: Line[]
  onCancel: () => void
  onSubmit: (d: PoDraft) => void
}) {
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id ?? '')
  const [branchId, setBranchId] = useState('main-wh')
  const [expected, setExpected] = useState(() => new Date(Date.now() + 4 * 86400000).toISOString().slice(0, 10))
  const [lines, setLines] = useState<Line[]>(initialLines?.length ? initialLines : [newLine()])
  const valid = !!supplierId && !!expected && linesValid(lines, products) && lines.every((l) => (l.cost ?? 0) > 0)

  return (
    <>
      <DialogHeader>
        <DialogTitle>أمر شراء جديد</DialogTitle>
        <DialogDescription>يُضاف الرصيد للمخزن المستلم عند تسجيل الاستلام فقط.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field>
            <FieldLabel htmlFor="po-supplier">المورد</FieldLabel>
            <SimpleSelect id="po-supplier" className="w-full min-w-0" value={supplierId} onValueChange={setSupplierId} options={suppliers.map((s) => ({ value: s.id, label: s.name }))} />
          </Field>
          <Field>
            <FieldLabel htmlFor="po-branch">جهة الاستلام</FieldLabel>
            <SimpleSelect id="po-branch" className="w-full min-w-0" value={branchId} onValueChange={setBranchId} options={BRANCHES.map((b) => ({ value: b.id, label: b.name }))} />
          </Field>
          <Field>
            <FieldLabel htmlFor="po-expected">تاريخ التوريد المتوقع</FieldLabel>
            <Input id="po-expected" type="date" className="num" value={expected} onChange={(e) => setExpected(e.target.value)} />
          </Field>
        </div>
        <Field>
          <FieldLabel>الأصناف</FieldLabel>
          <FieldDescription>الكمية ثم سعر الشراء للوحدة.</FieldDescription>
          <LineEditor lines={lines} onChange={setLines} products={products} withCost />
        </Field>
      </FieldGroup>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button variant="secondary" disabled={!valid} onClick={() => onSubmit({ supplierId, branchId, expected, lines, send: false })}>
          حفظ كمسودة
        </Button>
        <Button disabled={!valid} onClick={() => onSubmit({ supplierId, branchId, expected, lines, send: true })}>
          إرسال للمورد
        </Button>
      </DialogFooter>
    </>
  )
}

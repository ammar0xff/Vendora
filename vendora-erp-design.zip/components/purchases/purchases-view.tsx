'use client'

import { useMemo, useState } from 'react'
import { ClipboardList, MoreHorizontal, PackageCheck, Plus, Sparkles, Truck, Wallet } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { ListState, Money, Num, PageHeader, SimpleSelect, StatCard, StatusBadge, TableShell } from '@/components/app/shared'
import { newLine, type Line } from '@/components/stock/line-editor'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDate, formatDateTime } from '@/lib/format'
import { BRANCHES, type PurchaseOrder } from '@/lib/mock-data'
import { PoDialog, type PoDraft } from './po-dialog'

export function PurchasesView() {
  const { roleId } = useApp()
  const orders = useMock('purchases')
  const suppliers = useMock('suppliers')
  const products = useMock('products')
  const [status, setStatus] = useState('all')
  const [open, setOpen] = useState(false)
  const [initialLines, setInitialLines] = useState<Line[] | undefined>()
  const [cancelling, setCancelling] = useState<PurchaseOrder | null>(null)
  const [linesById, setLinesById] = useState<Record<string, { branchId: string; lines: Line[] }>>({})
  const showMoney = roleId !== 'storekeeper'

  const rows = useMemo(() => orders.data.filter((o) => status === 'all' || o.status === status), [orders.data, status])
  const open$ = orders.data.filter((o) => o.status === 'مرسل' || o.status === 'مستلم جزئيًا')
  const payables = suppliers.data.reduce((s, x) => s + x.balance, 0)

  function suggest() {
    const low = products.data.filter((p) => p.active && (p.stock['main-wh'] ?? 0) < p.minStock * 3)
    const lines = low.map((p) => ({ ...newLine(), productId: p.id, qty: p.minStock * 4 - (p.stock['main-wh'] ?? 0), cost: p.cost }))
    if (lines.length === 0) {
      toast.info('لا توجد نواقص في المخزن الرئيسي حاليًا')
      return
    }
    setInitialLines(lines)
    setOpen(true)
  }

  function create(d: PoDraft) {
    const supplier = suppliers.data.find((s) => s.id === d.supplierId)
    const id = `po${Date.now()}`
    const number = `PO-${String(222 + orders.data.length - 5).padStart(4, '0')}`
    const po: PurchaseOrder = {
      id,
      number,
      date: new Date().toISOString(),
      supplier: supplier?.name ?? '',
      branch: BRANCHES.find((b) => b.id === d.branchId)?.name ?? '',
      total: d.lines.reduce((s, l) => s + l.qty * (l.cost ?? 0), 0),
      status: d.send ? 'مرسل' : 'مسودة',
      expected: `${d.expected}T00:00:00`,
    }
    setLinesById((m) => ({ ...m, [id]: { branchId: d.branchId, lines: d.lines } }))
    orders.mutate([po, ...orders.data])
    setOpen(false)
    setInitialLines(undefined)
    toast.success(d.send ? `تم إرسال ${number} إلى ${po.supplier}` : `تم حفظ ${number} كمسودة`)
  }

  function setPoStatus(po: PurchaseOrder, next: PurchaseOrder['status']) {
    orders.mutate(orders.data.map((x) => (x.id === po.id ? { ...x, status: next } : x)))
  }

  function receive(po: PurchaseOrder) {
    const detail = linesById[po.id]
    if (detail) {
      products.mutate(
        products.data.map((p) => {
          const line = detail.lines.find((l) => l.productId === p.id)
          return line ? { ...p, stock: { ...p.stock, [detail.branchId]: (p.stock[detail.branchId] ?? 0) + line.qty } } : p
        }),
      )
    }
    setPoStatus(po, 'مستلم')
    suppliers.mutate(suppliers.data.map((s) => (s.name === po.supplier ? { ...s, balance: s.balance + po.total } : s)))
    toast.success(`تم استلام ${po.number}`, { description: `أضيفت الكميات إلى ${po.branch} وسُجلت مديونية للمورد` })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="المشتريات"
        description="أوامر الشراء والاستلام من الموردين"
        actions={
          <>
            <Button variant="outline" onClick={suggest} disabled={products.status !== 'ready'}>
              <Sparkles data-icon="inline-start" />
              اقتراح من النواقص
            </Button>
            <Button
              onClick={() => {
                setInitialLines(undefined)
                setOpen(true)
              }}
            >
              <Plus data-icon="inline-start" />
              أمر شراء
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="أوامر مفتوحة" value={<Num value={open$.length} />} icon={Truck} tone="warning" />
        {showMoney && <StatCard label="قيمة الأوامر المفتوحة" value={<Money value={open$.reduce((s, o) => s + o.total, 0)} />} icon={ClipboardList} />}
        {showMoney && <StatCard label="مستحقات الموردين" value={<Money value={payables} />} icon={Wallet} tone="destructive" />}
      </div>

      <SimpleSelect
        value={status}
        onValueChange={setStatus}
        label="الحالة"
        className="w-48"
        options={[{ value: 'all', label: 'كل الحالات' }, ...['مسودة', 'مرسل', 'مستلم جزئيًا', 'مستلم', 'ملغي'].map((s) => ({ value: s, label: s }))]}
      />

      <ListState
        status={orders.status}
        isEmpty={rows.length === 0}
        onRetry={orders.retry}
        emptyIcon={ClipboardList}
        emptyTitle="لا توجد أوامر شراء"
        emptyDescription="أنشئ أمر شراء أو استخدم الاقتراح التلقائي من النواقص."
      >
        <TableShell>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الأمر</TableHead>
                <TableHead>المورد</TableHead>
                <TableHead className="hidden md:table-cell">جهة الاستلام</TableHead>
                <TableHead className="hidden lg:table-cell">التوريد المتوقع</TableHead>
                {showMoney && <TableHead>القيمة</TableHead>}
                <TableHead>الحالة</TableHead>
                <TableHead className="w-12">
                  <span className="sr-only">إجراءات</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((po) => (
                <TableRow key={po.id}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="num font-medium">{po.number}</span>
                      <span className="num text-xs text-muted-foreground">{formatDateTime(po.date)}</span>
                    </div>
                  </TableCell>
                  <TableCell>{po.supplier}</TableCell>
                  <TableCell className="hidden md:table-cell">{po.branch}</TableCell>
                  <TableCell className="num hidden lg:table-cell">{formatDate(po.expected)}</TableCell>
                  {showMoney && (
                    <TableCell>
                      <Money value={po.total} />
                    </TableCell>
                  )}
                  <TableCell>
                    <StatusBadge status={po.status} />
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger render={<Button variant="ghost" size="icon-sm" aria-label={`إجراءات ${po.number}`} />}>
                        <MoreHorizontal />
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuGroup>
                          <DropdownMenuItem
                            disabled={po.status !== 'مسودة'}
                            onClick={() => {
                              setPoStatus(po, 'مرسل')
                              toast.success(`تم إرسال ${po.number}`)
                            }}
                          >
                            إرسال للمورد
                          </DropdownMenuItem>
                          <DropdownMenuItem disabled={po.status !== 'مرسل' && po.status !== 'مستلم جزئيًا'} onClick={() => receive(po)}>
                            <PackageCheck />
                            تسجيل استلام
                          </DropdownMenuItem>
                        </DropdownMenuGroup>
                        <DropdownMenuSeparator />
                        <DropdownMenuGroup>
                          <DropdownMenuItem variant="destructive" disabled={po.status !== 'مسودة' && po.status !== 'مرسل'} onClick={() => setCancelling(po)}>
                            إلغاء الأمر
                          </DropdownMenuItem>
                        </DropdownMenuGroup>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableShell>
      </ListState>

      <PoDialog
        open={open}
        onOpenChange={(o) => {
          setOpen(o)
          if (!o) setInitialLines(undefined)
        }}
        products={products.data}
        suppliers={suppliers.data}
        initialLines={initialLines}
        onSubmit={create}
      />
      <ConfirmDialog
        open={cancelling !== null}
        onOpenChange={(o) => !o && setCancelling(null)}
        title={`إلغاء ${cancelling?.number ?? ''}`}
        description="سيتم إبلاغ المورد بإلغاء الأمر ولن يمكن استلامه بعد ذلك."
        confirmLabel="إلغاء الأمر"
        destructive
        onConfirm={() => {
          if (!cancelling) return
          setPoStatus(cancelling, 'ملغي')
          toast.success(`تم إلغاء ${cancelling.number}`)
        }}
      />
    </div>
  )
}

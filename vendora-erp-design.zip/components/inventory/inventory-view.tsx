'use client'

import { useMemo, useState } from 'react'
import { ArrowLeftRight, Boxes, ClipboardCheck, History, PackageX, TriangleAlert } from 'lucide-react'
import { toast } from 'sonner'
import { useApp } from '@/components/app/app-provider'
import { ListState, Money, Num, PageHeader, SearchField, SimpleSelect, StatCard, TableShell } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Field, FieldLabel } from '@/components/ui/field'
import { Switch } from '@/components/ui/switch'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useMock } from '@/hooks/use-mock'
import { formatDateTime } from '@/lib/format'
import { BRANCHES, CATEGORIES, type StockMovement } from '@/lib/mock-data'
import { cn } from '@/lib/utils'
import { AdjustDialog, type Adjustment } from './adjust-dialog'

const MOVEMENT_VARIANT: Record<StockMovement['type'], 'success' | 'destructive' | 'info' | 'warning' | 'secondary'> = {
  بيع: 'secondary',
  شراء: 'success',
  'تحويل وارد': 'info',
  'تحويل صادر': 'info',
  مرتجع: 'warning',
  'تسوية جرد': 'destructive',
}

export function InventoryView() {
  const { branchId, userName, roleId } = useApp()
  const products = useMock('products')
  const movements = useMock('movements')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')
  const [lowOnly, setLowOnly] = useState(false)
  const [moveType, setMoveType] = useState('all')
  const [adjustOpen, setAdjustOpen] = useState(false)
  const showValue = roleId !== 'storekeeper'

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return products.data.filter(
      (p) =>
        (category === 'all' || p.category === category) &&
        (!lowOnly || Object.values(p.stock).some((v) => v < p.minStock)) &&
        (!q || p.name.includes(q) || p.sku.toLowerCase().includes(q)),
    )
  }, [products.data, search, category, lowOnly])

  const lowCount = products.data.filter((p) => Object.values(p.stock).some((v) => v < p.minStock)).length
  const outCount = products.data.filter((p) => Object.values(p.stock).some((v) => v === 0)).length
  const stockValue = products.data.reduce((s, p) => s + Object.values(p.stock).reduce((a, b) => a + b, 0) * p.cost, 0)
  const units = products.data.reduce((s, p) => s + Object.values(p.stock).reduce((a, b) => a + b, 0), 0)

  const movementRows = movements.data.filter((m) => moveType === 'all' || m.type === moveType)

  function applyAdjustment(a: Adjustment) {
    const product = products.data.find((p) => p.id === a.productId)
    const branch = BRANCHES.find((b) => b.id === a.branchId)
    if (!product || !branch) return
    products.mutate(products.data.map((p) => (p.id === a.productId ? { ...p, stock: { ...p.stock, [a.branchId]: a.counted } } : p)))
    movements.mutate([
      {
        id: `m${Date.now()}`,
        date: new Date().toISOString(),
        product: product.name,
        branch: branch.name,
        type: 'تسوية جرد',
        qty: a.diff,
        reference: `ADJ-${String(Date.now()).slice(-4)}`,
        user: userName,
      },
      ...movements.data,
    ])
    setAdjustOpen(false)
    toast.success('تم اعتماد التسوية', { description: `${product.name} — ${branch.name}: ${a.diff > 0 ? '+' : ''}${a.diff} (${a.reason})` })
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="المخزون"
        description="أرصدة الأصناف في كل الفروع والمخازن وحركة المخزون"
        actions={
          <Button onClick={() => setAdjustOpen(true)}>
            <ClipboardCheck data-icon="inline-start" />
            تسوية جرد
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="إجمالي الوحدات" value={<Num value={units} />} icon={Boxes} />
        {showValue && <StatCard label="قيمة المخزون بالتكلفة" value={<Money value={stockValue} />} icon={ArrowLeftRight} />}
        <StatCard label="أصناف تحت حد الطلب" value={<Num value={lowCount} />} icon={TriangleAlert} tone="warning" />
        <StatCard label="أصناف نفدت بفرع" value={<Num value={outCount} />} icon={PackageX} tone="destructive" />
      </div>

      <Tabs defaultValue="balances">
        <TabsList>
          <TabsTrigger value="balances">
            <Boxes />
            الأرصدة
          </TabsTrigger>
          <TabsTrigger value="movements">
            <History />
            حركة المخزون
          </TabsTrigger>
        </TabsList>

        <TabsContent value="balances" className="flex flex-col gap-4 pt-2">
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
            <SearchField value={search} onChange={setSearch} placeholder="اسم الصنف أو الكود" />
            <SimpleSelect
              value={category}
              onValueChange={setCategory}
              label="التصنيف"
              options={[{ value: 'all', label: 'كل التصنيفات' }, ...CATEGORIES.map((c) => ({ value: c, label: c }))]}
            />
            <Field orientation="horizontal" className="w-auto">
              <Switch id="low-only" checked={lowOnly} onCheckedChange={setLowOnly} />
              <FieldLabel htmlFor="low-only">النواقص فقط</FieldLabel>
            </Field>
          </div>

          <ListState
            status={products.status}
            isEmpty={rows.length === 0}
            onRetry={products.retry}
            emptyIcon={Boxes}
            emptyTitle={lowOnly ? 'لا توجد نواقص' : 'لا توجد أصناف'}
            emptyDescription={lowOnly ? 'كل الأصناف فوق حد إعادة الطلب في كل الفروع.' : 'لا توجد أصناف تطابق البحث.'}
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الصنف</TableHead>
                    {BRANCHES.map((b) => (
                      <TableHead key={b.id} className={cn('text-center', b.id === branchId && 'bg-primary/5 text-primary')}>
                        {b.name}
                      </TableHead>
                    ))}
                    <TableHead className="text-center">حد الطلب</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{p.name}</span>
                          <span className="num text-xs text-muted-foreground">
                            {p.sku} · {p.unit}
                          </span>
                        </div>
                      </TableCell>
                      {BRANCHES.map((b) => {
                        const v = p.stock[b.id] ?? 0
                        const threshold = b.kind === 'warehouse' ? p.minStock * 3 : p.minStock
                        return (
                          <TableCell key={b.id} className={cn('text-center', b.id === branchId && 'bg-primary/5')}>
                            {v === 0 ? (
                              <Badge variant="destructive">نفد</Badge>
                            ) : v < threshold ? (
                              <Badge variant="warning">
                                <span className="num">{v}</span>
                              </Badge>
                            ) : (
                              <Num value={v} />
                            )}
                          </TableCell>
                        )
                      })}
                      <TableCell className="text-center text-muted-foreground">
                        <Num value={p.minStock} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>

        <TabsContent value="movements" className="flex flex-col gap-4 pt-2">
          <SimpleSelect
            value={moveType}
            onValueChange={setMoveType}
            label="نوع الحركة"
            className="w-48"
            options={[{ value: 'all', label: 'كل الحركات' }, ...Object.keys(MOVEMENT_VARIANT).map((t) => ({ value: t, label: t }))]}
          />
          <ListState
            status={movements.status}
            isEmpty={movementRows.length === 0}
            onRetry={movements.retry}
            emptyIcon={History}
            emptyTitle="لا توجد حركات"
            emptyDescription="لم تُسجل أي حركة مخزون من هذا النوع."
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الصنف</TableHead>
                    <TableHead className="hidden md:table-cell">المخزن</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead className="text-center">الكمية</TableHead>
                    <TableHead className="hidden lg:table-cell">المرجع</TableHead>
                    <TableHead className="hidden lg:table-cell">المستخدم</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {movementRows.map((m) => (
                    <TableRow key={m.id}>
                      <TableCell className="num text-muted-foreground">{formatDateTime(m.date)}</TableCell>
                      <TableCell className="font-medium">{m.product}</TableCell>
                      <TableCell className="hidden md:table-cell">{m.branch}</TableCell>
                      <TableCell>
                        <Badge variant={MOVEMENT_VARIANT[m.type]}>{m.type}</Badge>
                      </TableCell>
                      <TableCell className={cn('num text-center font-medium', m.qty < 0 ? 'text-destructive' : 'text-success')}>
                        {m.qty > 0 ? `+${m.qty}` : m.qty}
                      </TableCell>
                      <TableCell className="num hidden lg:table-cell">{m.reference}</TableCell>
                      <TableCell className="hidden lg:table-cell">{m.user}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </TabsContent>
      </Tabs>

      <AdjustDialog open={adjustOpen} onOpenChange={setAdjustOpen} products={products.data} defaultBranch={branchId} onConfirm={applyAdjustment} />
    </div>
  )
}

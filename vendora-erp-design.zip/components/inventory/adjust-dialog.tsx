'use client'

import { useState } from 'react'
import { SimpleSelect } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { BRANCHES, type Product } from '@/lib/mock-data'

const REASONS = ['جرد دوري', 'تالف', 'فاقد', 'خطأ إدخال سابق'].map((r) => ({ value: r, label: r }))

export type Adjustment = { productId: string; branchId: string; counted: number; diff: number; reason: string }

export function AdjustDialog({
  open,
  onOpenChange,
  products,
  defaultBranch,
  onConfirm,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  products: Product[]
  defaultBranch: string
  onConfirm: (a: Adjustment) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        {open && <AdjustForm products={products} defaultBranch={defaultBranch} onCancel={() => onOpenChange(false)} onConfirm={onConfirm} />}
      </DialogContent>
    </Dialog>
  )
}

function AdjustForm({
  products,
  defaultBranch,
  onCancel,
  onConfirm,
}: {
  products: Product[]
  defaultBranch: string
  onCancel: () => void
  onConfirm: (a: Adjustment) => void
}) {
  const [productId, setProductId] = useState('')
  const [branchId, setBranchId] = useState(defaultBranch)
  const [counted, setCounted] = useState('')
  const [reason, setReason] = useState('جرد دوري')

  const product = products.find((p) => p.id === productId)
  const system = product?.stock[branchId] ?? 0
  const countedNum = counted === '' ? null : Math.max(0, Math.floor(Number(counted)))
  const diff = countedNum === null ? 0 : countedNum - system

  return (
    <>
      <DialogHeader>
        <DialogTitle>تسوية جرد</DialogTitle>
        <DialogDescription>سجّل الرصيد الفعلي بعد العد. الفرق يُسجَّل كحركة مخزون بسبب واضح.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <Field>
          <FieldLabel htmlFor="adj-product">الصنف</FieldLabel>
          <SimpleSelect
            id="adj-product"
            className="w-full"
            placeholder="اختر صنفًا"
            value={productId}
            onValueChange={setProductId}
            options={products.map((p) => ({ value: p.id, label: `${p.name} — ${p.sku}` }))}
          />
        </Field>
        <div className="grid grid-cols-2 gap-4">
          <Field>
            <FieldLabel htmlFor="adj-branch">المخزن</FieldLabel>
            <SimpleSelect id="adj-branch" className="w-full min-w-0" value={branchId} onValueChange={setBranchId} options={BRANCHES.map((b) => ({ value: b.id, label: b.name }))} />
          </Field>
          <Field>
            <FieldLabel htmlFor="adj-reason">السبب</FieldLabel>
            <SimpleSelect id="adj-reason" className="w-full min-w-0" value={reason} onValueChange={setReason} options={REASONS} />
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Field>
            <FieldLabel>رصيد النظام</FieldLabel>
            <div className="num flex h-8 items-center rounded-lg border bg-muted/50 px-2.5 text-sm">{product ? system : '—'}</div>
          </Field>
          <Field>
            <FieldLabel htmlFor="adj-counted">الرصيد الفعلي</FieldLabel>
            <Input id="adj-counted" type="number" inputMode="numeric" min={0} className="num" value={counted} disabled={!product} onChange={(e) => setCounted(e.target.value)} />
          </Field>
        </div>
        {product && countedNum !== null && (
          <div className="flex items-center justify-between rounded-lg bg-muted/60 p-3 text-sm">
            <span className="text-muted-foreground">الفرق</span>
            <Badge variant={diff === 0 ? 'secondary' : diff > 0 ? 'success' : 'destructive'}>
              <span className="num">{diff > 0 ? `+${diff}` : diff}</span>
            </Badge>
          </div>
        )}
      </FieldGroup>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button
          disabled={!product || countedNum === null || diff === 0}
          onClick={() => product && countedNum !== null && onConfirm({ productId: product.id, branchId, counted: countedNum, diff, reason })}
        >
          اعتماد التسوية
        </Button>
      </DialogFooter>
    </>
  )
}

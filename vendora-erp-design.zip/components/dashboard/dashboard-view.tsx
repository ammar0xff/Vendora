'use client'

import Link from 'next/link'
import { AlertTriangle, CalendarRange, Clock, Receipt, ShoppingCart, TrendingUp } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from 'recharts'
import { expectedCash, useApp } from '@/components/app/app-provider'
import { ListState, Money, Num, PageHeader, StatCard, StatusBadge, TableShell } from '@/components/app/shared'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useMock } from '@/hooks/use-mock'
import { formatDateTime, formatNumber, formatTime } from '@/lib/format'
import { SALES_TREND } from '@/lib/mock-data'

const chartConfig = {
  sales: { label: 'المبيعات', color: 'var(--chart-1)' },
  returns: { label: 'المرتجعات', color: 'var(--chart-4)' },
} satisfies ChartConfig

export function DashboardView() {
  const { shift, branchId, branchName } = useApp()
  const invoices = useMock('invoices')
  const products = useMock('products')

  const lowStock = products.data.filter((p) => p.active && (p.stock[branchId] ?? 0) < p.minStock)
  const todaySales = invoices.data
    .filter((i) => i.date.startsWith('2026-10-25') && i.status !== 'ملغاة' && i.status !== 'عرض سعر')
    .reduce((s, i) => s + i.total, 0)
  const monthSales = 1284650 + todaySales
  const trendTotal = SALES_TREND.reduce((s, d) => s + d.sales, 0)

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="لوحة التحكم"
        description={`نظرة عامة على ${branchName} — السبت 25 أكتوبر 2026`}
        actions={
          <Button nativeButton={false} render={<Link href="/pos" />}>
            <ShoppingCart data-icon="inline-start" />
            فاتورة جديدة
          </Button>
        }
      />

      <section aria-label="المؤشرات الرئيسية" className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard
          label="مبيعات اليوم"
          icon={Receipt}
          value={<Money value={todaySales} />}
          hint={
            <span className="flex items-center gap-1">
              <Badge variant="success">+12.4%</Badge> مقارنة بالسبت الماضي
            </span>
          }
        />
        <StatCard
          label="مبيعات الشهر"
          icon={CalendarRange}
          value={<Money value={monthSales} />}
          hint={<span>المستهدف 1,800,000.00 ج.م — تحقق <span className="num">72%</span></span>}
        />
        <StatCard
          label="منتجات تحت الحد"
          icon={AlertTriangle}
          tone={lowStock.length ? 'warning' : 'success'}
          value={<Num value={lowStock.length} />}
          hint={
            <Link href="/inventory" className="underline-offset-4 hover:underline">
              عرض قائمة النواقص
            </Link>
          }
        />
        <StatCard
          label="حالة الوردية"
          icon={Clock}
          tone={shift ? 'success' : 'destructive'}
          value={shift ? 'مفتوحة' : 'مغلقة'}
          hint={
            shift ? (
              <span>
                منذ <span className="num">{formatTime(shift.openedAt)}</span> — النقدية المتوقعة{' '}
                <Money value={expectedCash(shift)} />
              </span>
            ) : (
              <Link href="/shifts" className="underline-offset-4 hover:underline">
                افتح وردية لبدء البيع
              </Link>
            )
          }
        />
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle>المبيعات — آخر 14 يومًا</CardTitle>
            <CardDescription>
              إجمالي الفترة <Money value={trendTotal} />
            </CardDescription>
            <CardAction>
              <Badge variant="secondary">
                <TrendingUp data-icon="inline-start" />
                اتجاه صاعد
              </Badge>
            </CardAction>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="aspect-auto h-72 w-full" dir="ltr">
              <AreaChart data={SALES_TREND} margin={{ left: 8, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="fillSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-sales)" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="var(--color-sales)" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="day" tickLine={false} axisLine={false} tickMargin={8} reversed />
                <YAxis
                  orientation="right"
                  tickLine={false}
                  axisLine={false}
                  width={48}
                  tickFormatter={(v: number) => `${formatNumber(v / 1000)}k`}
                />
                <ChartTooltip content={<ChartTooltipContent indicator="line" />} />
                <Area dataKey="sales" type="monotone" stroke="var(--color-sales)" fill="url(#fillSales)" strokeWidth={2} />
                <Area dataKey="returns" type="monotone" stroke="var(--color-returns)" fill="transparent" strokeWidth={1.5} strokeDasharray="4 4" />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>نواقص {branchName}</CardTitle>
            <CardDescription>أصناف وصلت أقل من حد الطلب</CardDescription>
            <CardAction>
              <Button variant="outline" size="sm" nativeButton={false} render={<Link href="/purchases" />}>
                اقتراح طلب شراء
              </Button>
            </CardAction>
          </CardHeader>
          <CardContent>
            <ListState
              status={products.status}
              isEmpty={lowStock.length === 0}
              onRetry={products.retry}
              emptyTitle="لا توجد نواقص"
              emptyDescription="كل الأصناف فوق حد الطلب في هذا الفرع."
              emptyAction={
                <Button variant="outline" nativeButton={false} render={<Link href="/inventory" />}>
                  مراجعة المخزون
                </Button>
              }
            >
              <ul className="flex flex-col divide-y">
                {lowStock.slice(0, 6).map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="flex min-w-0 flex-col">
                      <span className="truncate text-sm font-medium">{p.name}</span>
                      <span className="num text-xs text-muted-foreground">{p.sku}</span>
                    </div>
                    <div className="flex shrink-0 items-center gap-2 text-sm">
                      <Num value={p.stock[branchId] ?? 0} className="font-semibold text-destructive" />
                      <span className="text-muted-foreground">/ <Num value={p.minStock} /></span>
                    </div>
                  </li>
                ))}
              </ul>
            </ListState>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>أحدث المبيعات</CardTitle>
          <CardDescription>آخر الفواتير المسجلة في كل الفروع</CardDescription>
          <CardAction>
            <Button variant="outline" size="sm" nativeButton={false} render={<Link href="/sales" />}>
              كل الفواتير
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent>
          <ListState
            status={invoices.status}
            isEmpty={invoices.data.length === 0}
            onRetry={invoices.retry}
            emptyTitle="لا توجد مبيعات بعد"
            emptyDescription="ستظهر الفواتير هنا بمجرد تسجيل أول عملية بيع."
            emptyAction={
              <Button nativeButton={false} render={<Link href="/pos" />}>
                <ShoppingCart data-icon="inline-start" />
                ابدأ البيع
              </Button>
            }
          >
            <TableShell>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الفاتورة</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead className="text-end">الإجمالي</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>التاريخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.data.slice(0, 7).map((inv) => (
                    <TableRow key={inv.id}>
                      <TableCell className="num font-medium">{inv.number}</TableCell>
                      <TableCell>{inv.customer}</TableCell>
                      <TableCell className="text-end">
                        <Money value={inv.total} />
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={inv.status} />
                      </TableCell>
                      <TableCell className="num text-muted-foreground">{formatDateTime(inv.date)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableShell>
          </ListState>
        </CardContent>
      </Card>
    </div>
  )
}

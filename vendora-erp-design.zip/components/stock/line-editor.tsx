'use client'

import { Plus, Trash2 } from 'lucide-react'
import { Money, SimpleSelect } from '@/components/app/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import type { Product } from '@/lib/mock-data'

export type Line = { key: string; productId: string; qty: number; cost?: number }

export function newLine(): Line {
  return { key: crypto.randomUUID(), productId: '', qty: 1 }
}

export function LineEditor({
  lines,
  onChange,
  products,
  available,
  withCost = false,
}: {
  lines: Line[]
  onChange: (lines: Line[]) => void
  products: Product[]
  available?: (p: Product) => number
  withCost?: boolean
}) {
  const update = (key: string, patch: Partial<Line>) => onChange(lines.map((l) => (l.key === key ? { ...l, ...patch } : l)))

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-col divide-y rounded-lg border">
        {lines.map((line, idx) => {
          const product = products.find((p) => p.id === line.productId)
          const max = product && available ? available(product) : undefined
          const over = max !== undefined && line.qty > max
          const taken = new Set(lines.filter((l) => l.key !== line.key).map((l) => l.productId))
          return (
            <div key={line.key} className="flex flex-col gap-2 p-3 sm:flex-row sm:items-start">
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <SimpleSelect
                  label={`صنف رقم ${idx + 1}`}
                  className="w-full"
                  placeholder="اختر صنفًا"
                  value={line.productId}
                  onValueChange={(v) => {
                    const p = products.find((x) => x.id === v)
                    update(line.key, { productId: v, cost: withCost ? p?.cost : undefined })
                  }}
                  options={products.filter((p) => !taken.has(p.id)).map((p) => ({ value: p.id, label: `${p.name} — ${p.sku}` }))}
                />
                {max !== undefined && (
                  <span className={over ? 'text-xs text-destructive' : 'text-xs text-muted-foreground'}>
                    المتاح: <span className="num">{max}</span>
                    {over && ' — الكمية أكبر من المتاح'}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  inputMode="numeric"
                  min={1}
                  aria-label="الكمية"
                  aria-invalid={over || undefined}
                  className="num w-20 text-center"
                  value={line.qty}
                  onChange={(e) => update(line.key, { qty: Math.max(0, Math.floor(Number(e.target.value) || 0)) })}
                />
                {withCost && (
                  <Input
                    type="number"
                    inputMode="decimal"
                    aria-label="سعر الشراء"
                    className="num w-28"
                    value={line.cost ?? ''}
                    onChange={(e) => update(line.key, { cost: Number(e.target.value) || 0 })}
                  />
                )}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon-sm"
                  aria-label="حذف السطر"
                  disabled={lines.length === 1}
                  onClick={() => onChange(lines.filter((l) => l.key !== line.key))}
                >
                  <Trash2 />
                </Button>
              </div>
            </div>
          )
        })}
      </div>
      <div className="flex items-center justify-between">
        <Button type="button" variant="outline" size="sm" onClick={() => onChange([...lines, newLine()])}>
          <Plus data-icon="inline-start" />
          إضافة سطر
        </Button>
        {withCost && (
          <span className="text-sm text-muted-foreground">
            الإجمالي <Money value={lines.reduce((s, l) => s + l.qty * (l.cost ?? 0), 0)} className="font-semibold text-foreground" />
          </span>
        )}
      </div>
    </div>
  )
}

export function linesValid(lines: Line[], products: Product[], available?: (p: Product) => number) {
  return (
    lines.length > 0 &&
    lines.every((l) => {
      const p = products.find((x) => x.id === l.productId)
      if (!p || l.qty <= 0) return false
      if (available && l.qty > available(p)) return false
      return true
    })
  )
}

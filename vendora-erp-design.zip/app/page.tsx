import { LoginForm } from '@/components/auth/login-form'
import { Droplets } from 'lucide-react'

export default function LoginPage() {
  return (
    <main className="grid min-h-svh lg:grid-cols-[1fr_1.1fr]">
      <section className="flex flex-col justify-center px-6 py-12 sm:px-12">
        <div className="mx-auto flex w-full max-w-sm flex-col gap-8">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Droplets className="size-5" aria-hidden />
            </span>
            <div className="flex flex-col leading-tight">
              <span className="text-lg font-semibold">فيندورا</span>
              <span className="text-xs text-muted-foreground">الشركة المصرية الألمانية للأدوات الصحية</span>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <h1 className="text-2xl font-semibold tracking-tight">تسجيل الدخول</h1>
            <p className="text-sm text-muted-foreground">أدخل بيانات حسابك للمتابعة إلى لوحة الفرع.</p>
          </div>
          <LoginForm />
        </div>
      </section>
      <aside className="relative hidden flex-col justify-end overflow-hidden bg-sidebar p-12 text-sidebar-foreground lg:flex">
        <div className="flex max-w-md flex-col gap-4">
          <p className="text-sm text-sidebar-primary">نظام تشغيل متكامل للفروع</p>
          <h2 className="text-balance text-3xl font-semibold leading-snug text-sidebar-accent-foreground">
            بيع، مخزون، مشتريات، ومالية — من شاشة واحدة لكل فرع.
          </h2>
          <ul className="flex flex-col gap-2 text-sm text-sidebar-foreground/75">
            <li>نقطة بيع سريعة تدعم الباركود والدفع المتعدد</li>
            <li>تحويلات بين الفروع والمخزن الرئيسي بموافقات</li>
            <li>ورديات وخزائن ومطابقة نقدية يومية</li>
          </ul>
        </div>
      </aside>
    </main>
  )
}

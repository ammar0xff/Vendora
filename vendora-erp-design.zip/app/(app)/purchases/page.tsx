import type { Metadata } from 'next'
import { PurchasesView } from '@/components/purchases/purchases-view'

export const metadata: Metadata = { title: 'المشتريات' }

export default function PurchasesPage() {
  return <PurchasesView />
}

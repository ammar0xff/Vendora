import type { Metadata } from 'next'
import { HrView } from '@/components/hr/hr-view'

export const metadata: Metadata = { title: 'الموارد البشرية' }

export default function HrPage() {
  return <HrView />
}

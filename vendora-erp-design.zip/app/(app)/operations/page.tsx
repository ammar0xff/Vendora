import type { Metadata } from 'next'
import { OperationsView } from '@/components/operations/operations-view'

export const metadata: Metadata = { title: 'العمليات المخزنية' }

export default function OperationsPage() {
  return <OperationsView />
}

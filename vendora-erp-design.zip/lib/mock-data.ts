import type { RoleId } from './permissions'

export type Branch = { id: string; name: string; kind: 'branch' | 'warehouse' }

export const BRANCHES: Branch[] = [
  { id: 'maadi', name: 'فرع المعادي', kind: 'branch' },
  { id: 'nasr', name: 'فرع مدينة نصر', kind: 'branch' },
  { id: 'october', name: 'فرع 6 أكتوبر', kind: 'branch' },
  { id: 'main-wh', name: 'المخزن الرئيسي', kind: 'warehouse' },
]

export const CATEGORIES = ['خلاطات ومحابس', 'مواسير ووصلات', 'أطقم حمامات', 'سخانات', 'لاصق وعزل'] as const
export type Category = (typeof CATEGORIES)[number]

export type Product = {
  id: string
  sku: string
  barcodes: string[]
  name: string
  brand: string
  category: Category
  unit: 'قطعة' | 'متر' | 'شيكارة' | 'طقم' | 'علبة'
  price: number
  wholesale: number
  cost: number
  image: string
  minStock: number
  stock: Record<string, number>
  active: boolean
}

export const PRODUCTS: Product[] = [
  { id: 'p1', sku: 'MX-1020', barcodes: ['6221034500127', '6221034500627'], name: 'خلاط مطبخ ذراع واحد كروم', brand: 'جروهي', category: 'خلاطات ومحابس', unit: 'قطعة', price: 2450, wholesale: 2205, cost: 1780, image: '/products/mixer-faucet.png', minStock: 10, stock: { maadi: 14, nasr: 6, october: 3, 'main-wh': 42 }, active: true },
  { id: 'p2', sku: 'MX-1045', barcodes: ['6221034500134', '6221034500634'], name: 'خلاط حوض بيسين قصير', brand: 'هانز', category: 'خلاطات ومحابس', unit: 'قطعة', price: 1890, wholesale: 1701, cost: 1320, image: '/products/mixer-faucet.png', minStock: 8, stock: { maadi: 9, nasr: 11, october: 0, 'main-wh': 25 }, active: true },
  { id: 'p3', sku: 'VL-0034', barcodes: ['6221034500141'], name: 'محبس زاوية نحاس ½ بوصة', brand: 'إيطالي', category: 'خلاطات ومحابس', unit: 'قطعة', price: 185, wholesale: 166.5, cost: 120, image: '/products/ball-valve.png', minStock: 40, stock: { maadi: 120, nasr: 35, october: 64, 'main-wh': 400 }, active: true },
  { id: 'p4', sku: 'VL-0051', barcodes: ['6221034500158'], name: 'محبس كورة نحاس 1 بوصة', brand: 'إيطالي', category: 'خلاطات ومحابس', unit: 'قطعة', price: 340, wholesale: 306, cost: 235, image: '/products/ball-valve.png', minStock: 25, stock: { maadi: 31, nasr: 18, october: 22, 'main-wh': 150 }, active: true },
  { id: 'p5', sku: 'PP-2010', barcodes: ['6221034500165'], name: 'ماسورة PVC صرف 4 بوصة', brand: 'الشريف', category: 'مواسير ووصلات', unit: 'متر', price: 96, wholesale: 86.4, cost: 68, image: '/products/pvc-pipe.png', minStock: 100, stock: { maadi: 260, nasr: 180, october: 75, 'main-wh': 1200 }, active: true },
  { id: 'p6', sku: 'PP-2025', barcodes: ['6221034500172'], name: 'ماسورة PPR تغذية 25 مم', brand: 'بنها', category: 'مواسير ووصلات', unit: 'متر', price: 42.5, wholesale: 38.25, cost: 29, image: '/products/pvc-pipe.png', minStock: 150, stock: { maadi: 340, nasr: 410, october: 220, 'main-wh': 2500 }, active: true },
  { id: 'p7', sku: 'FT-3001', barcodes: ['6221034500189'], name: 'كوع PPR 25 مم 90°', brand: 'بنها', category: 'مواسير ووصلات', unit: 'قطعة', price: 6.75, wholesale: 6.08, cost: 4.1, image: '/products/fittings.png', minStock: 300, stock: { maadi: 860, nasr: 520, october: 240, 'main-wh': 6000 }, active: true },
  { id: 'p8', sku: 'FT-3007', barcodes: ['6221034500196'], name: 'تيه PPR 25 مم', brand: 'بنها', category: 'مواسير ووصلات', unit: 'قطعة', price: 8.5, wholesale: 7.65, cost: 5.2, image: '/products/fittings.png', minStock: 300, stock: { maadi: 410, nasr: 95, october: 380, 'main-wh': 4800 }, active: true },
  { id: 'p9', sku: 'BT-5002', barcodes: ['6221034500202', '6221034500702'], name: 'قاعدة حمام قطعة واحدة', brand: 'ديورافيت', category: 'أطقم حمامات', unit: 'قطعة', price: 6850, wholesale: 6165, cost: 5100, image: '/products/toilet.png', minStock: 4, stock: { maadi: 5, nasr: 2, october: 3, 'main-wh': 18 }, active: true },
  { id: 'p10', sku: 'BT-5014', barcodes: ['6221034500219', '6221034500719'], name: 'حوض بيسين معلق 60 سم', brand: 'إيديال ستاندرد', category: 'أطقم حمامات', unit: 'قطعة', price: 2180, wholesale: 1962, cost: 1560, image: '/products/basin.png', minStock: 6, stock: { maadi: 8, nasr: 7, october: 1, 'main-wh': 30 }, active: true },
  { id: 'p11', sku: 'BT-5030', barcodes: ['6221034500226', '6221034500726'], name: 'دش مطري دائري 25 سم', brand: 'هانز', category: 'أطقم حمامات', unit: 'قطعة', price: 1250, wholesale: 1125, cost: 860, image: '/products/shower-head.png', minStock: 8, stock: { maadi: 12, nasr: 9, october: 4, 'main-wh': 40 }, active: true },
  { id: 'p12', sku: 'WH-7001', barcodes: ['6221034500233', '6221034500733'], name: 'سخان كهربائي 50 لتر', brand: 'أوليمبيك', category: 'سخانات', unit: 'قطعة', price: 5650, wholesale: 5085, cost: 4380, image: '/products/water-heater.png', minStock: 5, stock: { maadi: 6, nasr: 3, october: 2, 'main-wh': 22 }, active: true },
  { id: 'p13', sku: 'WH-7008', barcodes: ['6221034500240', '6221034500740'], name: 'سخان كهربائي 80 لتر', brand: 'أوليمبيك', category: 'سخانات', unit: 'قطعة', price: 7200, wholesale: 6480, cost: 5600, image: '/products/water-heater.png', minStock: 4, stock: { maadi: 2, nasr: 4, october: 0, 'main-wh': 12 }, active: true },
  { id: 'p14', sku: 'AD-8010', barcodes: ['6221034500257'], name: 'لاصق سيراميك 25 كجم', brand: 'سيكا', category: 'لاصق وعزل', unit: 'شيكارة', price: 215, wholesale: 193.5, cost: 160, image: '/products/tile-adhesive.png', minStock: 60, stock: { maadi: 75, nasr: 140, october: 48, 'main-wh': 900 }, active: true },
  { id: 'p15', sku: 'AD-8022', barcodes: ['6221034500264'], name: 'سيليكون شفاف مقاوم للفطريات', brand: 'سيكا', category: 'لاصق وعزل', unit: 'علبة', price: 115, wholesale: 103.5, cost: 74, image: '/products/silicone.png', minStock: 50, stock: { maadi: 88, nasr: 26, october: 61, 'main-wh': 600 }, active: true },
  { id: 'p16', sku: 'AD-8031', barcodes: ['6221034500271'], name: 'عازل مائي أسمنتي 20 كجم', brand: 'كيما', category: 'لاصق وعزل', unit: 'شيكارة', price: 640, wholesale: 576, cost: 470, image: '/products/tile-adhesive.png', minStock: 20, stock: { maadi: 24, nasr: 19, october: 9, 'main-wh': 210 }, active: false },
]

export type Customer = {
  id: string
  name: string
  phone: string
  type: 'فرد' | 'مقاول' | 'شركة'
  balance: number
  creditLimit: number
  lastPurchase: string
}

export const CUSTOMERS: Customer[] = [
  { id: 'c1', name: 'م. أحمد عبد الرحمن', phone: '01001234567', type: 'مقاول', balance: 18450, creditLimit: 50000, lastPurchase: '2026-10-24T13:20:00' },
  { id: 'c2', name: 'شركة النيل للمقاولات', phone: '0225167890', type: 'شركة', balance: 142300, creditLimit: 200000, lastPurchase: '2026-10-23T10:05:00' },
  { id: 'c3', name: 'محمود السيد حسن', phone: '01112223334', type: 'فرد', balance: 0, creditLimit: 0, lastPurchase: '2026-10-25T09:40:00' },
  { id: 'c4', name: 'مؤسسة الفتح للتشطيبات', phone: '01223334445', type: 'شركة', balance: 63780, creditLimit: 80000, lastPurchase: '2026-10-21T16:30:00' },
  { id: 'c5', name: 'م. كريم فؤاد', phone: '01556667778', type: 'مقاول', balance: 5200, creditLimit: 25000, lastPurchase: '2026-10-19T12:10:00' },
  { id: 'c6', name: 'سارة مصطفى', phone: '01098887776', type: 'فرد', balance: 0, creditLimit: 0, lastPurchase: '2026-10-25T11:55:00' },
  { id: 'c7', name: 'الشروق للإنشاءات', phone: '0233445566', type: 'شركة', balance: 91500, creditLimit: 90000, lastPurchase: '2026-10-15T14:00:00' },
]

export type Supplier = {
  id: string
  name: string
  phone: string
  category: string
  balance: number
  lastOrder: string
}

export const SUPPLIERS: Supplier[] = [
  { id: 's1', name: 'جروهي مصر للتوزيع', phone: '0227531100', category: 'خلاطات ومحابس', balance: 312000, lastOrder: '2026-10-20T10:00:00' },
  { id: 's2', name: 'بنها للمواسير البلاستيكية', phone: '0133221144', category: 'مواسير ووصلات', balance: 87500, lastOrder: '2026-10-22T09:30:00' },
  { id: 's3', name: 'سيكا إيجيبت', phone: '0244556677', category: 'لاصق وعزل', balance: 0, lastOrder: '2026-10-10T11:15:00' },
  { id: 's4', name: 'أوليمبيك إلكتريك', phone: '0235678900', category: 'سخانات', balance: 154800, lastOrder: '2026-10-18T13:45:00' },
  { id: 's5', name: 'إيديال ستاندرد الشرق الأوسط', phone: '0226001122', category: 'أطقم حمامات', balance: 46200, lastOrder: '2026-10-12T15:20:00' },
]

export type PaymentMethod = 'نقدي' | 'محفظة' | 'تحويل بنكي' | 'آجل'
export type InvoiceStatus = 'مكتملة' | 'آجل' | 'مرتجع جزئي' | 'مرتجع كلي' | 'ملغاة' | 'عرض سعر'

export type Invoice = {
  id: string
  number: string
  date: string
  customer: string
  branch: string
  cashier: string
  items: number
  total: number
  paid: number
  method: PaymentMethod
  status: InvoiceStatus
}

export const INVOICES: Invoice[] = [
  { id: 'i1', number: 'INV-10482', date: '2026-10-25T11:55:00', customer: 'سارة مصطفى', branch: 'فرع المعادي', cashier: 'منى عادل', items: 3, total: 4925, paid: 4925, method: 'محفظة', status: 'مكتملة' },
  { id: 'i2', number: 'INV-10481', date: '2026-10-25T11:12:00', customer: 'عميل نقدي', branch: 'فرع المعادي', cashier: 'منى عادل', items: 6, total: 1284.5, paid: 1284.5, method: 'نقدي', status: 'مكتملة' },
  { id: 'i3', number: 'INV-10480', date: '2026-10-25T09:40:00', customer: 'محمود السيد حسن', branch: 'فرع المعادي', cashier: 'منى عادل', items: 2, total: 7035, paid: 7035, method: 'نقدي', status: 'مكتملة' },
  { id: 'i4', number: 'INV-10479', date: '2026-10-24T17:22:00', customer: 'شركة النيل للمقاولات', branch: 'فرع مدينة نصر', cashier: 'يوسف رمضان', items: 14, total: 38640, paid: 10000, method: 'آجل', status: 'آجل' },
  { id: 'i5', number: 'INV-10478', date: '2026-10-24T13:20:00', customer: 'م. أحمد عبد الرحمن', branch: 'فرع المعادي', cashier: 'منى عادل', items: 9, total: 12480, paid: 12480, method: 'تحويل بنكي', status: 'مرتجع جزئي' },
  { id: 'i6', number: 'INV-10477', date: '2026-10-24T12:02:00', customer: 'عميل نقدي', branch: 'فرع 6 أكتوبر', cashier: 'هشام نبيل', items: 1, total: 185, paid: 185, method: 'نقدي', status: 'ملغاة' },
  { id: 'i7', number: 'INV-10476', date: '2026-10-24T10:47:00', customer: 'مؤسسة الفتح للتشطيبات', branch: 'فرع مدينة نصر', cashier: 'يوسف رمضان', items: 22, total: 26315, paid: 26315, method: 'تحويل بنكي', status: 'مكتملة' },
  { id: 'i11', number: 'QT-00213', date: '2026-10-24T15:30:00', customer: 'الشروق للإنشاءات', branch: 'فرع 6 أكتوبر', cashier: 'هشام نبيل', items: 18, total: 47250, paid: 0, method: 'آجل', status: 'عرض سعر' },
  { id: 'i8', number: 'INV-10475', date: '2026-10-23T16:05:00', customer: 'عميل نقدي', branch: 'فرع المعادي', cashier: 'منى عادل', items: 4, total: 2961, paid: 2961, method: 'نقدي', status: 'مكتملة' },
  { id: 'i9', number: 'INV-10474', date: '2026-10-23T14:38:00', customer: 'م. كريم فؤاد', branch: 'فرع 6 أكتوبر', cashier: 'هشام نبيل', items: 7, total: 9840, paid: 4640, method: 'آجل', status: 'آجل' },
  { id: 'i10', number: 'INV-10473', date: '2026-10-23T10:05:00', customer: 'شركة النيل للمقاولات', branch: 'فرع مدينة نصر', cashier: 'يوسف رمضان', items: 31, total: 54210, paid: 54210, method: 'تحويل بنكي', status: 'مكتملة' },
]

export type InvoiceLine = { productId: string; name: string; qty: number; price: number; returned: number }

export const INVOICE_LINES: Record<string, InvoiceLine[]> = {
  i5: [
    { productId: 'p3', name: 'محبس زاوية نحاس ½ بوصة', qty: 20, price: 185, returned: 4 },
    { productId: 'p6', name: 'ماسورة PPR تغذية 25 مم', qty: 120, price: 42.5, returned: 0 },
    { productId: 'p7', name: 'كوع PPR 25 مم 90°', qty: 200, price: 6.75, returned: 0 },
    { productId: 'p15', name: 'سيليكون شفاف مقاوم للفطريات', qty: 12, price: 115, returned: 0 },
  ],
}

export function getInvoiceLines(id: string): InvoiceLine[] {
  return (
    INVOICE_LINES[id] ?? [
      { productId: 'p1', name: 'خلاط مطبخ ذراع واحد كروم', qty: 1, price: 2450, returned: 0 },
      { productId: 'p3', name: 'محبس زاوية نحاس ½ بوصة', qty: 4, price: 185, returned: 0 },
      { productId: 'p15', name: 'سيليكون شفاف مقاوم للفطريات', qty: 2, price: 115, returned: 0 },
    ]
  )
}

export type StockMovement = {
  id: string
  date: string
  product: string
  branch: string
  type: 'بيع' | 'شراء' | 'تحويل وارد' | 'تحويل صادر' | 'مرتجع' | 'تسوية جرد'
  qty: number
  reference: string
  user: string
}

export const STOCK_MOVEMENTS: StockMovement[] = [
  { id: 'm1', date: '2026-10-25T11:55:00', product: 'خلاط مطبخ ذراع واحد كروم', branch: 'فرع المعادي', type: 'بيع', qty: -1, reference: 'INV-10482', user: 'منى عادل' },
  { id: 'm2', date: '2026-10-25T10:30:00', product: 'ماسورة PPR تغذية 25 مم', branch: 'فرع المعادي', type: 'تحويل وارد', qty: 200, reference: 'TR-0391', user: 'خالد إبراهيم' },
  { id: 'm3', date: '2026-10-25T10:30:00', product: 'ماسورة PPR تغذية 25 مم', branch: 'المخزن الرئيسي', type: 'تحويل صادر', qty: -200, reference: 'TR-0391', user: 'خالد إبراهيم' },
  { id: 'm4', date: '2026-10-24T15:10:00', product: 'محبس زاوية نحاس ½ بوصة', branch: 'فرع المعادي', type: 'مرتجع', qty: 4, reference: 'RT-0112', user: 'منى عادل' },
  { id: 'm5', date: '2026-10-24T09:00:00', product: 'سخان كهربائي 50 لتر', branch: 'المخزن الرئيسي', type: 'شراء', qty: 20, reference: 'PO-0218', user: 'خالد إبراهيم' },
  { id: 'm6', date: '2026-10-23T18:40:00', product: 'تيه PPR 25 مم', branch: 'فرع مدينة نصر', type: 'تسوية جرد', qty: -12, reference: 'ADJ-0044', user: 'طارق سمير' },
]

export type Transfer = {
  id: string
  number: string
  date: string
  from: string
  to: string
  items: number
  status: 'مسودة' | 'قيد النقل' | 'مستلم' | 'مرفوض'
  createdBy: string
}

export const TRANSFERS: Transfer[] = [
  { id: 't1', number: 'TR-0393', date: '2026-10-25T12:10:00', from: 'المخزن الرئيسي', to: 'فرع 6 أكتوبر', items: 5, status: 'قيد النقل', createdBy: 'خالد إبراهيم' },
  { id: 't2', number: 'TR-0392', date: '2026-10-25T08:45:00', from: 'فرع مدينة نصر', to: 'فرع المعادي', items: 2, status: 'مسودة', createdBy: 'طارق سمير' },
  { id: 't3', number: 'TR-0391', date: '2026-10-25T07:30:00', from: 'المخزن الرئيسي', to: 'فرع المعادي', items: 8, status: 'مستلم', createdBy: 'خالد إبراهيم' },
  { id: 't4', number: 'TR-0390', date: '2026-10-23T13:00:00', from: 'المخزن الرئيسي', to: 'فرع مدينة نصر', items: 3, status: 'مرفوض', createdBy: 'خالد إبراهيم' },
]

export type PurchaseOrder = {
  id: string
  number: string
  date: string
  supplier: string
  branch: string
  total: number
  status: 'مسودة' | 'مرسل' | 'مستلم جزئيًا' | 'مستلم' | 'ملغي'
  expected: string
}

export const PURCHASE_ORDERS: PurchaseOrder[] = [
  { id: 'po1', number: 'PO-0221', date: '2026-10-25T09:00:00', supplier: 'جروهي مصر للتوزيع', branch: 'المخزن الرئيسي', total: 186400, status: 'مرسل', expected: '2026-10-29T00:00:00' },
  { id: 'po2', number: 'PO-0220', date: '2026-10-23T11:20:00', supplier: 'بنها للمواسير البلاستيكية', branch: 'المخزن الرئيسي', total: 64250, status: 'مستلم جزئيًا', expected: '2026-10-26T00:00:00' },
  { id: 'po3', number: 'PO-0219', date: '2026-10-22T14:00:00', supplier: 'سيكا إيجيبت', branch: 'فرع مدينة نصر', total: 21800, status: 'مسودة', expected: '2026-10-30T00:00:00' },
  { id: 'po4', number: 'PO-0218', date: '2026-10-20T10:00:00', supplier: 'أوليمبيك إلكتريك', branch: 'المخزن الرئيسي', total: 87600, status: 'مستلم', expected: '2026-10-24T00:00:00' },
  { id: 'po5', number: 'PO-0217', date: '2026-10-18T09:15:00', supplier: 'إيديال ستاندرد الشرق الأوسط', branch: 'فرع المعادي', total: 43120, status: 'ملغي', expected: '2026-10-22T00:00:00' },
]

export type Treasury = { id: string; name: string; branch: string; balance: number; kind: 'خزينة' | 'بنك' | 'محفظة' }

export const TREASURIES: Treasury[] = [
  { id: 'tr1', name: 'خزينة المعادي', branch: 'فرع المعادي', balance: 48320.5, kind: 'خزينة' },
  { id: 'tr2', name: 'خزينة مدينة نصر', branch: 'فرع مدينة نصر', balance: 31275, kind: 'خزينة' },
  { id: 'tr3', name: 'خزينة 6 أكتوبر', branch: 'فرع 6 أكتوبر', balance: 12940, kind: 'خزينة' },
  { id: 'tr4', name: 'البنك الأهلي — جاري', branch: 'الإدارة', balance: 1284600, kind: 'بنك' },
  { id: 'tr5', name: 'فودافون كاش', branch: 'الإدارة', balance: 26480, kind: 'محفظة' },
  { id: 'tr6', name: 'إنستاباي', branch: 'الإدارة', balance: 41950, kind: 'محفظة' },
]

export type FinanceEntry = {
  id: string
  date: string
  description: string
  category: string
  treasury: string
  amount: number
  kind: 'إيراد' | 'مصروف'
  user: string
}

export const FINANCE_ENTRIES: FinanceEntry[] = [
  { id: 'f1', date: '2026-10-25T12:00:00', description: 'تحصيل دفعة من شركة النيل', category: 'تحصيل عملاء', treasury: 'البنك الأهلي — جاري', amount: 50000, kind: 'إيراد', user: 'رانيا فتحي' },
  { id: 'f2', date: '2026-10-25T10:15:00', description: 'نقل بضاعة — سيارة ربع نقل', category: 'نقل وشحن', treasury: 'خزينة المعادي', amount: 650, kind: 'مصروف', user: 'رانيا فتحي' },
  { id: 'f3', date: '2026-10-24T16:40:00', description: 'فاتورة كهرباء فرع مدينة نصر', category: 'مرافق', treasury: 'خزينة مدينة نصر', amount: 3420, kind: 'مصروف', user: 'رانيا فتحي' },
  { id: 'f4', date: '2026-10-24T11:00:00', description: 'سداد دفعة لأوليمبيك إلكتريك', category: 'سداد موردين', treasury: 'البنك الأهلي — جاري', amount: 60000, kind: 'مصروف', user: 'رانيا فتحي' },
  { id: 'f5', date: '2026-10-23T09:30:00', description: 'ضيافة ونظافة', category: 'نثريات', treasury: 'خزينة 6 أكتوبر', amount: 380, kind: 'مصروف', user: 'رانيا فتحي' },
]

export type Employee = {
  id: string
  name: string
  title: string
  branch: string
  phone: string
  salary: number
  status: 'حاضر' | 'غائب' | 'إجازة' | 'متأخر'
  checkIn?: string
}

export const EMPLOYEES: Employee[] = [
  { id: 'e1', name: 'منى عادل', title: 'كاشير', branch: 'فرع المعادي', phone: '01011112222', salary: 7500, status: 'حاضر', checkIn: '2026-10-25T08:52:00' },
  { id: 'e2', name: 'خالد إبراهيم', title: 'أمين مخزن', branch: 'المخزن الرئيسي', phone: '01022223333', salary: 9000, status: 'حاضر', checkIn: '2026-10-25T07:58:00' },
  { id: 'e3', name: 'يوسف رمضان', title: 'كاشير', branch: 'فرع مدينة نصر', phone: '01033334444', salary: 7500, status: 'متأخر', checkIn: '2026-10-25T09:41:00' },
  { id: 'e4', name: 'رانيا فتحي', title: 'محاسبة', branch: 'الإدارة', phone: '01044445555', salary: 12500, status: 'حاضر', checkIn: '2026-10-25T08:30:00' },
  { id: 'e5', name: 'هشام نبيل', title: 'كاشير', branch: 'فرع 6 أكتوبر', phone: '01055556666', salary: 7200, status: 'إجازة' },
  { id: 'e6', name: 'طارق سمير', title: 'مدير فرع', branch: 'فرع مدينة نصر', phone: '01066667777', salary: 16000, status: 'حاضر', checkIn: '2026-10-25T08:05:00' },
  { id: 'e7', name: 'إسلام حمدي', title: 'مندوب مبيعات', branch: 'فرع المعادي', phone: '01077778888', salary: 6800, status: 'غائب' },
]

export type ShiftRecord = {
  id: string
  cashier: string
  branch: string
  openedAt: string
  closedAt?: string
  openingCash: number
  expectedCash: number
  countedCash?: number
  sales: number
  invoices: number
}

export const SHIFT_HISTORY: ShiftRecord[] = [
  { id: 'sh1', cashier: 'يوسف رمضان', branch: 'فرع مدينة نصر', openedAt: '2026-10-24T09:00:00', closedAt: '2026-10-24T21:05:00', openingCash: 2000, expectedCash: 31480, countedCash: 31430, sales: 64955, invoices: 38 },
  { id: 'sh2', cashier: 'منى عادل', branch: 'فرع المعادي', openedAt: '2026-10-24T09:00:00', closedAt: '2026-10-24T21:00:00', openingCash: 2000, expectedCash: 18240, countedCash: 18240, sales: 27615, invoices: 26 },
  { id: 'sh3', cashier: 'هشام نبيل', branch: 'فرع 6 أكتوبر', openedAt: '2026-10-24T09:15:00', closedAt: '2026-10-24T20:45:00', openingCash: 1500, expectedCash: 9875, countedCash: 9925, sales: 12360, invoices: 17 },
  { id: 'sh4', cashier: 'منى عادل', branch: 'فرع المعادي', openedAt: '2026-10-23T09:00:00', closedAt: '2026-10-23T21:10:00', openingCash: 2000, expectedCash: 22310, countedCash: 22110, sales: 33480, invoices: 31 },
]

export type ArchiveDoc = {
  id: string
  title: string
  kind: 'عقد' | 'فاتورة مورد' | 'مستند حكومي' | 'صورة' | 'تقرير'
  linkedTo: string
  uploadedBy: string
  date: string
  size: string
}

export const ARCHIVE_DOCS: ArchiveDoc[] = [
  { id: 'a1', title: 'عقد توريد جروهي 2026', kind: 'عقد', linkedTo: 'جروهي مصر للتوزيع', uploadedBy: 'رانيا فتحي', date: '2026-10-20T10:00:00', size: '1.8 MB' },
  { id: 'a2', title: 'فاتورة PO-0218 الأصلية', kind: 'فاتورة مورد', linkedTo: 'PO-0218', uploadedBy: 'خالد إبراهيم', date: '2026-10-24T09:20:00', size: '640 KB' },
  { id: 'a3', title: 'السجل التجاري — تجديد', kind: 'مستند حكومي', linkedTo: 'الإدارة', uploadedBy: 'رانيا فتحي', date: '2026-09-30T12:00:00', size: '2.4 MB' },
  { id: 'a4', title: 'صور تلف شحنة سخانات', kind: 'صورة', linkedTo: 'PO-0218', uploadedBy: 'خالد إبراهيم', date: '2026-10-24T09:35:00', size: '5.1 MB' },
  { id: 'a5', title: 'تقرير جرد الربع الثالث', kind: 'تقرير', linkedTo: 'المخزن الرئيسي', uploadedBy: 'طارق سمير', date: '2026-10-02T15:00:00', size: '380 KB' },
]

export type AppUser = {
  id: string
  name: string
  email: string
  role: RoleId
  branch: string
  active: boolean
  lastLogin: string
}

export const APP_USERS: AppUser[] = [
  { id: 'u1', name: 'عمرو الجندي', email: 'amr@egygerman.com', role: 'admin', branch: 'الإدارة', active: true, lastLogin: '2026-10-25T08:00:00' },
  { id: 'u2', name: 'طارق سمير', email: 'tarek@egygerman.com', role: 'manager', branch: 'فرع مدينة نصر', active: true, lastLogin: '2026-10-25T08:06:00' },
  { id: 'u3', name: 'رانيا فتحي', email: 'rania@egygerman.com', role: 'accountant', branch: 'الإدارة', active: true, lastLogin: '2026-10-25T08:31:00' },
  { id: 'u4', name: 'خالد إبراهيم', email: 'khaled@egygerman.com', role: 'storekeeper', branch: 'المخزن الرئيسي', active: true, lastLogin: '2026-10-25T07:59:00' },
  { id: 'u5', name: 'منى عادل', email: 'mona@egygerman.com', role: 'cashier', branch: 'فرع المعادي', active: true, lastLogin: '2026-10-25T08:53:00' },
  { id: 'u6', name: 'هشام نبيل', email: 'hesham@egygerman.com', role: 'cashier', branch: 'فرع 6 أكتوبر', active: false, lastLogin: '2026-10-24T09:14:00' },
]

export type AuditLog = { id: string; date: string; user: string; action: string; target: string }

export const AUDIT_LOGS: AuditLog[] = [
  { id: 'l1', date: '2026-10-25T12:14:00', user: 'عمرو الجندي', action: 'تعديل صلاحيات', target: 'دور: أمين مخزن' },
  { id: 'l2', date: '2026-10-25T11:02:00', user: 'منى عادل', action: 'إلغاء فاتورة معلقة', target: 'HLD-0031' },
  { id: 'l3', date: '2026-10-25T09:40:00', user: 'طارق سمير', action: 'اعتماد تحويل', target: 'TR-0391' },
  { id: 'l4', date: '2026-10-24T21:05:00', user: 'يوسف رمضان', action: 'إغلاق وردية بفرق -50.00', target: 'SH-0884' },
]

export const SALES_TREND = [
  { day: '12/10', sales: 71200, returns: 1424 },
  { day: '13/10', sales: 88400, returns: 1768 },
  { day: '14/10', sales: 92100, returns: 1842 },
  { day: '15/10', sales: 65300, returns: 1306 },
  { day: '16/10', sales: 58700, returns: 1174 },
  { day: '17/10', sales: 94800, returns: 1896 },
  { day: '18/10', sales: 101300, returns: 2026 },
  { day: '19/10', sales: 84200, returns: 1684 },
  { day: '20/10', sales: 96500, returns: 1930 },
  { day: '21/10', sales: 78300, returns: 1566 },
  { day: '22/10', sales: 102800, returns: 2056 },
  { day: '23/10', sales: 118400, returns: 2368 },
  { day: '24/10', sales: 134900, returns: 2698 },
  { day: '25/10', sales: 61200, returns: 1224 },
]

export const BRANCH_SALES = [
  { branch: 'المعادي', sales: 284500 },
  { branch: 'مدينة نصر', sales: 341200 },
  { branch: '6 أكتوبر', sales: 151600 },
]

export const CATEGORY_SALES = [
  { category: 'خلاطات ومحابس', value: 34 },
  { category: 'أطقم حمامات', value: 26 },
  { category: 'مواسير ووصلات', value: 18 },
  { category: 'سخانات', value: 14 },
  { category: 'لاصق وعزل', value: 8 },
]

export const MOCK_SOURCES = {
  products: PRODUCTS,
  customers: CUSTOMERS,
  suppliers: SUPPLIERS,
  invoices: INVOICES,
  movements: STOCK_MOVEMENTS,
  transfers: TRANSFERS,
  purchases: PURCHASE_ORDERS,
  treasuries: TREASURIES,
  finance: FINANCE_ENTRIES,
  employees: EMPLOYEES,
  shifts: SHIFT_HISTORY,
  archive: ARCHIVE_DOCS,
  users: APP_USERS,
  audit: AUDIT_LOGS,
} as const

export type MockKey = keyof typeof MOCK_SOURCES

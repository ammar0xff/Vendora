import {
  Archive,
  ArrowLeftRight,
  BarChart3,
  Boxes,
  Clock,
  Contact,
  LayoutDashboard,
  Package,
  Receipt,
  Settings,
  ShieldCheck,
  ShoppingCart,
  Truck,
  UserCog,
  Wallet,
  type LucideIcon,
} from 'lucide-react'

export type FeatureKey =
  | 'dashboard'
  | 'pos'
  | 'sales'
  | 'products'
  | 'inventory'
  | 'operations'
  | 'purchases'
  | 'parties'
  | 'finance'
  | 'hr'
  | 'shifts'
  | 'archive'
  | 'reports'
  | 'users'
  | 'settings'

export type NavItem = {
  feature: FeatureKey
  label: string
  href: string
  icon: LucideIcon
  group: 'main' | 'stock' | 'money' | 'admin'
}

export const NAV_ITEMS: NavItem[] = [
  { feature: 'dashboard', label: 'لوحة التحكم', href: '/dashboard', icon: LayoutDashboard, group: 'main' },
  { feature: 'pos', label: 'نقطة البيع', href: '/pos', icon: ShoppingCart, group: 'main' },
  { feature: 'sales', label: 'المبيعات', href: '/sales', icon: Receipt, group: 'main' },
  { feature: 'shifts', label: 'الورديات', href: '/shifts', icon: Clock, group: 'main' },
  { feature: 'products', label: 'المنتجات', href: '/products', icon: Package, group: 'stock' },
  { feature: 'inventory', label: 'المخزون', href: '/inventory', icon: Boxes, group: 'stock' },
  { feature: 'operations', label: 'العمليات', href: '/operations', icon: ArrowLeftRight, group: 'stock' },
  { feature: 'purchases', label: 'المشتريات', href: '/purchases', icon: Truck, group: 'stock' },
  { feature: 'parties', label: 'العملاء والموردون', href: '/parties', icon: Contact, group: 'money' },
  { feature: 'finance', label: 'المالية', href: '/finance', icon: Wallet, group: 'money' },
  { feature: 'reports', label: 'التقارير', href: '/reports', icon: BarChart3, group: 'money' },
  { feature: 'hr', label: 'الموارد البشرية', href: '/hr', icon: UserCog, group: 'admin' },
  { feature: 'archive', label: 'الأرشيف', href: '/archive', icon: Archive, group: 'admin' },
  { feature: 'users', label: 'المستخدمون والصلاحيات', href: '/users', icon: ShieldCheck, group: 'admin' },
  { feature: 'settings', label: 'الإعدادات', href: '/settings', icon: Settings, group: 'admin' },
]

export const NAV_GROUPS: Record<NavItem['group'], string> = {
  main: 'التشغيل اليومي',
  stock: 'المخزون والتوريد',
  money: 'المال والعلاقات',
  admin: 'الإدارة',
}

export type RoleId = 'admin' | 'manager' | 'accountant' | 'storekeeper' | 'cashier'

export type Role = {
  id: RoleId
  label: string
  description: string
  features: FeatureKey[]
}

const ALL_FEATURES = NAV_ITEMS.map((n) => n.feature)

export const ROLES: Role[] = [
  {
    id: 'admin',
    label: 'مدير النظام',
    description: 'تحكم كامل في الإعدادات والمستخدمين — بدون صلاحية المالية افتراضيًا',
    features: ALL_FEATURES.filter((f) => f !== 'finance'),
  },
  {
    id: 'manager',
    label: 'مدير فرع',
    description: 'متابعة الفرع والمبيعات والمخزون والموظفين',
    features: ['dashboard', 'pos', 'sales', 'shifts', 'products', 'inventory', 'operations', 'purchases', 'parties', 'reports', 'hr', 'archive'],
  },
  {
    id: 'accountant',
    label: 'محاسب',
    description: 'المالية والخزائن والتقارير والذمم',
    features: ['dashboard', 'sales', 'purchases', 'parties', 'finance', 'reports', 'archive'],
  },
  {
    id: 'storekeeper',
    label: 'أمين مخزن',
    description: 'الأصناف والمخزون والتحويلات والاستلام',
    features: ['dashboard', 'products', 'inventory', 'operations', 'purchases'],
  },
  {
    id: 'cashier',
    label: 'كاشير',
    description: 'نقطة البيع والورديات وفواتير اليوم',
    features: ['pos', 'shifts', 'sales'],
  },
]

export function getRole(id: RoleId) {
  return ROLES.find((r) => r.id === id) ?? ROLES[0]
}

export function canAccess(role: RoleId, feature: FeatureKey) {
  return getRole(role).features.includes(feature)
}

export function featureForPath(pathname: string): FeatureKey | null {
  const item = NAV_ITEMS.find((n) => pathname === n.href || pathname.startsWith(`${n.href}/`))
  return item?.feature ?? null
}
